<?php
$host = "localhost";      // Server (leave as localhost if using XAMPP)
$user = "root";           // Default MySQL user in XAMPP
$pass = "";               // Default password is empty in XAMPP
$db   = "cleanupwaste"; // The database we created

// Create connection
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

