<?php
// Backfill lat/lon for existing letters that have a resident_location but no coordinates.
// Usage: run from CLI (php tools/backfill_geocode_letters.php) or via browser (not recommended for many rows).

include(__DIR__ . '/../includes/db_connect.php');

$limit = 50; // process at most 50 per run to avoid hammering service

$stmt = $conn->prepare("SELECT id, resident_location FROM letters WHERE (latitude IS NULL OR longitude IS NULL) AND resident_location IS NOT NULL AND resident_location <> '' LIMIT ?");
$stmt->bind_param('i', $limit);
$stmt->execute();
$result = $stmt->get_result();

$rows = [];
while ($r = $result->fetch_assoc()) $rows[] = $r;
$stmt->close();

if (empty($rows)) {
    echo "No records to backfill.\n";
    exit;
}

function geocode($address) {
    $url = 'https://nominatim.openstreetmap.org/search?format=json&q=' . urlencode($address) . '&limit=1';
    $opts = [
        "http" => [
            "method" => "GET",
            "header" => "User-Agent: DalipugaCleanup/1.0 (admin@example.com)\r\nAccept-Language: en\r\n"
        ]
    ];
    $context = stream_context_create($opts);
    $resp = @file_get_contents($url, false, $context);
    if (!$resp) return null;
    $j = json_decode($resp, true);
    if (!empty($j[0]['lat']) && !empty($j[0]['lon'])) return ['lat'=>$j[0]['lat'],'lon'=>$j[0]['lon']];
    return null;
}

foreach ($rows as $row) {
    $id = $row['id'];
    $addr = $row['resident_location'];
    echo "Geocoding id={$id} addr={$addr}... ";
    $g = geocode($addr);
    if ($g) {
        $u = $conn->prepare("UPDATE letters SET latitude = ?, longitude = ? WHERE id = ?");
        $u->bind_param('ddi', $g['lat'], $g['lon'], $id);
        if ($u->execute()) echo "OK ({$g['lat']},{$g['lon']})\n"; else echo "Update failed: " . $u->error . "\n";
        $u->close();
    } else {
        echo "No coords\n";
    }
    // Respect rate limits
    sleep(1);
}

echo "Done.\n";
?>