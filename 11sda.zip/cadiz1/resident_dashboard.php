<?php
session_start();
include("includes/db_connect.php");

if(!isset($_SESSION['resident_id'])){
    header("Location: auth/login.php");
    exit;
}

$resident_id = $_SESSION['resident_id'];

// Get resident information
$stmt = $conn->prepare("SELECT id, first_name, last_name, email, contact_number, location, date_added FROM residents WHERE id = ?");
$stmt->bind_param("i", $resident_id);
$stmt->execute();
$result = $stmt->get_result();
$resident = $result->fetch_assoc();
$stmt->close();

// If resident not found, logout
if (!$resident) {
    session_destroy();
    header("Location: auth/resident_login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resident Dashboard - Dalipuga Cleanup Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        /* ===== ECO-FRIENDLY BACKGROUND ===== */
        body {
            background: linear-gradient(135deg, #d4eee5 0%, #e8f8f0 50%, #c8e6c9 100%);
            position: relative;
            overflow-x: hidden;
            min-height: 100vh;
        }

        /* Decorative background shapes */
        .bg-shape {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.6;
            z-index: -1;
        }

        .bg-shape.green {
            width: 400px;
            height: 400px;
            background: #27ae60;
            top: -150px;
            left: -150px;
        }

        .bg-shape.light {
            width: 350px;
            height: 350px;
            background: #52b788;
            bottom: -150px;
            right: -150px;
        }

        .navbar-custom {
            background: linear-gradient(135deg, #27ae60 0%, #229954 100%);
        }

        /* ===== CARDS STYLING ===== */
        .card {
            background: linear-gradient(135deg, #f0f9f7 0%, #ffffff 100%);
            border: 2px solid #e8f5e9 !important;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(39, 174, 96, 0.1);
        }

        .card-header {
            background: linear-gradient(135deg, #27ae60 0%, #52b788 100%) !important;
            color: white !important;
            border-bottom: none;
            border-radius: 10px 10px 0 0;
        }

        .card-body {
            padding: 25px;
        }

        /* ===== LABELS AND TEXT ===== */
        label.fw-semibold {
            color: #27ae60 !important;
        }

        .appointment-card {
            background: linear-gradient(135deg, #f0f9f7 0%, #ffffff 100%);
            border-left: 4px solid #27ae60;
            transition: transform 0.3s;
            border: 2px solid #e8f5e9;
        }

        .appointment-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 30px rgba(39, 174, 96, 0.15);
        }

        .qr-section {
            text-align: center;
            padding: 20px;
            background: linear-gradient(135deg, #e8f5e9 0%, #f0f9f7 100%);
            border-radius: 10px;
            border: 2px solid #a8d5ba;
        }

        /* ===== SCHEDULE TABS ===== */
        .schedule-badge {
            display: inline-block;
            padding: 8px 12px;
            border-radius: 5px;
            font-weight: 600;
            margin: 5px;
        }

        .schedule-monday {
            background-color: #e8f5e9;
            color: #27ae60;
        }

        .schedule-wednesday {
            background-color: #e8f5e9;
            color: #27ae60;
        }

        .schedule-saturday {
            background-color: #e8f5e9;
            color: #27ae60;
        }

        /* ===== BUTTONS ===== */
        .btn-success, .btn-outline-success {
            background-color: #27ae60 !important;
            border-color: #27ae60 !important;
            color: white !important;
            font-weight: 600;
        }

        .btn-success:hover, .btn-outline-success:hover {
            background-color: #229954 !important;
            border-color: #229954 !important;
            transform: translateY(-2px);
        }

        .alert {
            border-left: 4px solid #27ae60;
            background-color: linear-gradient(135deg, #e8f5e9 0%, #f0f9f7 100%);
        }

        .alert-success {
            border-color: #27ae60 !important;
            background-color: #e8f5e9 !important;
            color: #27ae60 !important;
        }

        .alert-info {
            border-color: #27ae60 !important;
            background-color: #e8f5e9 !important;
            color: #27ae60 !important;
        }

        .alert-primary {
            border-color: #27ae60 !important;
            background-color: #e8f5e9 !important;
            color: #27ae60 !important;
        }

        .alert-warning {
            border-color: #f39c12 !important;
            background-color: #fff3e0 !important;
            color: #e67e22 !important;
        }

        /* ===== BADGES ===== */
        .badge {
            background-color: #27ae60 !important;
        }

        .container {
            position: relative;
            z-index: 1;
        }
    </style>
</head>
<body>
    <!-- Background Shapes -->
    <div class="bg-shape green"></div>
    <div class="bg-shape light"></div>

    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom">
        <div class="container-fluid px-4">
            <a class="navbar-brand" href="resident_dashboard.php">
                ♻️ Dalipuga Cleanup Management System
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#residentNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="residentNavbar">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="resident_dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="waste_report.php">Waste Report</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="send_letter.php">Send Letter</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="auth/resident_change_password.php">Change Password</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="auth/resident_logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Page Content -->
    <div class="container-fluid px-4 mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h3 mb-1 text-success fw-bold">Welcome, <?= htmlspecialchars($resident['first_name'] ?? '') ?>!</h1>
                <p class="text-muted mb-0">Resident Dashboard</p>
            </div>
        </div>

        <!-- Profile Information Card -->
        <div class="row mb-4">
            <div class="col-md-6">
                <div class="card shadow-sm">
                    <div class="card-header">
                        <h5 class="mb-0 fw-bold">👤 Your Profile Information</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="fw-semibold">Name</label>
                            <p class="text-dark"><?= htmlspecialchars(($resident['first_name'] ?? '') . ' ' . ($resident['last_name'] ?? '')) ?></p>
                        </div>
                        <div class="mb-3">
                            <label class="fw-semibold">Email</label>
                            <p class="text-dark"><?= htmlspecialchars($resident['email'] ?? '') ?></p>
                        </div>
                        <div class="mb-3">
                            <label class="fw-semibold">Contact Number</label>
                            <p class="text-dark"><?= htmlspecialchars($resident['contact_number'] ?? 'N/A') ?></p>
                        </div>
                        <div class="mb-3">
                            <label class="fw-semibold">Location/Address</label>
                            <p class="text-dark"><?= htmlspecialchars($resident['location'] ?? '') ?></p>
                        </div>
                        <div class="mb-3">
                            <label class="fw-semibold">Member Since</label>
                            <p class="text-dark"><?= htmlspecialchars(isset($resident['date_added']) ? date("M d, Y", strtotime($resident['date_added'])) : '') ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Stats Card -->
            <div class="col-md-6">
                <div class="card shadow-sm mb-4">
                    <div class="card-header">
                        <h5 class="mb-0 fw-bold">ℹ️ System Information</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="fw-semibold">System Name</label>
                            <p class="text-dark">Dalipuga Cleanup Management System</p>
                        </div>
                        <div class="mb-3">
                            <label class="fw-semibold">Role</label>
                            <p class="text-dark"><span class="badge bg-success">Resident</span></p>
                        </div>
                        <div class="mb-3">
                            <label class="fw-semibold">Session Status</label>
                            <p class="text-dark"><span class="badge bg-success">Active</span></p>
                        </div>
                        <div class="alert alert-success mt-4">
                            <strong> Welcome!</strong> You can now view your profile information and manage your account settings. Use the navigation menu to access more features.
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Info Section -->
        <div class="card shadow-sm">
            <div class="card-header">
                <h6 class="mb-0 fw-bold"> About Dalipuga Cleanup System</h6>
            </div>
            <div class="card-body">
                <p class="text-muted">
                    The Dalipuga Cleanup Management System is designed to help manage cleanup activities, track inventory, and coordinate with residents for a cleaner and healthier community.
                </p>
                <p class="text-muted mb-0">
                    As a resident, you can access your profile information and stay updated with community cleanup schedules and initiatives.
                </p>
            </div>
        </div>

        <!-- Appointment Schedule Card - Eco Friendly Tabs -->
        <div class="card shadow-sm mt-4">
            <div class="card-header">
                <h5 class="mb-0 fw-bold"> Cleanup Appointment Schedule</h5>
            </div>
            <div class="card-body">
                <p class="text-muted mb-4">Click on a day to view the schedule details:</p>
                
                <!-- Schedule Tabs/Buttons -->
                <div class="d-flex gap-2 mb-4">
                    <button class="btn schedule-btn schedule-btn-active" data-day="monday" style="background-color: #27ae60; color: white; border: none; padding: 10px 20px; border-radius: 5px; font-weight: 600; cursor: pointer;">
                        Monday
                    </button>
                    <button class="btn schedule-btn" data-day="wednesday" style="background-color: #e8f5e9; color: #27ae60; border: 2px solid #27ae60; padding: 10px 20px; border-radius: 5px; font-weight: 600; cursor: pointer;">
                        Wednesday
                    </button>
                    <button class="btn schedule-btn" data-day="saturday" style="background-color: #e8f5e9; color: #27ae60; border: 2px solid #27ae60; padding: 10px 20px; border-radius: 5px; font-weight: 600; cursor: pointer;">
                        Saturday
                    </button>
                </div>

                <!-- Schedule Content -->
                <div class="schedule-content">
                    <!-- Monday -->
                    <div class="schedule-day" id="monday" style="display: block;">
                        <div class="card border-0" style="background-color: #e8f5e9; border-left: 4px solid #27ae60;">
                            <div class="card-body">
                                <h5 class="text-success fw-bold"> Monday Schedule</h5>
                                <p class="mb-2">
                                    <i class="bi bi-clock" style="color: #27ae60;"></i> <strong>8:00 AM - 12:00 PM</strong>
                                </p>
                                <p class="mb-2">
                                    <i class="bi bi-trash" style="color: #27ae60;"></i> <strong style="color: #27ae60;">Non-Biodegradable Trash</strong>
                                </p>
                                <p class="text-muted">
                                    Plastics, metals, glass, and other non-organic waste
                                </p>
                            </div>
                        </div>
                    </div>

                    <!-- Wednesday -->
                    <div class="schedule-day" id="wednesday" style="display: none;">
                        <div class="card border-0" style="background-color: #e8f5e9; border-left: 4px solid #27ae60;">
                            <div class="card-body">
                                <h5 class="text-success fw-bold"> Wednesday Schedule</h5>
                                <p class="mb-2">
                                    <i class="bi bi-clock" style="color: #27ae60;"></i> <strong>9:00 AM - 1:00 PM</strong>
                                </p>
                                <p class="mb-2">
                                    <i class="bi bi-leaf" style="color: #27ae60;"></i> <strong style="color: #27ae60;">Biodegradable Waste</strong>
                                </p>
                                <p class="text-muted">
                                    Leaves, food scraps, garden waste, and organic materials
                                </p>
                            </div>
                        </div>
                    </div>

                    <!-- Saturday -->
                    <div class="schedule-day" id="saturday" style="display: none;">
                        <div class="card border-0" style="background-color: #e8f5e9; border-left: 4px solid #27ae60;">
                            <div class="card-body">
                                <h5 class="text-success fw-bold"> Saturday Schedule</h5>
                                <p class="mb-2">
                                    <i class="bi bi-clock" style="color: #27ae60;"></i> <strong>7:00 AM - 12:00 PM</strong>
                                </p>
                                <p class="mb-2">
                                    <i class="bi bi-boxes" style="color: #27ae60;"></i> <strong style="color: #27ae60;">Mixed General Waste</strong>
                                </p>
                                <p class="text-muted">
                                    All types of waste - comprehensive cleanup day
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="alert mt-4" style="background-color: #e8f5e9; border-left: 4px solid #27ae60; color: #27ae60;">
                    <strong> Tip:</strong> Send us a letter with your location and waste type to schedule a pickup during these times!
                </div>
            </div>
        </div>

        <!-- Announcements Section -->
        <div class="card shadow-sm mt-4">
            <div class="card-header">
                <h5 class="mb-0 fw-bold"> Announcements & Updates</h5>
            </div>
            <div class="card-body">
                <div class="alert alert-success" role="alert">
                    <h6 class="alert-heading"> Trash Collection Completed</h6>
                    <p class="mb-0">Thursday collection round completed successfully. Thank you for your cooperation!</p>
                </div>
                <div class="alert alert-info" role="alert">
                    <h6 class="alert-heading"> Scheduled Pickup Available</h6>
                    <p class="mb-0">Send us a letter to schedule a trash pickup for your area. Include your location and waste type.</p>
                </div>
                <div class="alert alert-primary" role="alert">
                    <h6 class="alert-heading"> New Collection Points Available</h6>
                    <p class="mb-0">Three new waste collection points have been established at Purok 2, 3, and 5.</p>
                </div>
            </div>
        </div>

    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Schedule Tab Switching
        document.querySelectorAll('.schedule-btn').forEach(button => {
            button.addEventListener('click', function() {
                const selectedDay = this.getAttribute('data-day');
                
                // Hide all schedule days
                document.querySelectorAll('.schedule-day').forEach(day => {
                    day.style.display = 'none';
                });
                
                // Show selected day
                document.getElementById(selectedDay).style.display = 'block';
                
                // Update button styles
                document.querySelectorAll('.schedule-btn').forEach(btn => {
                    btn.style.backgroundColor = '#e8f5e9';
                    btn.style.color = '#27ae60';
                    btn.style.border = '2px solid #27ae60';
                });
                
                // Highlight active button
                this.style.backgroundColor = '#27ae60';
                this.style.color = 'white';
                this.style.border = 'none';
            });
    </script>

    <!-- Footer -->
    <?php include("footer.php"); ?>