<?php
include("includes/auth_check.php");
include("includes/db_connect.php");
include("header.php");

$error = "";
$success = "";

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'send_message') {
            $resident_id = intval($_POST['resident_id'] ?? 0);
            $message = trim($_POST['message'] ?? '');

            if ($resident_id > 0 && !empty($message)) {
                // Get resident info
                $resident_query = $conn->prepare("SELECT first_name, last_name FROM residents WHERE id = ?");
                $resident_query->bind_param("i", $resident_id);
                $resident_query->execute();
                $resident = $resident_query->get_result()->fetch_assoc();

                if ($resident) {
                    $sender_name = $_SESSION['admin_username'];
                    $stmt = $conn->prepare("INSERT INTO messages (resident_id, admin_id, sender_type, sender_name, message) VALUES (?, ?, 'admin', ?, ?)");
                    $stmt->bind_param("iiss", $resident_id, $_SESSION['admin_id'], $sender_name, $message);
                    
                    if ($stmt->execute()) {
                        $success = "Message sent successfully!";
                    } else {
                        $error = "Error sending message: " . $stmt->error;
                    }
                }
            } else {
                $error = "Please select a resident and enter a message.";
            }
        } elseif ($_POST['action'] == 'mark_read') {
            $message_id = intval($_POST['message_id'] ?? 0);

            if ($message_id > 0) {
                $stmt = $conn->prepare("UPDATE messages SET is_read = 1 WHERE id = ?");
                $stmt->bind_param("i", $message_id);
                $stmt->execute();
            }
        }
    }
}

// Get all residents for dropdown
$residents_result = $conn->query("SELECT r.id, r.first_name, r.last_name, r.house_number, r.block_id, b.block_name 
    FROM residents r 
    LEFT JOIN blocks b ON r.block_id = b.id 
    WHERE r.status = 'active' 
    ORDER BY r.first_name");

// Get messages with resident info
$messages_result = $conn->query("SELECT m.*, r.house_number, b.block_name 
    FROM messages m 
    LEFT JOIN residents r ON m.resident_id = r.id 
    LEFT JOIN blocks b ON r.block_id = b.id 
    ORDER BY m.date_sent DESC");

// Get unread count
$unread_count = $conn->query("SELECT COUNT(*) as count FROM messages WHERE sender_type = 'resident' AND is_read = 0")->fetch_assoc()['count'];
?>

<style>
    .message-card {
        background: white;
        border-radius: 15px;
        padding: 20px;
        margin-bottom: 15px;
        box-shadow: 0 3px 15px rgba(0, 0, 0, 0.08);
        transition: all 0.3s ease;
    }

    .message-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 20px rgba(0, 0, 0, 0.12);
    }

    .message-card.unread {
        background: linear-gradient(135deg, #fff5f5 0%, #ffffff 100%);
        border-left: 4px solid #e74c3c;
    }

    .message-card.sent {
        border-left: 4px solid #27ae60;
    }

    .message-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
    }

    .message-sender {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .sender-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: 600;
    }

    .sender-avatar.resident { background: linear-gradient(135deg, #3498db 0%, #2980b9 100%); }
    .sender-avatar.admin { background: linear-gradient(135deg, #27ae60 0%, #229954 100%); }

    .message-content {
        background: #f8f9fa;
        border-radius: 10px;
        padding: 15px;
        margin: 10px 0;
    }

    .chat-container {
        max-height: 500px;
        overflow-y: auto;
        padding-right: 10px;
    }

    .chat-message {
        margin-bottom: 15px;
    }

    .chat-message.sent {
        text-align: right;
    }

    .chat-message.sent .message-bubble {
        background: linear-gradient(135deg, #27ae60 0%, #229954 100%);
        color: white;
        display: inline-block;
        padding: 12px 18px;
        border-radius: 18px 18px 4px 18px;
        max-width: 70%;
        text-align: left;
    }

    .chat-message.received .message-bubble {
        background: #f0f2f5;
        color: #2c3e50;
        display: inline-block;
        padding: 12px 18px;
        border-radius: 18px 18px 18px 4px;
        max-width: 70%;
    }

    .chat-message .time {
        font-size: 0.75rem;
        color: #7f8c8d;
        margin-top: 5px;
    }
</style>

<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1><i class="bi bi-envelope me-2"></i>Messages</h1>
            <p class="text-muted">Communicate with residents</p>
        </div>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#sendMessageModal">
            <i class="bi bi-plus-lg me-2"></i>New Message
        </button>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo $success; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Unread Badge -->
    <?php if ($unread_count > 0): ?>
        <div class="alert alert-info">
            <i class="bi bi-bell me-2"></i>You have <strong><?php echo $unread_count; ?></strong> unread message(s) from residents.
        </div>
    <?php endif; ?>

    <!-- Messages List -->
    <div class="row">
        <div class="col-12">
            <?php if ($messages_result && $messages_result->num_rows > 0): ?>
                <?php while ($message = $messages_result->fetch_assoc()): ?>
                    <div class="message-card <?php echo ($message['sender_type'] == 'resident' && !$message['is_read']) ? 'unread' : ''; ?> <?php echo ($message['sender_type'] == 'admin') ? 'sent' : ''; ?>">
                        <div class="message-header">
                            <div class="message-sender">
                                <div class="sender-avatar <?php echo $message['sender_type']; ?>">
                                    <?php 
                                    if ($message['sender_type'] == 'admin') {
                                        echo 'A';
                                    } else {
                                        echo strtoupper(substr($message['sender_name'], 0, 1));
                                    }
                                    ?>
                                </div>
                                <div>
                                    <strong><?php echo htmlspecialchars($message['sender_name']); ?></strong>
                                    <?php if ($message['sender_type'] == 'resident'): ?>
                                        <small class="text-muted d-block">
                                            <?php echo htmlspecialchars($message['house_number'] ?? 'N/A'); ?> | 
                                            <?php echo htmlspecialchars($message['block_name'] ?? 'N/A'); ?>
                                        </small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="text-end">
                                <small class="text-muted"><?php echo date('M d, Y h:i A', strtotime($message['date_sent'])); ?></small>
                                <?php if ($message['sender_type'] == 'resident' && !$message['is_read']): ?>
                                    <span class="badge bg-danger ms-2">New</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="message-content">
                            <?php echo nl2br(htmlspecialchars($message['message'])); ?>
                        </div>
                        <?php if ($message['sender_type'] == 'resident' && !$message['is_read']): ?>
                            <form method="POST" class="d-inline">
                                <input type="hidden" name="action" value="mark_read">
                                <input type="hidden" name="message_id" value="<?php echo $message['id']; ?>">
                                <button type="submit" class="btn btn-sm btn-outline-info">
                                    <i class="bi bi-check me-1"></i>Mark as Read
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="bi bi-inbox fs-1 text-muted"></i>
                    <p class="mt-3 text-muted">No messages yet.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Send Message Modal -->
<div class="modal fade" id="sendMessageModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title"><i class="bi bi-plus-lg me-2"></i>Send New Message</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form method="POST" id="sendMessageForm">
                    <input type="hidden" name="action" value="send_message">
                    
                    <div class="mb-3">
                        <label for="resident_id" class="form-label">Select Resident *</label>
                        <select class="form-select" name="resident_id" id="resident_id" required>
                            <option value="">Select Resident</option>
                            <?php while ($resident = $residents_result->fetch_assoc()): ?>
                                <option value="<?php echo $resident['id']; ?>">
                                    <?php echo htmlspecialchars($resident['first_name'] . ' ' . $resident['last_name'] . ' - ' . $resident['house_number'] . ' (' . $resident['block_name'] . ')'); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="message" class="form-label">Message *</label>
                        <textarea class="form-control" name="message" id="message" rows="5" required placeholder="Type your message here..."></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" form="sendMessageForm" class="btn btn-success">Send Message</button>
            </div>
        </div>
    </div>
</div>

<?php include("footer.php"); ?>
