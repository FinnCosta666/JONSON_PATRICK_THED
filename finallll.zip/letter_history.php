<?php
session_start();
include("includes/db_connect.php");

if(!isset($_SESSION['resident_id'])){
    header("Location: auth/resident_login.php");
    exit;
}

$resident_id = $_SESSION['resident_id'];

// Get resident information
$stmt = $conn->prepare("SELECT id, first_name, last_name FROM residents WHERE id = ?");
$stmt->bind_param("i", $resident_id);
$stmt->execute();
$result = $stmt->get_result();
$resident = $result->fetch_assoc();
$stmt->close();

// If resident not found, logout
if (!$resident) {
    session_destroy();
    header("Location: auth/resident_login.php");
    exit;
}

// Get all letters sent by this resident
$letters_stmt = $conn->prepare("SELECT id, subject, message, date_sent, status FROM letters WHERE resident_id = ? ORDER BY date_sent DESC");
$letters_stmt->bind_param("i", $resident_id);
$letters_stmt->execute();
$letters_result = $letters_stmt->get_result();
$letters = [];
while ($row = $letters_result->fetch_assoc()) {
    $letters[] = $row;
}
$letters_stmt->close();

// Function to extract trash info from message
function extractTrashInfo($message) {
    $trash_type = "N/A";
    $trash_weight = "N/A";
    
    if (preg_match('/Trash Type: (.+?) \|/', $message, $matches)) {
        $trash_type = trim($matches[1]);
    }
    
    if (preg_match('/Weight: ([\d.]+)\s*kg/', $message, $matches)) {
        $trash_weight = $matches[1] . " kg";
    }
    
    return ['type' => $trash_type, 'weight' => $trash_weight];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Letter History - Dalipuga Cleanup Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .navbar-custom {
            background: linear-gradient(135deg, #27ae60 0%, #229954 100%);
        }
        .letter-card {
            border-left: 4px solid #27ae60;
            transition: transform 0.3s;
            margin-bottom: 15px;
        }
        .letter-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .status-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-weight: 500;
            font-size: 12px;
        }
        .status-unread {
            background-color: #fff3cd;
            color: #856404;
        }
        .status-read {
            background-color: #d4edda;
            color: #155724;
        }
        .trash-info {
            background: #f8f9fa;
            padding: 12px;
            border-radius: 8px;
            margin: 10px 0;
        }
        .no-letters {
            text-align: center;
            padding: 40px 20px;
            color: #7f8c8d;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom">
        <div class="container-fluid px-4">
            <a class="navbar-brand" href="resident_dashboard.php">
                ♻️ Dalipuga Cleanup Management System
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#residentNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="residentNavbar">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="resident_dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="send_letter.php">Send Letter</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="letter_history.php">History</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="auth/resident_change_password.php">Change Password</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="auth/resident_logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Page Content -->
    <div class="container-fluid px-4 mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h3 mb-1 text-success fw-bold">Letter History</h1>
                <p class="text-muted mb-0">View all your submitted letters and garbage information</p>
            </div>
        </div>

        <?php if (count($letters) > 0): ?>
            <div class="row">
                <div class="col-12">
                    <?php foreach ($letters as $letter): 
                        $trash_info = extractTrashInfo($letter['message']);
                        $date = date("M d, Y • h:i A", strtotime($letter['date_sent']));
                        $status_class = $letter['status'] === 'read' ? 'status-read' : 'status-unread';
                        $status_text = ucfirst($letter['status']);
                    ?>
                        <div class="card letter-card shadow-sm border-0">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <div>
                                        <h5 class="card-title mb-1 text-success"><?= htmlspecialchars($letter['subject']) ?></h5>
                                        <small class="text-muted"><?= $date ?></small>
                                    </div>
                                    <span class="status-badge <?= $status_class ?>"><?= $status_text ?></span>
                                </div>

                                <div class="trash-info">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label class="fw-semibold text-success small">Trash Type</label>
                                            <p class="mb-0 text-dark"><?= htmlspecialchars($trash_info['type']) ?></p>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="fw-semibold text-success small">Weight</label>
                                            <p class="mb-0 text-dark"><?= htmlspecialchars($trash_info['weight']) ?></p>
                                        </div>
                                    </div>
                                </div>

                                <?php 
                                    // Extract the actual message (after trash type and weight)
                                    $full_message = $letter['message'];
                                    $message_only = preg_replace('/Trash Type:.+?kg\n\n/', '', $full_message);
                                ?>
                                <?php if (!empty(trim($message_only))): ?>
                                    <div class="mt-3">
                                        <label class="fw-semibold text-success small">Message</label>
                                        <p class="card-text text-dark"><?= htmlspecialchars($message_only) ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php else: ?>
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <div class="no-letters">
                        <h5 class="text-muted mb-2">No letters submitted yet</h5>
                        <p class="text-muted mb-3">You haven't sent any letters to the admin yet.</p>
                        <a href="send_letter.php" class="btn btn-success">Send Your First Letter</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
