<?php
session_start();
include("../includes/db_connect.php");

// Only allow admins to export
if (empty($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit;
}

$now = date('Y-m-d_H-i');
$filename = "accounts_backup_{$now}.csv";
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=' . $filename);

$out = fopen('php://output', 'w');
// Write header
fputcsv($out, ['type','id','username_or_name','email','contact_number','location']);

// Admins
$adm = $conn->query("SELECT Admin_Id, Username, Email, Contact_Number FROM admin");
while ($row = $adm->fetch_assoc()) {
    fputcsv($out, ['admin', $row['Admin_Id'], $row['Username'], $row['Email'], $row['Contact_Number'], '']);
}

// Residents
$res = $conn->query("SELECT id, CONCAT(first_name,' ',last_name) AS name, email, contact_number, location FROM residents");
while ($row = $res->fetch_assoc()) {
    fputcsv($out, ['resident', $row['id'], $row['name'], $row['email'], $row['contact_number'], $row['location']]);
}

fclose($out);
exit;
?>