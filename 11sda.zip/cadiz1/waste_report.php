<?php
session_start();
include("includes/db_connect.php");

if(!isset($_SESSION['resident_id'])){
    header("Location: auth/login.php");
    exit;
}

$resident_id = $_SESSION['resident_id'];

// Get resident information
$stmt = $conn->prepare("SELECT id, first_name, last_name, email, contact_number, location, date_added FROM residents WHERE id = ?");
$stmt->bind_param("i", $resident_id);
$stmt->execute();
$result = $stmt->get_result();
$resident = $result->fetch_assoc();
$stmt->close();

// If resident not found, logout
if (!$resident) {
    session_destroy();
    header("Location: auth/resident_login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Waste Reports - Dalipuga Cleanup Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        /* ===== ECO-FRIENDLY BACKGROUND ===== */
        body {
            background: linear-gradient(135deg, #d4eee5 0%, #e8f8f0 50%, #c8e6c9 100%);
            position: relative;
            overflow-x: hidden;
            min-height: 100vh;
        }

        /* Decorative background shapes */
        .bg-shape {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.6;
            z-index: -1;
        }

        .bg-shape.green {
            width: 400px;
            height: 400px;
            background: #27ae60;
            top: -150px;
            left: -150px;
        }

        .bg-shape.light {
            width: 350px;
            height: 350px;
            background: #52b788;
            bottom: -150px;
            right: -150px;
        }

        .navbar-custom {
            background: linear-gradient(135deg, #27ae60 0%, #229954 100%);
        }

        /* ===== CARDS STYLING ===== */
        .card {
            background: linear-gradient(135deg, #f0f9f7 0%, #ffffff 100%);
            border: 2px solid #e8f5e9 !important;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(39, 174, 96, 0.1);
        }

        .card-header {
            background: linear-gradient(135deg, #27ae60 0%, #52b788 100%) !important;
            color: white !important;
            border-bottom: none;
            border-radius: 10px 10px 0 0;
        }

        .card-body {
            padding: 25px;
        }

        .container {
            position: relative;
            z-index: 1;
        }

        .table thead {
            background-color: #f0f9f7;
        }

        .table tbody tr:hover {
            background-color: #e8f5e9;
        }

        .btn-success {
            background-color: #27ae60 !important;
            border-color: #27ae60 !important;
            font-weight: 600;
        }

        .btn-success:hover {
            background-color: #229954 !important;
            border-color: #229954 !important;
            transform: translateY(-2px);
        }

        .badge {
            padding: 6px 12px;
            font-weight: 600;
            font-size: 0.85rem;
        }

        .waste-report-container {
            max-width: 1200px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <!-- Background Shapes -->
    <div class="bg-shape green"></div>
    <div class="bg-shape light"></div>

    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom">
        <div class="container-fluid px-4">
            <a class="navbar-brand" href="resident_dashboard.php">
                ♻️ Dalipuga Cleanup Management System
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#residentNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="residentNavbar">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="resident_dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="waste_report.php">Waste Report</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="send_letter.php">Send Letter</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="auth/resident_change_password.php">Change Password</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="auth/resident_logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Page Content -->
    <div class="container-fluid px-4 mt-4 waste-report-container">
        <div class="row mb-4">
            <div class="col-12">
                <div>
                    <h1 class="h3 mb-1 text-success fw-bold">📋 Waste Reports</h1>
                    <p class="text-muted mb-0">View and manage all your submitted waste reports</p>
                </div>
            </div>
        </div>

        <!-- Waste Reports Table -->
        <div class="card shadow-sm">
            <div class="card-header">
                <h5 class="mb-0 fw-bold">📝 Your Waste Reports</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light text-uppercase small">
                            <tr>
                                <th class="ps-4">ID</th>
                                <th>Subject</th>
                                <th>Status</th>
                                <th>Priority</th>
                                <th>Date Sent</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Fetch all letters for the logged-in resident
                            $letter_stmt = $conn->prepare("SELECT id, subject, status, priority, date_sent FROM letters WHERE resident_id = ? ORDER BY date_sent DESC");
                            $letter_stmt->bind_param("i", $resident_id);
                            $letter_stmt->execute();
                            $letter_result = $letter_stmt->get_result();
                            
                            if ($letter_result && $letter_result->num_rows > 0) {
                                while ($ltr = $letter_result->fetch_assoc()) {
                                    $status_badge = $ltr['status'] == 'unread' ?
                                        '<span class="badge bg-warning text-dark">Unread</span>' :
                                        '<span class="badge bg-success">' . htmlspecialchars(ucfirst($ltr['status'])) . '</span>';
                                    
                                    $priority_color = '';
                                    switch($ltr['priority']) {
                                        case 'High':
                                            $priority_color = 'bg-danger';
                                            break;
                                        case 'Normal':
                                            $priority_color = 'bg-info';
                                            break;
                                        case 'Low':
                                            $priority_color = 'bg-secondary';
                                            break;
                                        default:
                                            $priority_color = 'bg-secondary';
                                    }
                                    $priority_badge = '<span class="badge ' . $priority_color . '">' . htmlspecialchars($ltr['priority']) . '</span>';
                                    ?>
                                    <tr>
                                        <td class="ps-4 fw-bold"><?= htmlspecialchars($ltr['id']) ?></td>
                                        <td><?= htmlspecialchars($ltr['subject']) ?></td>
                                        <td><?= $status_badge ?></td>
                                        <td><?= $priority_badge ?></td>
                                        <td class="text-muted small"><?= htmlspecialchars(date("M d, Y H:i", strtotime($ltr['date_sent']))) ?></td>
                                        <td class="text-center">
                                            <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#wasteReportModal" onclick="viewWasteReport(<?= $ltr['id'] ?>)">
                                                👁️ View
                                            </button>
                                        </td>
                                    </tr>
                                    <?php
                                }
                            } else {
                                ?>
                                <tr>
                                    <td colspan="6" class="text-center py-5 text-muted">
                                        <i class="bi bi-inbox" style="font-size: 2rem; opacity: 0.5;"></i>
                                        <p class="mt-2">You have not submitted any waste reports yet.</p>
                                        <a href="resident_dashboard.php#wasteReportForm" class="btn btn-success btn-sm mt-2">📝 Create First Report</a>
                                    </td>
                                </tr>
                                <?php
                            }
                            $letter_stmt->close();
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Quick Stats -->
        <div class="row mt-4 mb-4">
            <div class="col-md-3">
                <div class="card text-center">
                    <div class="card-body">
                        <h5 class="text-success fw-bold">
                            <?php
                            $count_stmt = $conn->prepare("SELECT COUNT(*) as total FROM letters WHERE resident_id = ?");
                            $count_stmt->bind_param("i", $resident_id);
                            $count_stmt->execute();
                            $count_result = $count_stmt->get_result();
                            $count_row = $count_result->fetch_assoc();
                            echo $count_row['total'];
                            $count_stmt->close();
                            ?>
                        </h5>
                        <p class="text-muted mb-0">Total Reports</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-center">
                    <div class="card-body">
                        <h5 class="text-info fw-bold">
                            <?php
                            $unread_stmt = $conn->prepare("SELECT COUNT(*) as unread FROM letters WHERE resident_id = ? AND status = 'unread'");
                            $unread_stmt->bind_param("i", $resident_id);
                            $unread_stmt->execute();
                            $unread_result = $unread_stmt->get_result();
                            $unread_row = $unread_result->fetch_assoc();
                            echo $unread_row['unread'];
                            $unread_stmt->close();
                            ?>
                        </h5>
                        <p class="text-muted mb-0">Unread Reports</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-center">
                    <div class="card-body">
                        <h5 class="text-warning fw-bold">
                            <?php
                            $high_stmt = $conn->prepare("SELECT COUNT(*) as high FROM letters WHERE resident_id = ? AND priority = 'High'");
                            $high_stmt->bind_param("i", $resident_id);
                            $high_stmt->execute();
                            $high_result = $high_stmt->get_result();
                            $high_row = $high_result->fetch_assoc();
                            echo $high_row['high'];
                            $high_stmt->close();
                            ?>
                        </h5>
                        <p class="text-muted mb-0">High Priority</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-center">
                    <div class="card-body">
                        <h5 class="text-success fw-bold">
                            <?php
                            $read_stmt = $conn->prepare("SELECT COUNT(*) as resolved_count FROM letters WHERE resident_id = ? AND status != 'unread'");
                            $read_stmt->bind_param("i", $resident_id);
                            $read_stmt->execute();
                            $read_result = $read_stmt->get_result();
                            $read_row = $read_result->fetch_assoc();
                            echo $read_row['resolved_count'];
                            $read_stmt->close();
                            ?>
                        </h5>
                        <p class="text-muted mb-0">Resolved</p>
                    </div>
                </div>
            </div>
        </div>

        <a href="resident_dashboard.php" class="btn btn-outline-success mb-4">← Back to Dashboard</a>
    </div>

    <!-- Waste Report Modal -->
    <div class="modal fade" id="wasteReportModal" tabindex="-1" aria-labelledby="wasteReportModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title" id="wasteReportModalLabel">📧 Report Details & Location</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" style="min-height: 500px; background-color: #f9f9f9;">
                    <div class="row g-3">
                        <div class="col-md-5">
                            <div id="wasteReportContent" style="max-height: 450px; overflow-y: auto;">
                                <div class="text-center text-muted py-5">
                                    <div class="spinner-border text-success" role="status">
                                        <span class="visually-hidden">Loading...</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-7">
                            <div id="wasteReportMap" style="height: 450px; border-radius: 8px; border: 3px solid #27ae60; background-color: #e8f5e9;"></div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-success" data-bs-dismiss="modal">✕ Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"></script>
    <script>
        function escapeHtml(text) {
            var map = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            };
            return text.replace(/[&<>\"']/g, function(m) { return map[m]; });
        }

        let reportMap = null;
        let reportMapMarker = null;

        function viewWasteReport(letterId) {
            document.getElementById('wasteReportContent').innerHTML = `
                <div class="text-center text-muted py-5">
                    <div class="spinner-border text-success" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-3">Loading report details...</p>
                </div>
            `;

            fetch('get_letter_details.php?id=' + letterId)
                .then(r => {
                    if (!r.ok) throw new Error('Network error ' + r.status);
                    return r.json();
                })
                .then(data => {
                    let html = `
                        <div style="background-color: #e8f5e9; padding: 15px; border-radius: 8px; margin-bottom: 15px;">
                            <h6 class="text-success fw-bold mb-3">📋 Report Information</h6>
                            <div class="mb-2">
                                <label class="small text-muted">Subject</label>
                                <p class="fw-bold text-dark">${escapeHtml(data.subject)}</p>
                            </div>
                            <div class="mb-2">
                                <label class="small text-muted">Status</label>
                                <p class="fw-bold"><span class="badge ${data.status === 'unread' ? 'bg-warning text-dark' : 'bg-success'}">${escapeHtml(data.status)}</span></p>
                            </div>
                            <div class="mb-2">
                                <label class="small text-muted">Priority</label>
                                <p class="fw-bold"><span class="badge ${data.priority === 'High' ? 'bg-danger' : data.priority === 'Normal' ? 'bg-info' : 'bg-secondary'}">${escapeHtml(data.priority)}</span></p>
                            </div>
                            <div class="mb-2">
                                <label class="small text-muted">Date Sent</label>
                                <p class="fw-bold text-dark">${escapeHtml(data.date_sent)}</p>
                            </div>
                        </div>

                        <div style="background-color: #e8f5e9; padding: 15px; border-radius: 8px; margin-bottom: 15px;">
                            <h6 class="text-success fw-bold mb-3">📍 Location Details</h6>
                            <div class="mb-2">
                                <label class="small text-muted">Address</label>
                                <p class="fw-bold text-dark">${escapeHtml(data.resident_location)}</p>
                            </div>
                            <div class="mb-2">
                                <label class="small text-muted">Contact Number</label>
                                <p class="fw-bold text-dark">${escapeHtml(data.resident_contact)}</p>
                            </div>
                        </div>

                        <div style="background-color: #e8f5e9; padding: 15px; border-radius: 8px;">
                            <h6 class="text-success fw-bold mb-3">💬 Message</h6>
                            <p class="text-dark" style="white-space: pre-wrap; word-break: break-word;">${escapeHtml(data.message)}</p>
                            ${data.photo_path ? `<img src="${escapeHtml(data.photo_path)}" class="img-fluid mt-3 rounded" style="max-width: 100%; border: 2px solid #27ae60;">` : ''}
                        </div>
                    `;
                    document.getElementById('wasteReportContent').innerHTML = html;

                    // Initialize map
                    if (!reportMap) {
                        reportMap = L.map('wasteReportMap').setView([data.latitude || 10.6896, data.longitude || 124.0453], 13);
                        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(reportMap);
                    }
                    if (reportMapMarker) reportMap.removeLayer(reportMapMarker);
                    reportMapMarker = L.marker([data.latitude || 10.6896, data.longitude || 124.0453]).addTo(reportMap)
                        .bindPopup(`<strong>${escapeHtml(data.subject)}</strong><br>${escapeHtml(data.resident_location)}`).openPopup();
                })
                .catch(err => {
                    document.getElementById('wasteReportContent').innerHTML = `
                        <div class="alert alert-danger text-center">
                            <p class="mb-0">❌ Error! Could not load details.</p>
                            <small>${escapeHtml(err.message)}</small>
                        </div>
                    `;
                });
        }
    </script>
</body>
</html>
