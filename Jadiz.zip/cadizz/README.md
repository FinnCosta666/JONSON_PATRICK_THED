# 🏡 Villa Estates Waste Management System

A comprehensive web-based waste management system designed for villa communities. This system allows administrators to manage waste collection schedules by blocks and enables residents to view schedules, request appointments, send feedback, and communicate with administrators.

## ✨ Features

### Admin Features
- **Dashboard** - Overview of residents, blocks, schedules, appointments, feedback, and messages
- **Collection Scheduling** - Create and manage waste collection schedules for each block
  - Block 1-3 (Houses 1-3)
  - Block 4-6 (Houses 4-6)
  - Block 7-9 (Houses 7-9)
  - Block 10-14 (Houses 10-14)
- **Resident Management** - Add and manage resident accounts
- **Appointment Management** - View and manage special collection appointments
- **Feedback System** - Receive and respond to resident feedback and complaints
- **Messaging** - Direct communication with residents

### Resident Features
- **Villa-Themed Dashboard** - Beautiful villa background with personalized welcome
- **Schedule Viewer** - View collection schedules for their block and all blocks
- **Appointment Requests** - Request special waste collection appointments
- **Feedback System** - Send feedback, complaints, suggestions with ratings
- **Messaging** - Direct communication with administrators

## 🔧 Installation

### Prerequisites
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Web server (Apache/Nginx)

### Setup Steps

1. **Create Database**
   ```sql
   CREATE DATABASE waste_management_system;
   ```

2. **Import Database Schema**
   ```bash
   mysql -u root -p waste_management_system < waste_management_system.sql
   ```

3. **Configure Database Connection**
   Edit `includes/db_connect.php` with your database credentials:
   ```php
   $servername = "localhost";
   $username   = "root";
   $password   = "";
   $database   = "waste_management_system";
   ```

4. **Deploy Files**
   Copy all files to your web server directory (e.g., `htdocs/waste_management/`)

5. **Access the System**
   - Admin Login: `http://localhost/waste_management/auth/login.php`
   - Resident Login: `http://localhost/waste_management/auth/resident_login.php`

## 🔑 Default Login Credentials

### Admin
- **Username:** admin
- **Password:** admin123

### Residents (All use password: `password123`)
| Email | Block | House |
|-------|-------|-------|
| juan@villa-estates.com | Block 1-3 | House 1 |
| maria@villa-estates.com | Block 1-3 | House 2 |
| pedro@villa-estates.com | Block 4-6 | House 4 |
| ana@villa-estates.com | Block 7-9 | House 7 |
| luis@villa-estates.com | Block 10-14 | House 10 |

## 📁 File Structure

```
waste_management_system/
├── auth/
│   ├── login.php              # Admin login page
│   ├── logout.php             # Admin logout
│   ├── resident_login.php     # Resident login page
│   └── resident_logout.php    # Resident logout
├── includes/
│   ├── auth_check.php         # Admin authentication check
│   ├── resident_auth_check.php # Resident authentication check
│   └── db_connect.php         # Database connection
├── assets/
│   └── images/
│       └── villa-bg.jpg       # Villa-themed background
├── index.php                  # Admin dashboard
├── header.php                 # Admin header template
├── footer.php                 # Footer template
├── residents.php              # Resident management
├── schedules.php              # Schedule management
├── appointments.php           # Appointment management
├── feedback.php               # Admin feedback management
├── messages.php               # Admin messaging
├── resident_dashboard.php     # Resident dashboard
├── resident_schedules.php     # Resident schedule viewer
├── resident_appointments.php  # Resident appointment requests
├── resident_feedback.php      # Resident feedback sender
├── resident_messages.php      # Resident messaging
├── waste_management_system.sql # Database schema
└── README.md                  # This file
```

## 🎨 Design Features

### Villa Theme
- Beautiful Mediterranean villa background image
- Golden accent colors for premium feel
- Glass-morphism effects on cards
- Responsive design for all devices

### Color Scheme
- **Primary:** Green (#27ae60) - Represents eco-friendliness
- **Accent:** Gold (#d4af37) - Represents villa luxury
- **Background:** Villa estate image with overlay

## 📱 Responsive Design

The system is fully responsive and works on:
- Desktop computers
- Tablets
- Mobile phones

## 🔒 Security Features

- Password hashing with bcrypt
- Session-based authentication
- SQL injection prevention with prepared statements
- XSS protection with htmlspecialchars

## 🚀 Future Enhancements

- Email notifications for appointments and feedback responses
- SMS notifications for collection reminders
- Mobile app version
- Analytics dashboard with charts
- Export reports to PDF/Excel
- Multi-language support

## 📝 License

This project is open source and available for personal and commercial use.

## 🙏 Credits

Developed for Villa Estates Community

---

**Keeping Our Community Clean & Green 🌿**
