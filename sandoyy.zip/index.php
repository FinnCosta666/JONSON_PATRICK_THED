<?php
include("includes/auth_check.php");
include("db_connect.php");
include("header.php");
// Leaflet CSS for map
 echo '<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" crossorigin=""/>';
 // Bootstrap Icons for dashboard
 echo '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" crossorigin="anonymous"/>'; 
?>
<!-- custom styles moved to assets/css/style.css -->
<?php

?>



<!-- Background Shapes -->
<div class="bg-shape green"></div>
<div class="bg-shape light"></div>

<div class="container-fluid px-4">

    <!-- HERO BANNER -->
    <div class="hero text-center">
        <h1>Waste Management System</h1>
        <p class="lead">Welcome to the Dalipuga Cleanup Tracking Dashboard</p>
    </div>

    <!-- DASHBOARD CARDS -->
    <div class="row mt-5">

        <div class="col-md-4 mb-4">
            <div class="dashboard-card h-100">
                <div class="card-icon"><i class="bi bi-person-plus"></i></div>
                <h5>Add Resident</h5>
                <p>Register a new household into the system.</p>
                <a href="form.php" class="btn btn-outline-success stretched-link">
                    Open Form
                </a>
            </div>
        </div>

        <div class="col-md-4 mb-4">
            <div class="dashboard-card h-100">
                <div class="card-icon"><i class="bi bi-people"></i></div>
                <h5>View Residents</h5>
                <p>View and manage all registered households.</p>
                <a href="resident.php" class="btn btn-outline-primary stretched-link">
                    View List
                </a>
            </div>
        </div>
        <div class="col-md-4 mb-4">
            <div class="dashboard-card h-100">
                <div class="card-icon"><i class="bi bi-shield-lock"></i></div>
                <h5>Administrators</h5>
                <p>Manage system administrators and access.</p>
                <a href="admins.php" class="btn btn-outline-secondary stretched-link">
                    View Admins
                </a>
            </div>
        </div>

    </div>

    <!-- MAP: Residents Who Sent Letters -->
    <div class="row mt-4">
        <div class="col-12">
            <div class="dashboard-card">
                <h5>Residents Who Sent Letters — Map</h5>
                <p class="text-muted">Markers show location for each submitted letter (approximate).</p>
                <div id="lettersMap" style="height:420px;border-radius:8px;overflow:hidden;margin-top:14px"></div>
                <div class="small text-muted mt-2">Note: locations are approximated from the address text.</div>
            </div>
        </div>
    </div>

    <!-- Cleanup appointment schedule -->
    <section class="schedule-section my-5">
      <h2 class="mb-3"><i class="bi bi-calendar-check-fill"></i>
        Cleanup Appointment Schedule
      </h2>
      <p class="text-muted">Our cleanup team operates on the following schedule:</p>

      <div class="row gy-4">
        <div class="col-md-4">
          <div class="dashboard-card h-100 text-start">
            <span class="badge bg-primary mb-2">Monday</span>
            <h5 class="mb-1">8:00 AM – 12:00 PM</h5>
            <small class="text-muted">All zones available for cleanup</small>
          </div>
        </div>
        <div class="col-md-4">
          <div class="dashboard-card h-100 text-start">
            <span class="badge bg-purple mb-2">Wednesday</span>
            <h5 class="mb-1">9:00 AM – 1:00 PM</h5>
            <small class="text-muted">All zones available for cleanup</small>
          </div>
        </div>
        <div class="col-md-4">
          <div class="dashboard-card h-100 text-start">
            <span class="badge bg-success mb-2">Saturday</span>
            <h5 class="mb-1">7:00 AM – 12:00 PM</h5>
            <small class="text-muted">All zones available for cleanup</small>
          </div>
        </div>
      </div>

      <div class="alert alert-info mt-4 d-flex align-items-center">
        <i class="bi bi-lightbulb-fill me-2"></i>
        <div>Tip: Send us a letter with your location and waste type to schedule a pickup during these times!</div>
      </div>
    </section>

</div>

<?php include("footer.php"); ?>
<!-- Leaflet JS and live map script -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" crossorigin=""></script>
<script>
    // Live letters map: fetch letters and geocode addresses (client-side cache)
    // center map on Dalipuga, Lanao del Norte
    // center map on Dalipuga, Lanao del Norte
    const map = L.map('lettersMap', {scrollWheelZoom: true}).setView([8.472, 125.729], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);

    let markersLayer = L.layerGroup().addTo(map);

    // localStorage cache prefix
    const CACHE_PREFIX = 'geo_cache_v1:';

    async function geocodeAddress(address) {
        const key = CACHE_PREFIX + address;
        try {
            const cached = localStorage.getItem(key);
            if (cached) return JSON.parse(cached);
        } catch (e) {
            // ignore
        }

        // Use Nominatim (rate-limit friendly: don't call too frequently)
        const url = 'https://nominatim.openstreetmap.org/search?format=json&q=' + encodeURIComponent(address) + '&limit=1&addressdetails=0';
        try {
            const res = await fetch(url, {headers: {'Accept': 'application/json'}});
            if (!res.ok) return null;
            const data = await res.json();
            if (data && data.length > 0) {
                const lat = parseFloat(data[0].lat);
                const lon = parseFloat(data[0].lon);
                const obj = {lat, lon};
                try { localStorage.setItem(key, JSON.stringify(obj)); } catch(e){}
                return obj;
            }
        } catch (e) {
            console.error('Geocode error', e);
        }
        return null;
    }

    async function updateMarkers() {
        try {
            const res = await fetch('get_letters_locations.php');
            if (!res.ok) return;
            const letters = await res.json();

            // clear markers
            markersLayer.clearLayers();

            const bounds = [];

            for (const l of letters) {
                // Prefer server-provided coordinates
                let lat = l.latitude || l.lat || null;
                let lon = l.longitude || l.lon || null;

                if (lat && lon) {
                    lat = parseFloat(lat); lon = parseFloat(lon);
                } else {
                    const address = l.resident_location || l.location || '';
                    if (!address) continue;

                    // try localStorage cache by address
                    let coord = null;
                    try { coord = JSON.parse(localStorage.getItem(CACHE_PREFIX + address)); } catch(e) { coord = null; }

                    if (coord) {
                        lat = coord.lat; lon = coord.lon;
                    } else {
                        const g = await geocodeAddress(address);
                        if (g) {
                            lat = g.lat; lon = g.lon;
                            try { localStorage.setItem(CACHE_PREFIX + address, JSON.stringify(g)); } catch(e){}
                        }
                        await new Promise(r => setTimeout(r, 800));
                    }
                }

                if (lat && lon) {
                    const marker = L.marker([lat, lon]);
                    const popup = `<strong>${escapeHtml(l.resident_name || l.name || l.username || '')}</strong><br>${escapeHtml(l.resident_location || '')}<br><small>${escapeHtml(l.subject || '')} ${escapeHtml(l.date_sent || '')}</small>`;
                    marker.bindPopup(popup);
                    markersLayer.addLayer(marker);
                    bounds.push([lat, lon]);
                }
            }

            if (bounds.length) {
                map.fitBounds(bounds, {padding: [40,40]});
            }
        } catch (e) {
            console.error('Update markers failed', e);
        }
    }

    function escapeHtml(s){ return String(s||'').replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c])); }

    // Initial load
    updateMarkers();
    // Poll every 20 seconds
    setInterval(updateMarkers, 20000);
</script>
