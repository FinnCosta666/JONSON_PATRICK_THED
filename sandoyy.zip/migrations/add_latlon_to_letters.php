<?php
// Run this once to add latitude/longitude columns to `letters` table if missing.
include(__DIR__ . '/../includes/db_connect.php');

// Check columns
$res = $conn->query("SHOW COLUMNS FROM letters LIKE 'latitude'");
$hasLat = ($res && $res->num_rows > 0);
$res = $conn->query("SHOW COLUMNS FROM letters LIKE 'longitude'");
$hasLon = ($res && $res->num_rows > 0);

if ($hasLat && $hasLon) {
    echo "Table already has latitude and longitude columns.\n";
    exit;
}

$sqls = [];
if (!$hasLat) $sqls[] = "ALTER TABLE letters ADD COLUMN latitude DECIMAL(10,7) NULL AFTER resident_location";
if (!$hasLon) $sqls[] = "ALTER TABLE letters ADD COLUMN longitude DECIMAL(10,7) NULL AFTER latitude";

foreach ($sqls as $sql) {
    if ($conn->query($sql) === TRUE) {
        echo "Executed: $sql\n";
    } else {
        echo "Error executing: $sql - " . $conn->error . "\n";
    }
}

echo "Done.\n";
?>