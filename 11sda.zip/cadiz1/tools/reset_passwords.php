<?php
/**
 * Reset all accounts to known default credentials.
 *
 * - Admins will be set to the usernames / passwords listed below.
 * - All residents will have their password changed to the same default.
 *
 * Run this script once from the browser or CLI, then delete it to avoid abuse.
 */

require_once __DIR__ . "/../includes/db_connect.php";

$admins = [
    'admin'  => 'admin123',
    'Jadiz'  => 'Talongis',
];
$residentDefault = 'password123';

$output = [];

foreach ($admins as $user => $pass) {
    $hash = password_hash($pass, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("UPDATE admin SET Password = ? WHERE Username = ?");
    $stmt->bind_param('ss', $hash, $user);
    if ($stmt->execute()) {
        $output[] = "Updated admin '{$user}'";
    } else {
        $output[] = "Failed to update admin '{$user}': " . $stmt->error;
    }
    $stmt->close();
}

// update all residents in one go
$hash = password_hash($residentDefault, PASSWORD_DEFAULT);
$resStmt = $conn->prepare("UPDATE residents SET password = ?");
$resStmt->bind_param('s', $hash);
if ($resStmt->execute()) {
    $output[] = "Updated all residents to default password";
} else {
    $output[] = "Failed updating residents: " . $resStmt->error;
}
$resStmt->close();

// display results
header('Content-Type: text/plain; charset=utf-8');
echo "Reset complete.\n";
echo implode("\n", $output);

// Reminder to delete this file
echo "\n\n*** Please remove or secure this script after use! ***\n";
