<?php
include("includes/auth_check.php");
include("db_connect.php");
include("header.php");
?>

<style>
    /* ===== BACKGROUND DESIGN ===== */
    body {
        background: linear-gradient(135deg, #d4eee5 0%, #e8f8f0 50%, #c8e6c9 100%);
        position: relative;
        overflow-x: hidden;
        min-height: 100vh;
    }

    /* Decorative shapes */
    .bg-shape {
        position: absolute;
        border-radius: 50%;
        filter: blur(80px);
        opacity: 0.6;
        z-index: -1;
    }

    .bg-shape.green {
        width: 400px;
        height: 400px;
        background: #27ae60;
        top: -150px;
        left: -150px;
    }

    .bg-shape.light {
        width: 350px;
        height: 350px;
        background: #52b788;
        bottom: -150px;
        right: -150px;
    }

    /* ===== CONTENT AREA ===== */
    .container {
        position: relative;
        z-index: 1;
    }

    /* ===== PAGE TITLE ===== */
    .page-title {
        margin-top: 40px;
    }

    .page-title h1 {
        font-weight: 700;
        color: #27ae60;
    }

    .page-title p {
        font-size: 1.1rem;
        color: #6c757d;
    }

    /* ===== CARDS STYLING ===== */
    .card {
        background: linear-gradient(135deg, #f0f9f7 0%, #ffffff 100%);
        border: 2px solid #e8f5e9 !important;
        border-radius: 12px;
        box-shadow: 0 8px 25px rgba(39, 174, 96, 0.1);
    }

    .card-header {
        background: linear-gradient(135deg, #27ae60 0%, #52b788 100%) !important;
        color: white !important;
        border-bottom: none;
        border-radius: 10px 10px 0 0;
    }

    .btn-success {
        background: linear-gradient(135deg, #27ae60 0%, #229954 100%);
        border: none;
    }

    .btn-success:hover {
        background: linear-gradient(135deg, #229954 0%, #1e7e34 100%);
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(39, 174, 96, 0.3);
    }
</style>

<!-- Background Shapes -->
<div class="bg-shape green"></div>
<div class="bg-shape light"></div>

<div class="container">
    <!-- PAGE TITLE -->
    <div class="page-title d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 mb-1">👥 Residents</h1>
            <p class="text-muted mb-0">List of registered residents in the system</p>
        </div>
        <a href="form.php" class="btn btn-success">
            ➕ Add New Resident
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="card-header">
            <h6 class="mb-0 fw-bold">👤 Resident Records</h6>
        </div>

        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light text-uppercase small">
                        <tr>
                            <th>ID</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Address</th>
                            <th>Contact Number</th>
                            <th>Date Added</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sql = "SELECT id, first_name, last_name, location, contact_number, date_added 
                                FROM residents 
                                ORDER BY id DESC";
                        $result = $conn->query($sql);

                        if ($result && $result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                ?>
                                <tr>
                                    <td><?= htmlspecialchars($row['id']) ?></td>
                                    <td class="fw-semibold"><?= htmlspecialchars($row['first_name']) ?></td>
                                    <td class="fw-semibold"><?= htmlspecialchars($row['last_name']) ?></td>
                                    <td><?= htmlspecialchars($row['location']) ?></td>
                                    <td><?= htmlspecialchars($row['contact_number']) ?></td>
                                    <td class="text-muted small">
                                        <?= htmlspecialchars(date("M d, Y", strtotime($row['date_added']))) ?>
                                    </td>
                                </tr>
                                <?php
                            }
                        } else {
                            ?>
                            <tr>
                                <td colspan="6" class="text-center py-5 text-muted">
                                    No resident records found.
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include("footer.php"); ?>
