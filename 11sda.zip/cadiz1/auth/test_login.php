<?php
include("../includes/db_connect.php");

echo "<h2>🔍 Database Login Test</h2>";

// Test Admin 1
echo "<h3>Testing Admin 1 (admin / admin123):</h3>";
$stmt = $conn->prepare("SELECT Admin_Id, Username, Email, Password FROM admin WHERE LOWER(Username) = LOWER(?)");
$username = "admin";
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo "✅ Found admin: " . $row['Username'] . "<br>";
    echo "Password hash: " . substr($row['Password'], 0, 30) . "...<br>";
    $test_password = "admin123";
    if (password_verify($test_password, $row['Password'])) {
        echo "✅ Password verification: SUCCESS<br>";
    } else {
        echo "❌ Password verification: FAILED<br>";
    }
} else {
    echo "❌ Admin not found in database<br>";
}
$stmt->close();

echo "<hr>";

// Test Admin 2
echo "<h3>Testing Admin 2 (Jadiz / Talongis):</h3>";
$stmt = $conn->prepare("SELECT Admin_Id, Username, Email, Password FROM admin WHERE LOWER(Username) = LOWER(?)");
$username = "Jadiz";
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo "✅ Found admin: " . $row['Username'] . "<br>";
    echo "Password hash: " . substr($row['Password'], 0, 30) . "...<br>";
    $test_password = "Talongis";
    if (password_verify($test_password, $row['Password'])) {
        echo "✅ Password verification: SUCCESS<br>";
    } else {
        echo "❌ Password verification: FAILED<br>";
    }
} else {
    echo "❌ Admin not found in database<br>";
}
$stmt->close();

echo "<hr>";

// Show all admins in database
echo "<h3>All Admins in Database:</h3>";
$result = $conn->query("SELECT Admin_Id, Username, Email FROM admin");
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "ID: " . $row['Admin_Id'] . " | Username: " . $row['Username'] . " | Email: " . $row['Email'] . "<br>";
    }
} else {
    echo "No admins found in database<br>";
}

echo "<hr>";
echo "<a href='login.php'>← Back to Login</a>";
?>
