<?php
include("includes/resident_auth_check.php");
include("includes/db_connect.php");

// Get resident information
$stmt = $conn->prepare("SELECT r.*, b.block_name, b.block_range 
    FROM residents r 
    LEFT JOIN blocks b ON r.block_id = b.id 
    WHERE r.id = ?");
$stmt->bind_param("i", $_SESSION['resident_id']);
$stmt->execute();
$resident = $stmt->get_result()->fetch_assoc();

// Get current day
$current_day = date('l');

// Get all blocks' schedules for comparison
$all_schedules_result = $conn->query("SELECT s.*, b.block_name, b.block_range 
    FROM schedules s 
    JOIN blocks b ON s.block_id = b.id 
    WHERE s.status = 'active'
    ORDER BY b.id, FIELD(s.collection_day, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'), 
    s.collection_time_start ASC");

// Get resident's block schedules
$my_schedules_result = $conn->query("SELECT s.*, b.block_name 
    FROM schedules s 
    JOIN blocks b ON s.block_id = b.id 
    WHERE s.block_id = {$resident['block_id']} AND s.status = 'active'
    ORDER BY FIELD(s.collection_day, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'), 
    s.collection_time_start ASC");

// Get unread messages count
$messages_count = $conn->query("SELECT COUNT(*) as count FROM messages WHERE resident_id = {$_SESSION['resident_id']} AND sender_type = 'admin' AND is_read = 0")->fetch_assoc()['count'];

// Days of week
$days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Collection Schedules - Villa Castena Waste Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #27ae60;
            --primary-dark: #229954;
            --primary-light: #e8f5e9;
            --villa-gold: #d4af37;
            --villa-brown: #8b6914;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            background: linear-gradient(135deg, rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.2)),
                        url('assets/images/villa-bg.jpg') no-repeat center center fixed;
            background-size: cover;
            position: relative;
        }

        /* Villa-themed Navbar */
        .navbar-villa {
            background: linear-gradient(135deg, rgba(39, 174, 96, 0.95) 0%, rgba(34, 153, 84, 0.95) 100%);
            backdrop-filter: blur(10px);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.2);
            padding: 15px 0;
            border-bottom: 2px solid var(--villa-gold);
        }

        .navbar-villa .navbar-brand {
            font-weight: 700;
            font-size: 1.3rem;
            color: white !important;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
        }

        .navbar-villa .nav-link {
            color: rgba(255, 255, 255, 0.9) !important;
            font-weight: 500;
            padding: 10px 15px !important;
            border-radius: 8px;
            transition: all 0.3s ease;
            margin: 0 3px;
        }

        .navbar-villa .nav-link:hover {
            background: rgba(255, 255, 255, 0.2);
            color: white !important;
        }

        .navbar-villa .nav-link.active {
            background: rgba(255, 255, 255, 0.25);
            color: white !important;
        }

        /* Main Content Container */
        .villa-container {
            padding: 30px;
        }

        /* Villa Card Style */
        .villa-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.3);
            overflow: hidden;
            margin-bottom: 25px;
        }

        .villa-card-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
            color: white;
            padding: 20px 25px;
            border-bottom: 3px solid var(--villa-gold);
        }

        .villa-card-header h5 {
            margin: 0;
            font-weight: 600;
        }

        .villa-card-body {
            padding: 25px;
        }

        /* Schedule Card */
        .schedule-card {
            background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
            border-left: 5px solid var(--primary-color);
            transition: all 0.3s ease;
        }

        .schedule-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
        }

        .schedule-card.my-block {
            border-left-color: var(--villa-gold);
            background: linear-gradient(135deg, #fff9e6 0%, #ffffff 100%);
        }

        .schedule-card .block-name {
            font-size: 1.2rem;
            font-weight: 700;
            color: #2c3e50;
        }

        .schedule-card .day {
            display: inline-block;
            background: var(--primary-light);
            color: var(--primary-color);
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .schedule-card .time {
            color: #7f8c8d;
            font-size: 1rem;
            margin-bottom: 10px;
        }

        .schedule-card .waste-type {
            display: inline-block;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
            color: white;
            padding: 8px 20px;
            border-radius: 25px;
            font-size: 0.9rem;
            font-weight: 600;
        }

        .schedule-card .notes {
            color: #7f8c8d;
            font-size: 0.9rem;
            margin-top: 10px;
        }

        .my-block-badge {
            display: inline-block;
            background: linear-gradient(135deg, var(--villa-gold) 0%, var(--villa-brown) 100%);
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            margin-left: 10px;
        }

        .today-badge {
            display: inline-block;
            background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            margin-left: 10px;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }

        /* Day Tabs */
        .day-tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 25px;
            flex-wrap: wrap;
        }

        .day-tab {
            padding: 10px 20px;
            border-radius: 25px;
            background: white;
            border: 2px solid #e8f5e9;
            color: #7f8c8d;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .day-tab:hover {
            border-color: var(--primary-color);
            color: var(--primary-color);
        }

        .day-tab.active {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
            border-color: var(--primary-color);
            color: white;
        }

        .day-tab.today {
            border-color: #e74c3c;
            color: #e74c3c;
        }

        .day-tab.today.active {
            background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
            border-color: #e74c3c;
            color: white;
        }

        /* Legend */
        .legend-item {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 10px;
        }

        .legend-color {
            width: 20px;
            height: 20px;
            border-radius: 5px;
        }

        /* Footer */
        .villa-footer {
            background: rgba(44, 62, 80, 0.95);
            color: white;
            padding: 20px;
            text-align: center;
            margin-top: 30px;
            border-top: 2px solid var(--villa-gold);
        }

        .villa-footer small {
            color: rgba(255, 255, 255, 0.7);
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-villa">
        <div class="container-fluid px-4">
            <a class="navbar-brand" href="resident_dashboard.php">
                <i class="bi bi-house-heart-fill me-2"></i>Villa Castena
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#residentNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="residentNavbar">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="resident_dashboard.php"><i class="bi bi-speedometer2 me-1"></i> Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="resident_schedules.php"><i class="bi bi-calendar-week me-1"></i> Schedules</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="resident_appointments.php"><i class="bi bi-calendar-check me-1"></i> Appointments</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="resident_feedback.php"><i class="bi bi-chat-dots me-1"></i> Feedback</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="resident_messages.php"><i class="bi bi-envelope me-1"></i> Messages
                            <?php if ($messages_count > 0): ?>
                                <span class="badge bg-danger ms-1"><?php echo $messages_count; ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="auth/resident_change_password.php"><i class="bi bi-key me-1"></i> Change Password</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="auth/resident_logout.php"><i class="bi bi-box-arrow-right me-1"></i> Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="villa-container">
        <!-- Header -->
        <div class="row mb-4">
            <div class="col-12">
                <h1 class="text-white"><i class="bi bi-calendar-week me-2"></i>Collection Schedules</h1>
                <p class="text-white-50">View waste collection schedules for all blocks</p>
            </div>
        </div>

        <!-- Legend -->
        <div class="villa-card mb-4">
            <div class="villa-card-body">
                <div class="row">
                    <div class="col-md-4">
                        <div class="legend-item">
                            <div class="legend-color" style="background: var(--villa-gold);"></div>
                            <span>Your Block (<?php echo htmlspecialchars($resident['block_name']); ?>)</span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="legend-item">
                            <div class="legend-color" style="background: #e74c3c;"></div>
                            <span>Today (<?php echo $current_day; ?>)</span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="legend-item">
                            <div class="legend-color" style="background: var(--primary-color);"></div>
                            <span>Other Blocks</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Day Filter -->
        <div class="day-tabs">
            <div class="day-tab active" onclick="filterSchedules('all', this)">All Days</div>
            <?php foreach ($days as $day): ?>
                <div class="day-tab <?php echo ($day == $current_day) ? 'today' : ''; ?>" onclick="filterSchedules('<?php echo $day; ?>', this)">
                    <?php echo $day; ?>
                    <?php if ($day == $current_day): ?> (Today)<?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- My Block Schedules -->
        <div class="villa-card">
            <div class="villa-card-header">
                <h5><i class="bi bi-house-heart me-2"></i>Your Block Schedule - <?php echo htmlspecialchars($resident['block_name']); ?></h5>
            </div>
            <div class="villa-card-body">
                <div class="row" id="mySchedules">
                    <?php if ($my_schedules_result && $my_schedules_result->num_rows > 0): ?>
                        <?php 
                        $my_schedules_result->data_seek(0);
                        while ($schedule = $my_schedules_result->fetch_assoc()): 
                            $isToday = ($schedule['collection_day'] == $current_day);
                        ?>
                            <div class="col-md-6 schedule-item" data-day="<?php echo $schedule['collection_day']; ?>">
                                <div class="schedule-card my-block">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <span class="day"><?php echo $schedule['collection_day']; ?></span>
                                        <?php if ($isToday): ?>
                                            <span class="today-badge">TODAY</span>
                                        <?php else: ?>
                                            <span class="my-block-badge">YOUR BLOCK</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="time">
                                        <i class="bi bi-clock me-2"></i>
                                        <?php echo date('h:i A', strtotime($schedule['collection_time_start'])) . ' - ' . date('h:i A', strtotime($schedule['collection_time_end'])); ?>
                                    </div>
                                    <span class="waste-type">
                                        <i class="bi bi-trash me-2"></i><?php echo htmlspecialchars($schedule['waste_type']); ?>
                                    </span>
                                    <?php if ($schedule['notes']): ?>
                                        <div class="notes">
                                            <i class="bi bi-info-circle me-2"></i><?php echo htmlspecialchars($schedule['notes']); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="col-12 text-center py-4 text-muted">
                            <i class="bi bi-calendar-x fs-1"></i>
                            <p class="mt-2">No schedules available for your block.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- All Blocks Schedules -->
        <div class="villa-card">
            <div class="villa-card-header">
                <h5><i class="bi bi-grid-3x3-gap me-2"></i>All Blocks Schedule</h5>
            </div>
            <div class="villa-card-body">
                <div class="row" id="allSchedules">
                    <?php if ($all_schedules_result && $all_schedules_result->num_rows > 0): ?>
                        <?php 
                        $all_schedules_result->data_seek(0);
                        while ($schedule = $all_schedules_result->fetch_assoc()): 
                            $isMyBlock = ($schedule['block_id'] == $resident['block_id']);
                            $isToday = ($schedule['collection_day'] == $current_day);
                        ?>
                            <div class="col-md-6 col-lg-4 schedule-item" data-day="<?php echo $schedule['collection_day']; ?>">
                                <div class="schedule-card <?php echo $isMyBlock ? 'my-block' : ''; ?>">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <span class="day"><?php echo $schedule['collection_day']; ?></span>
                                        <?php if ($isToday && $isMyBlock): ?>
                                            <span class="today-badge">TODAY</span>
                                        <?php elseif ($isMyBlock): ?>
                                            <span class="my-block-badge">YOUR BLOCK</span>
                                        <?php elseif ($isToday): ?>
                                            <span class="today-badge">TODAY</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="block-name mb-2"><?php echo htmlspecialchars($schedule['block_name']); ?></div>
                                    <div class="time">
                                        <i class="bi bi-clock me-2"></i>
                                        <?php echo date('h:i A', strtotime($schedule['collection_time_start'])) . ' - ' . date('h:i A', strtotime($schedule['collection_time_end'])); ?>
                                    </div>
                                    <span class="waste-type">
                                        <i class="bi bi-trash me-2"></i><?php echo htmlspecialchars($schedule['waste_type']); ?>
                                    </span>
                                    <?php if ($schedule['notes']): ?>
                                        <div class="notes">
                                            <i class="bi bi-info-circle me-2"></i><?php echo htmlspecialchars($schedule['notes']); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="col-12 text-center py-4 text-muted">
                            <i class="bi bi-calendar-x fs-1"></i>
                            <p class="mt-2">No schedules available.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <div class="villa-footer">
        <div class="small">
            &copy; 2025 <strong>Villa Castena Waste Management</strong>
        </div>
        <div class="small">
            Keeping Our Community Clean & Green 🌿
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function filterSchedules(day, element) {
            // Update active tab
            document.querySelectorAll('.day-tab').forEach(tab => {
                tab.classList.remove('active');
            });
            element.classList.add('active');

            // Filter schedules
            document.querySelectorAll('.schedule-item').forEach(item => {
                if (day === 'all' || item.dataset.day === day) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        }

        // Auto-filter to today's schedule on page load
        document.addEventListener('DOMContentLoaded', function() {
            const todayTab = document.querySelector('.day-tab.today');
            if (todayTab) {
                // Optional: Uncomment to auto-show today's schedule on load
                // filterSchedules('<?php echo $current_day; ?>', todayTab);
            }
        });
    </script>
</body>
</html>
