<?php
ob_start();
header('Content-Type: application/json; charset=utf-8');

try {
    include("db_connect.php");
    
    if (!isset($_GET['id'])) {
        http_response_code(400);
        ob_end_clean();
        echo json_encode(array('error' => 'Letter ID is required'));
        exit;
    }
    
    $letter_id = intval($_GET['id']);
    
    if ($letter_id <= 0) {
        http_response_code(400);
        ob_end_clean();
        echo json_encode(array('error' => 'Invalid letter ID'));
        exit;
    }
    
    // if a resident is logged in, ensure they only fetch their own letter
    if (session_id() === '' && !headers_sent()) {
        @session_start();
    }
    $resident_id = null;
    if (isset($_SESSION['resident_id']) && is_numeric($_SESSION['resident_id'])) {
        $resident_id = intval($_SESSION['resident_id']);
    }
    
    if ($resident_id) {
        $stmt = $conn->prepare("SELECT id, resident_name, resident_email, resident_location, resident_contact, subject, message, date_sent, status, priority, latitude, longitude FROM letters WHERE id = ? AND resident_id = ?");
    } else {
        $stmt = $conn->prepare("SELECT id, resident_name, resident_email, resident_location, resident_contact, subject, message, date_sent, status, priority, latitude, longitude FROM letters WHERE id = ?");
    }
    
    if (!$stmt) {
        http_response_code(500);
        ob_end_clean();
        echo json_encode(array('error' => 'Database prepare error: ' . $conn->error));
        exit;
    }
    
    if ($resident_id) {
        $stmt->bind_param("ii", $letter_id, $resident_id);
    } else {
        $stmt->bind_param("i", $letter_id);
    }
    
    if (!$stmt->execute()) {
        http_response_code(500);
        ob_end_clean();
        echo json_encode(array('error' => 'Query execution error: ' . $stmt->error));
        $stmt->close();
        exit;
    }
    
    $result = $stmt->get_result();
    
    if (!$result) {
        http_response_code(500);
        ob_end_clean();
        echo json_encode(array('error' => 'Result fetch error: ' . $conn->error));
        $stmt->close();
        exit;
    }
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        ob_end_clean();
        echo json_encode($row);
    } else {
        http_response_code(404);
        ob_end_clean();
        echo json_encode(array('error' => 'Letter not found'));
    }
    
    $stmt->close();
    
} catch (Exception $e) {
    http_response_code(500);
    ob_end_clean();
    echo json_encode(array('error' => 'Server error'));
}
?>
