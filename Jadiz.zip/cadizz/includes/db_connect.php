<?php
$servername = "localhost";
$username   = "root";
$password   = "";
$database   = "waste_management_system";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("<div class='alert alert-danger'>❌ Connection failed: " . $conn->connect_error . "</div>");
}

// Set charset to handle special characters
$conn->set_charset("utf8mb4");
?>
