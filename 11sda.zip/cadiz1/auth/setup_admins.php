<?php
include("../includes/db_connect.php");

echo "<h2>🔧 Admin Account Setup Tool</h2>";

// Clear existing admins
echo "<p>Clearing existing admin accounts...</p>";
$conn->query("DELETE FROM admin");

// Insert fresh admin accounts
echo "<p>Inserting fresh admin accounts...</p>";

$admins = [
    ['username' => 'admin', 'email' => 'admin@example.com', 'phone' => '09170001111', 'password' => 'admin123'],
    ['username' => 'Jadiz', 'email' => 'jadiz@example.com', 'phone' => '09170002222', 'password' => 'Talongis']
];

foreach ($admins as $admin) {
    $hashed_password = password_hash($admin['password'], PASSWORD_BCRYPT);
    $stmt = $conn->prepare("INSERT INTO admin (Username, Email, Contact_Number, Password) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $admin['username'], $admin['email'], $admin['phone'], $hashed_password);
    
    if ($stmt->execute()) {
        echo "✅ Created admin: <strong>" . $admin['username'] . "</strong> (Password: " . $admin['password'] . ")<br>";
    } else {
        echo "❌ Failed to create admin: " . $admin['username'] . "<br>";
    }
    $stmt->close();
}

echo "<hr>";
echo "<h3>✅ Setup Complete!</h3>";
echo "<p><strong>Admin Login Credentials:</strong></p>";
echo "<ul>";
echo "<li>Username: <strong>admin</strong> | Password: <strong>admin123</strong></li>";
echo "<li>Username: <strong>Jadiz</strong> | Password: <strong>Talongis</strong></li>";
echo "</ul>";
echo "<hr>";
echo "<p><a href='login.php' class='btn btn-success' style='padding: 10px 20px; text-decoration: none; background: #27ae60; color: white; border-radius: 5px;'>← Go to Login</a></p>";
?>
