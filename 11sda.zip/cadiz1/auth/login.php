<?php
session_start();
include("../includes/db_connect.php");

$error = "";

// UNIFIED LOGIN - Try both admin and resident
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username_or_email = trim($_POST['username_or_email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (!empty($username_or_email) && !empty($password)) {
        $login_success = false;

        // Try Admin login first (case-insensitive)
        $stmt = $conn->prepare("SELECT Admin_Id, Username, Password FROM admin WHERE LOWER(Username) = LOWER(?)");
        $stmt->bind_param("s", $username_or_email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            // Try both hashed and plain password (fallback handles bad sample data)
            if (password_verify($password, $row['Password']) || $password === $row['Password']) {
                $_SESSION['admin_id'] = $row['Admin_Id'];
                $_SESSION['username'] = $row['Username'];
                $_SESSION['role'] = 'admin';
                $login_success = true;
                header("Location: ../index.php");
                exit;
            }
        }
        $stmt->close();

        // Try Resident login if admin login failed
        $stmt = $conn->prepare("SELECT id, first_name, last_name, email, password FROM residents WHERE email = ?");
        $stmt->bind_param("s", $username_or_email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            // Accept hashed or plaintext (in case sample data is wrong)
            if (password_verify($password, $row['password']) || $password === $row['password']) {
                $_SESSION['resident_id'] = $row['id'];
                $_SESSION['resident_email'] = $row['email'];
                $_SESSION['resident_name'] = $row['first_name'] . ' ' . $row['last_name'];
                $_SESSION['role'] = 'resident';
                $login_success = true;
                header("Location: ../resident_dashboard.php");
                exit;
            }
        }
        $stmt->close();

        // If both failed
        if (!$login_success) {
            $error = "Invalid username/email or password.";
        }
    } else {
        $error = "Please fill in all fields.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dalipuga Cleanup - Professional Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            font-family: 'Poppins', sans-serif;
        }

        body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #d4eee5 0%, #e8f8f0 50%, #c8e6c9 100%);
            position: relative;
            overflow: hidden;
        }

        /* Decorative background shapes */
        .bg-shape {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.6;
            z-index: 0;
        }

        .bg-shape.green {
            width: 400px;
            height: 400px;
            background: #27ae60;
            top: -150px;
            left: -150px;
        }

        .bg-shape.light {
            width: 350px;
            height: 350px;
            background: #52b788;
            bottom: -150px;
            right: -150px;
        }

        .login-wrapper {
            position: relative;
            z-index: 1;
            width: 100%;
        }

        .login-container {
            background: linear-gradient(135deg, #f0f9f7 0%, #ffffff 100%);
            border: 2px solid #e8f5e9;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(39, 174, 96, 0.15);
            padding: 50px 40px;
            width: 100%;
            max-width: 450px;
            margin: 0 auto;
        }

        .login-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .login-header .logo {
            font-size: 28px;
            margin-bottom: 15px;
        }

        .login-header h1 {
            color: #27ae60;
            font-weight: 700;
            font-size: 28px;
            margin-bottom: 8px;
        }

        .login-header p {
            color: #7f8c8d;
            font-size: 14px;
            margin: 0;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            color: #27ae60;
            font-weight: 600;
            font-size: 14px;
            margin-bottom: 8px;
            display: block;
        }

        .form-control {
            border: 2px solid #c8e6c9;
            border-radius: 8px;
            padding: 12px 16px;
            font-size: 14px;
            transition: all 0.3s ease;
            background: #ffffff;
        }

        .form-control:focus {
            border-color: #27ae60;
            box-shadow: 0 0 0 0.2rem rgba(39, 174, 96, 0.15);
            background: #ffffff;
        }

        .form-control::placeholder {
            color: #bdc3c7;
        }

        .btn-login {
            background: linear-gradient(135deg, #27ae60 0%, #229954 100%);
            border: none;
            color: white;
            padding: 14px 20px;
            width: 100%;
            border-radius: 8px;
            font-weight: 600;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 10px;
        }

        .btn-login:hover {
            background: linear-gradient(135deg, #229954 0%, #1e7e34 100%);
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(39, 174, 96, 0.25);
            color: white;
        }

        .btn-login:active {
            transform: translateY(0);
        }

        .alert {
            border-radius: 8px;
            border: 1px solid #ef5350;
            background: linear-gradient(135deg, #ffebee 0%, #ffcdd2 100%);
            color: #c62828;
            padding: 14px 16px;
            margin-bottom: 25px;
            font-size: 14px;
        }

        .alert strong {
            font-weight: 600;
        }

        .register-link {
            text-align: center;
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid #e8f5e9;
        }

        .register-link p {
            color: #7f8c8d;
            font-size: 14px;
            margin: 0 0 12px 0;
        }

        .register-link a {
            display: inline-block;
            background: #e8f5e9;
            color: #27ae60;
            padding: 10px 24px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s ease;
            border: 2px solid #e8f5e9;
        }

        .register-link a:hover {
            background: #27ae60;
            color: white;
            border-color: #27ae60;
        }

        .input-icon {
            position: relative;
        }

        .input-icon i {
            position: absolute;
            right: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: #27ae60;
        }

        @media (max-width: 480px) {
            .login-container {
                padding: 30px 20px;
                border-radius: 12px;
            }

            .login-header h1 {
                font-size: 24px;
            }

            .login-header .logo {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <div class="bg-shape green"></div>
    <div class="bg-shape light"></div>

    <div class="login-wrapper">
        <div class="login-container">
            <div class="login-header">
                <div class="logo">♻️</div>
                <h1>Dalipuga Cleanup</h1>
                <p>Management System</p>
            </div>

            <?php if (!empty($error)): ?>
                <div class="alert" role="alert">
                    <strong>⚠ Login Failed:</strong> <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label class="form-label" for="username_or_email">🔐 Username or Email</label>
                    <input 
                        type="text" 
                        id="username_or_email"
                        name="username_or_email" 
                        class="form-control" 
                        placeholder="Enter admin username or resident email"
                        required 
                        autofocus>
                </div>

                <div class="form-group">
                    <label class="form-label" for="password">🔑 Password</label>
                    <input 
                        type="password" 
                        id="password"
                        name="password" 
                        class="form-control" 
                        placeholder="Enter your password"
                        required>
                </div>

                <button type="submit" class="btn-login">Login</button>
            </form>

            <div class="register-link">
                <p>Don't have an account?</p>
                <a href="resident_register.php">Create Resident Account</a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
