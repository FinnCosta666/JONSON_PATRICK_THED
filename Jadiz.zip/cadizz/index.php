<?php
include("includes/auth_check.php");
include("includes/db_connect.php");
include("header.php");

// Get statistics
$stats = [
    'total_residents' => 0,
    'total_blocks' => 0,
    'total_schedules' => 0,
    'pending_appointments' => 0,
    'unread_feedback' => 0,
    'unread_messages' => 0
];

// Count residents
$result = $conn->query("SELECT COUNT(*) as count FROM residents WHERE status = 'active'");
if ($result) $stats['total_residents'] = $result->fetch_assoc()['count'];

// Count blocks
$result = $conn->query("SELECT COUNT(*) as count FROM blocks WHERE status = 'active'");
if ($result) $stats['total_blocks'] = $result->fetch_assoc()['count'];

// Count schedules
$result = $conn->query("SELECT COUNT(*) as count FROM schedules WHERE status = 'active'");
if ($result) $stats['total_schedules'] = $result->fetch_assoc()['count'];

// Count pending appointments
$result = $conn->query("SELECT COUNT(*) as count FROM appointments WHERE status = 'pending'");
if ($result) $stats['pending_appointments'] = $result->fetch_assoc()['count'];

// Count unread feedback
$result = $conn->query("SELECT COUNT(*) as count FROM feedback WHERE status = 'unread'");
if ($result) $stats['unread_feedback'] = $result->fetch_assoc()['count'];

// Count unread messages
$result = $conn->query("SELECT COUNT(*) as count FROM messages WHERE sender_type = 'resident' AND is_read = 0");
if ($result) $stats['unread_messages'] = $result->fetch_assoc()['count'];

// Get recent feedback
$recent_feedback = $conn->query("SELECT f.*, r.house_number, b.block_name 
    FROM feedback f 
    LEFT JOIN residents r ON f.resident_id = r.id 
    LEFT JOIN blocks b ON f.block_id = b.id 
    ORDER BY f.date_submitted DESC LIMIT 5");

// Get today's schedules
$today = date('l');
$today_schedules = $conn->query("SELECT s.*, b.block_name, b.block_range 
    FROM schedules s 
    JOIN blocks b ON s.block_id = b.id 
    WHERE s.collection_day = '$today' AND s.status = 'active'
    ORDER BY s.collection_time_start ASC");

// Get block distribution
$block_distribution = $conn->query("SELECT b.block_name, b.block_range, COUNT(r.id) as resident_count 
    FROM blocks b 
    LEFT JOIN residents r ON b.id = r.block_id AND r.status = 'active'
    WHERE b.status = 'active'
    GROUP BY b.id 
    ORDER BY b.id");
?>

<style>
    .dashboard-title {
        margin-bottom: 30px;
    }

    .dashboard-title h1 {
        font-weight: 700;
        color: #2c3e50;
    }

    .dashboard-title p {
        color: #7f8c8d;
    }

    .stats-card {
        background: white;
        border-radius: 15px;
        padding: 25px;
        text-align: center;
        box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
        transition: all 0.3s ease;
        border: 1px solid #e8f5e9;
    }

    .stats-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
    }

    .stats-card .icon {
        width: 60px;
        height: 60px;
        border-radius: 15px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 15px;
        font-size: 28px;
    }

    .stats-card .number {
        font-size: 2.2rem;
        font-weight: 700;
        color: #2c3e50;
    }

    .stats-card .label {
        color: #7f8c8d;
        font-size: 0.9rem;
    }

    .icon-residents { background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%); }
    .icon-blocks { background: linear-gradient(135deg, #f3e5f5 0%, #e1bee7 100%); }
    .icon-schedules { background: linear-gradient(135deg, #e8f5e9 0%, #c8e6c9 100%); }
    .icon-appointments { background: linear-gradient(135deg, #fff3e0 0%, #ffe0b2 100%); }
    .icon-feedback { background: linear-gradient(135deg, #ffebee 0%, #ffcdd2 100%); }
    .icon-messages { background: linear-gradient(135deg, #e0f7fa 0%, #b2ebf2 100%); }

    .schedule-item {
        background: #f8f9fa;
        border-radius: 10px;
        padding: 15px;
        margin-bottom: 10px;
        border-left: 4px solid #27ae60;
    }

    .schedule-item .time {
        font-weight: 600;
        color: #27ae60;
    }

    .schedule-item .block {
        font-weight: 600;
        color: #2c3e50;
    }

    .feedback-item {
        background: #f8f9fa;
        border-radius: 10px;
        padding: 15px;
        margin-bottom: 10px;
        border-left: 4px solid #f39c12;
    }

    .feedback-item.unread {
        border-left-color: #e74c3c;
        background: #fff5f5;
    }

    .block-card {
        background: white;
        border-radius: 15px;
        padding: 20px;
        text-align: center;
        box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
        transition: all 0.3s ease;
    }

    .block-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);
    }

    .block-card .block-number {
        font-size: 1.5rem;
        font-weight: 700;
        color: #27ae60;
    }

    .block-card .resident-count {
        color: #7f8c8d;
        font-size: 0.9rem;
    }
</style>

<div class="container">
    <!-- Header -->
    <div class="dashboard-title">
        <h1><i class="bi bi-speedometer2 me-2"></i>Admin Dashboard</h1>
        <p>Welcome back, <?php echo htmlspecialchars($_SESSION['admin_username']); ?>! Here's what's happening in Villa Estates.</p>
    </div>

    <!-- Statistics Cards -->
    <div class="row g-4 mb-4">
        <div class="col-md-4 col-lg-2">
            <div class="stats-card">
                <div class="icon icon-residents">👥</div>
                <div class="number"><?php echo $stats['total_residents']; ?></div>
                <div class="label">Total Residents</div>
            </div>
        </div>
        <div class="col-md-4 col-lg-2">
            <div class="stats-card">
                <div class="icon icon-blocks">🏘️</div>
                <div class="number"><?php echo $stats['total_blocks']; ?></div>
                <div class="label">Blocks</div>
            </div>
        </div>
        <div class="col-md-4 col-lg-2">
            <div class="stats-card">
                <div class="icon icon-schedules">📅</div>
                <div class="number"><?php echo $stats['total_schedules']; ?></div>
                <div class="label">Active Schedules</div>
            </div>
        </div>
        <div class="col-md-4 col-lg-2">
            <div class="stats-card">
                <div class="icon icon-appointments">📋</div>
                <div class="number"><?php echo $stats['pending_appointments']; ?></div>
                <div class="label">Pending Appointments</div>
            </div>
        </div>
        <div class="col-md-4 col-lg-2">
            <div class="stats-card">
                <div class="icon icon-feedback">💬</div>
                <div class="number"><?php echo $stats['unread_feedback']; ?></div>
                <div class="label">Unread Feedback</div>
            </div>
        </div>
        <div class="col-md-4 col-lg-2">
            <div class="stats-card">
                <div class="icon icon-messages">✉️</div>
                <div class="number"><?php echo $stats['unread_messages']; ?></div>
                <div class="label">Unread Messages</div>
            </div>
        </div>
    </div>

    <!-- Block Distribution & Today's Schedule -->
    <div class="row g-4 mb-4">
        <!-- Block Distribution -->
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-grid-3x3-gap me-2"></i>Block Distribution</h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <?php while ($block = $block_distribution->fetch_assoc()): ?>
                            <div class="col-6">
                                <div class="block-card">
                                    <div class="block-number"><?php echo htmlspecialchars($block['block_name']); ?></div>
                                    <small class="text-muted"><?php echo htmlspecialchars($block['block_range']); ?></small>
                                    <div class="resident-count mt-2">
                                        <strong><?php echo $block['resident_count']; ?></strong> Residents
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Today's Schedule -->
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-calendar-day me-2"></i>Today's Collection Schedule (<?php echo $today; ?>)</h5>
                </div>
                <div class="card-body">
                    <?php if ($today_schedules && $today_schedules->num_rows > 0): ?>
                        <?php while ($schedule = $today_schedules->fetch_assoc()): ?>
                            <div class="schedule-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <span class="block"><?php echo htmlspecialchars($schedule['block_name']); ?></span>
                                        <small class="text-muted d-block"><?php echo htmlspecialchars($schedule['waste_type']); ?></small>
                                    </div>
                                    <span class="time"><?php echo date('h:i A', strtotime($schedule['collection_time_start'])) . ' - ' . date('h:i A', strtotime($schedule['collection_time_end'])); ?></span>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="text-center py-4 text-muted">
                            <i class="bi bi-calendar-x fs-1"></i>
                            <p class="mt-2">No collections scheduled for today.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Feedback -->
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><i class="bi bi-chat-dots me-2"></i>Recent Feedback</h5>
            <a href="feedback.php" class="btn btn-light btn-sm">View All</a>
        </div>
        <div class="card-body">
            <?php if ($recent_feedback && $recent_feedback->num_rows > 0): ?>
                <?php while ($feedback = $recent_feedback->fetch_assoc()): ?>
                    <div class="feedback-item <?php echo ($feedback['status'] == 'unread') ? 'unread' : ''; ?>">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <strong><?php echo htmlspecialchars($feedback['resident_name']); ?></strong>
                                <small class="text-muted">| <?php echo htmlspecialchars($feedback['house_number'] ?? 'N/A'); ?> | <?php echo htmlspecialchars($feedback['block_name'] ?? 'N/A'); ?></small>
                                <p class="mb-1 mt-1"><?php echo htmlspecialchars($feedback['subject']); ?></p>
                                <small class="text-muted"><?php echo htmlspecialchars($feedback['feedback_type']); ?></small>
                            </div>
                            <div class="text-end">
                                <span class="badge bg-<?php echo ($feedback['status'] == 'unread') ? 'danger' : 'success'; ?>">
                                    <?php echo ucfirst($feedback['status']); ?>
                                </span>
                                <small class="text-muted d-block mt-1"><?php echo date('M d, Y', strtotime($feedback['date_submitted'])); ?></small>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="text-center py-4 text-muted">
                    <i class="bi bi-inbox fs-1"></i>
                    <p class="mt-2">No feedback received yet.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include("footer.php"); ?>
