<?php
include("includes/resident_auth_check.php");
include("includes/db_connect.php");

// Get resident information
$stmt = $conn->prepare("SELECT r.*, b.block_name, b.block_range 
    FROM residents r 
    LEFT JOIN blocks b ON r.block_id = b.id 
    WHERE r.id = ?");
$stmt->bind_param("i", $_SESSION['resident_id']);
$stmt->execute();
$resident = $stmt->get_result()->fetch_assoc();

// Get current day
$current_day = date('l'); // Returns full day name like "Friday"

// Get resident's block schedules for TODAY ONLY
$today_schedules_result = $conn->query("SELECT s.*, b.block_name 
    FROM schedules s 
    JOIN blocks b ON s.block_id = b.id 
    WHERE s.block_id = {$resident['block_id']} AND s.status = 'active' AND s.collection_day = '$current_day'
    ORDER BY s.collection_time_start ASC");

// Get announcements
$announcements_result = $conn->query("SELECT * FROM announcements WHERE status = 'active' ORDER BY date_created DESC LIMIT 5");

// Get unread messages count
$messages_count = $conn->query("SELECT COUNT(*) as count FROM messages WHERE resident_id = {$_SESSION['resident_id']} AND sender_type = 'admin' AND is_read = 0")->fetch_assoc()['count'];

// Get feedback count
$feedback_count = $conn->query("SELECT COUNT(*) as count FROM feedback WHERE resident_id = {$_SESSION['resident_id']}")->fetch_assoc()['count'];

// Get total schedules count for stats
$total_schedules_result = $conn->query("SELECT COUNT(*) as count FROM schedules WHERE block_id = {$resident['block_id']} AND status = 'active'");
$total_schedules = $total_schedules_result->fetch_assoc()['count'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resident Dashboard - Villa Castena Waste Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #27ae60;
            --primary-dark: #229954;
            --primary-light: #e8f5e9;
            --villa-gold: #d4af37;
            --villa-brown: #8b6914;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            background: linear-gradient(135deg, rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.2)),
                        url('assets/images/villa-bg.jpg') no-repeat center center fixed;
            background-size: cover;
            position: relative;
        }

        /* Villa-themed Navbar */
        .navbar-villa {
            background: linear-gradient(135deg, rgba(39, 174, 96, 0.95) 0%, rgba(34, 153, 84, 0.95) 100%);
            backdrop-filter: blur(10px);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.2);
            padding: 15px 0;
            border-bottom: 2px solid var(--villa-gold);
        }

        .navbar-villa .navbar-brand {
            font-weight: 700;
            font-size: 1.3rem;
            color: white !important;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
        }

        .navbar-villa .nav-link {
            color: rgba(255, 255, 255, 0.9) !important;
            font-weight: 500;
            padding: 10px 15px !important;
            border-radius: 8px;
            transition: all 0.3s ease;
            margin: 0 3px;
        }

        .navbar-villa .nav-link:hover {
            background: rgba(255, 255, 255, 0.2);
            color: white !important;
        }

        .navbar-villa .nav-link.active {
            background: rgba(255, 255, 255, 0.25);
            color: white !important;
        }

        /* Main Content Container */
        .villa-container {
            padding: 30px;
        }

        /* Villa Card Style */
        .villa-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.3);
            overflow: hidden;
            margin-bottom: 25px;
        }

        .villa-card-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
            color: white;
            padding: 20px 25px;
            border-bottom: 3px solid var(--villa-gold);
        }

        .villa-card-header h5 {
            margin: 0;
            font-weight: 600;
        }

        .villa-card-body {
            padding: 25px;
        }

        /* Welcome Banner */
        .welcome-banner {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.95) 0%, rgba(248, 249, 250, 0.95) 100%);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 25px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            border-left: 5px solid var(--villa-gold);
        }

        .welcome-banner h1 {
            color: #2c3e50;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .welcome-banner p {
            color: #7f8c8d;
            margin: 0;
        }

        .house-badge {
            display: inline-block;
            background: linear-gradient(135deg, var(--villa-gold) 0%, var(--villa-brown) 100%);
            color: white;
            padding: 8px 20px;
            border-radius: 25px;
            font-weight: 600;
            font-size: 0.9rem;
            margin-top: 10px;
        }

        /* Stats Cards */
        .stat-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            padding: 25px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.2);
        }

        .stat-card .icon {
            width: 60px;
            height: 60px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            font-size: 28px;
        }

        .stat-card .number {
            font-size: 2rem;
            font-weight: 700;
            color: #2c3e50;
        }

        .stat-card .label {
            color: #7f8c8d;
            font-size: 0.9rem;
        }

        /* Schedule Item */
        .schedule-item {
            background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 15px;
            border-left: 4px solid var(--primary-color);
            transition: all 0.3s ease;
        }

        .schedule-item:hover {
            transform: translateX(5px);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }

        .schedule-item .day {
            font-weight: 700;
            color: var(--primary-color);
            font-size: 1.1rem;
        }

        .schedule-item .time {
            color: #7f8c8d;
            font-size: 0.9rem;
        }

        .schedule-item .waste-type {
            display: inline-block;
            background: var(--primary-light);
            color: var(--primary-color);
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            margin-top: 10px;
        }

        /* No Schedule Alert */
        .no-schedule-alert {
            background: linear-gradient(135deg, #fff3e0 0%, #ffffff 100%);
            border-radius: 15px;
            padding: 30px;
            text-align: center;
            border-left: 4px solid var(--villa-gold);
        }

        .no-schedule-alert i {
            font-size: 3rem;
            color: var(--villa-gold);
            margin-bottom: 15px;
        }

        .no-schedule-alert h5 {
            color: #2c3e50;
            margin-bottom: 10px;
        }

        /* Announcement Item */
        .announcement-item {
            background: linear-gradient(135deg, #fff9e6 0%, #ffffff 100%);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 15px;
            border-left: 4px solid var(--villa-gold);
        }

        .announcement-item h6 {
            color: var(--villa-brown);
            font-weight: 600;
            margin-bottom: 8px;
        }

        .announcement-item p {
            color: #7f8c8d;
            margin: 0;
            font-size: 0.95rem;
        }

        .announcement-item .date {
            color: #95a5a6;
            font-size: 0.8rem;
            margin-top: 10px;
        }

        /* Profile Info */
        .profile-info-item {
            display: flex;
            padding: 15px 0;
            border-bottom: 1px solid #e8f5e9;
        }

        .profile-info-item:last-child {
            border-bottom: none;
        }

        .profile-info-item .label {
            width: 150px;
            color: var(--primary-color);
            font-weight: 600;
        }

        .profile-info-item .value {
            flex: 1;
            color: #2c3e50;
        }

        /* Quick Actions */
        .quick-action-btn {
            display: flex;
            align-items: center;
            gap: 15px;
            background: white;
            border-radius: 12px;
            padding: 20px;
            text-decoration: none;
            color: #2c3e50;
            transition: all 0.3s ease;
            border: 2px solid #e8f5e9;
            margin-bottom: 15px;
        }

        .quick-action-btn:hover {
            background: var(--primary-light);
            border-color: var(--primary-color);
            transform: translateX(5px);
            color: var(--primary-color);
        }

        .quick-action-btn .icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
        }

        .quick-action-btn .text h6 {
            margin: 0;
            font-weight: 600;
        }

        .quick-action-btn .text small {
            color: #7f8c8d;
        }

        /* Footer */
        .villa-footer {
            background: rgba(44, 62, 80, 0.95);
            color: white;
            padding: 20px;
            text-align: center;
            margin-top: 30px;
            border-top: 2px solid var(--villa-gold);
        }

        .villa-footer small {
            color: rgba(255, 255, 255, 0.7);
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-villa">
        <div class="container-fluid px-4">
            <a class="navbar-brand" href="resident_dashboard.php">
                <i class="bi bi-house-heart-fill me-2"></i>Villa Castena
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#residentNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="residentNavbar">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="resident_dashboard.php"><i class="bi bi-speedometer2 me-1"></i> Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="resident_schedules.php"><i class="bi bi-calendar-week me-1"></i> Schedules</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="resident_appointments.php"><i class="bi bi-calendar-check me-1"></i> Appointments</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="resident_feedback.php"><i class="bi bi-chat-dots me-1"></i> Feedback</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="resident_messages.php"><i class="bi bi-envelope me-1"></i> Messages
                            <?php if ($messages_count > 0): ?>
                                <span class="badge bg-danger ms-1"><?php echo $messages_count; ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="auth/resident_change_password.php"><i class="bi bi-key me-1"></i> Change Password</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="auth/resident_logout.php"><i class="bi bi-box-arrow-right me-1"></i> Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="villa-container">
        <!-- Welcome Banner -->
        <div class="welcome-banner">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1>Welcome Home, <?php echo htmlspecialchars($resident['first_name']); ?>! 🏡</h1>
                    <p>Your waste management portal for Villa Castena</p>
                </div>
                <div class="col-md-4 text-md-end">
                    <span class="house-badge">
                        <i class="bi bi-house-fill me-2"></i><?php echo htmlspecialchars($resident['house_number']); ?> | <?php echo htmlspecialchars($resident['block_name']); ?>
                    </span>
                </div>
            </div>
        </div>

        <!-- Stats Row -->
        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="icon" style="background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%);">📅</div>
                    <div class="number"><?php echo $total_schedules; ?></div>
                    <div class="label">Weekly Schedules</div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="icon" style="background: linear-gradient(135deg, #e8f5e9 0%, #c8e6c9 100%);">💬</div>
                    <div class="number"><?php echo $feedback_count; ?></div>
                    <div class="label">Feedback Sent</div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="icon" style="background: linear-gradient(135deg, #fff3e0 0%, #ffe0b2 100%);">✉️</div>
                    <div class="number"><?php echo $messages_count; ?></div>
                    <div class="label">New Messages</div>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Left Column -->
            <div class="col-lg-8">
                <!-- Today's Collection Schedule - ONLY SHOW IF THERE'S A SCHEDULE -->
                <?php if ($today_schedules_result && $today_schedules_result->num_rows > 0): ?>
                    <div class="villa-card">
                        <div class="villa-card-header d-flex justify-content-between align-items-center">
                            <h5><i class="bi bi-calendar-week me-2"></i>Today's Collection Schedule - <?php echo $current_day; ?></h5>
                            <a href="resident_schedules.php" class="btn btn-light btn-sm">View All</a>
                        </div>
                        <div class="villa-card-body">
                            <?php while ($schedule = $today_schedules_result->fetch_assoc()): ?>
                                <div class="schedule-item">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <div class="day"><?php echo $schedule['collection_day']; ?></div>
                                            <div class="time">
                                                <i class="bi bi-clock me-1"></i>
                                                <?php echo date('h:i A', strtotime($schedule['collection_time_start'])) . ' - ' . date('h:i A', strtotime($schedule['collection_time_end'])); ?>
                                            </div>
                                            <span class="waste-type"><?php echo htmlspecialchars($schedule['waste_type']); ?></span>
                                        </div>
                                    </div>
                                    <?php if ($schedule['notes']): ?>
                                        <small class="text-muted d-block mt-2">
                                            <i class="bi bi-info-circle me-1"></i><?php echo htmlspecialchars($schedule['notes']); ?>
                                        </small>
                                    <?php endif; ?>
                                </div>
                            <?php endwhile; ?>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- Show message when no schedule for today -->
                    <div class="villa-card">
                        <div class="villa-card-header">
                            <h5><i class="bi bi-calendar-week me-2"></i>Today's Collection Schedule - <?php echo $current_day; ?></h5>
                        </div>
                        <div class="villa-card-body">
                            <div class="no-schedule-alert">
                                <i class="bi bi-calendar-x"></i>
                                <h5>No Collection Today</h5>
                                <p class="mb-0">There is no waste collection scheduled for your block today. Check the full schedule to see upcoming collection days.</p>
                                <a href="resident_schedules.php" class="btn btn-success mt-3">
                                    <i class="bi bi-calendar me-2"></i>View Full Schedule
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Announcements -->
                <div class="villa-card">
                    <div class="villa-card-header">
                        <h5><i class="bi bi-megaphone me-2"></i>Announcements</h5>
                    </div>
                    <div class="villa-card-body">
                        <?php if ($announcements_result && $announcements_result->num_rows > 0): ?>
                            <?php while ($announcement = $announcements_result->fetch_assoc()): ?>
                                <div class="announcement-item">
                                    <h6><?php echo htmlspecialchars($announcement['title']); ?></h6>
                                    <p><?php echo htmlspecialchars($announcement['content']); ?></p>
                                    <div class="date">
                                        <i class="bi bi-calendar me-1"></i><?php echo date('F d, Y', strtotime($announcement['date_created'])); ?>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div class="text-center py-4 text-muted">
                                <i class="bi bi-megaphone fs-1"></i>
                                <p class="mt-2">No announcements at this time.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Right Column -->
            <div class="col-lg-4">
                <!-- Profile Info -->
                <div class="villa-card">
                    <div class="villa-card-header">
                        <h5><i class="bi bi-person-circle me-2"></i>Your Profile</h5>
                    </div>
                    <div class="villa-card-body">
                        <div class="profile-info-item">
                            <span class="label">Name</span>
                            <span class="value"><?php echo htmlspecialchars($resident['first_name'] . ' ' . $resident['last_name']); ?></span>
                        </div>
                        <div class="profile-info-item">
                            <span class="label">Email</span>
                            <span class="value"><?php echo htmlspecialchars($resident['email']); ?></span>
                        </div>
                        <div class="profile-info-item">
                            <span class="label">Contact</span>
                            <span class="value"><?php echo htmlspecialchars($resident['contact_number'] ?? 'N/A'); ?></span>
                        </div>
                        <div class="profile-info-item">
                            <span class="label">House</span>
                            <span class="value"><?php echo htmlspecialchars($resident['house_number']); ?></span>
                        </div>
                        <div class="profile-info-item">
                            <span class="label">Block</span>
                            <span class="value"><?php echo htmlspecialchars($resident['block_name'] . ' (' . $resident['block_range'] . ')'); ?></span>
                        </div>
                        <div class="profile-info-item">
                            <span class="label">Member Since</span>
                            <span class="value"><?php echo date('F Y', strtotime($resident['date_added'])); ?></span>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="villa-card">
                    <div class="villa-card-header">
                        <h5><i class="bi bi-lightning me-2"></i>Quick Actions</h5>
                    </div>
                    <div class="villa-card-body">
                        <a href="resident_schedules.php" class="quick-action-btn">
                            <div class="icon">📅</div>
                            <div class="text">
                                <h6>View Schedules</h6>
                                <small>Check collection times</small>
                            </div>
                        </a>
                        <a href="resident_appointments.php" class="quick-action-btn">
                            <div class="icon">📋</div>
                            <div class="text">
                                <h6>Request Appointment</h6>
                                <small>Schedule special collection</small>
                            </div>
                        </a>
                        <a href="resident_feedback.php" class="quick-action-btn">
                            <div class="icon">💬</div>
                            <div class="text">
                                <h6>Send Feedback</h6>
                                <small>Share your thoughts</small>
                            </div>
                        </a>
                        <a href="resident_messages.php" class="quick-action-btn">
                            <div class="icon">✉️</div>
                            <div class="text">
                                <h6>Messages</h6>
                                <small>Contact admin</small>
                            </div>
                        </a>
                        <a href="auth/resident_change_password.php" class="quick-action-btn">
                            <div class="icon">🔑</div>
                            <div class="text">
                                <h6>Change Password</h6>
                                <small>Update your password</small>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <div class="villa-footer">
        <div class="small">
            &copy; 2025 <strong>Villa Castena Waste Management</strong>
        </div>
        <div class="small">
            Keeping Our Community Clean & Green 🌿
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
