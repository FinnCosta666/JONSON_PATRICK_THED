<?php
ob_start();
header('Content-Type: application/json; charset=utf-8');

try {
    include("db_connect.php");
    
    if (!isset($_GET['id'])) {
        http_response_code(400);
        ob_end_clean();
        echo json_encode(array('error' => 'Letter ID is required'));
        exit;
    }
    
    $letter_id = intval($_GET['id']);
    
    if ($letter_id <= 0) {
        http_response_code(400);
        ob_end_clean();
        echo json_encode(array('error' => 'Invalid letter ID'));
        exit;
    }
    
    // enforce that residents can only mark their own letters
    session_start();
    if (isset($_SESSION['resident_id']) && is_numeric($_SESSION['resident_id'])) {
        $stmt = $conn->prepare("UPDATE letters SET status = 'read', read_at = NOW() WHERE id = ? AND status = 'unread' AND resident_id = ?");
    } else {
        $stmt = $conn->prepare("UPDATE letters SET status = 'read', read_at = NOW() WHERE id = ? AND status = 'unread'");
    }
    
    if (!$stmt) {
        http_response_code(500);
        ob_end_clean();
        echo json_encode(array('error' => 'Database prepare error'));
        exit;
    }
    
    if (isset($_SESSION['resident_id']) && is_numeric($_SESSION['resident_id'])) {
        $stmt->bind_param("ii", $letter_id, $_SESSION['resident_id']);
    } else {
        $stmt->bind_param("i", $letter_id);
    }
    
    if ($stmt->execute()) {
        ob_end_clean();
        echo json_encode(array('success' => true, 'affected_rows' => $stmt->affected_rows));
    } else {
        http_response_code(500);
        ob_end_clean();
        echo json_encode(array('error' => 'Update failed'));
    }
    
    $stmt->close();
    
} catch (Exception $e) {
    http_response_code(500);
    ob_end_clean();
    echo json_encode(array('error' => 'Server error'));
}
?>
