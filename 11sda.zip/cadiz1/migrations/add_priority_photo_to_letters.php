<?php
// Run this once to add priority and photo_path columns to `letters` table if missing.
include(__DIR__ . '/../includes/db_connect.php');

function columnExists($conn, $column) {
    $res = $conn->query("SHOW COLUMNS FROM letters LIKE '" . $conn->real_escape_string($column) . "'");
    return ($res && $res->num_rows > 0);
}

$hasPriority = columnExists($conn, 'priority');
$hasPhoto = columnExists($conn, 'photo_path');

if ($hasPriority && $hasPhoto) {
    echo "Table already has priority and photo_path columns.\n";
    exit;
}

$sqls = [];
if (!$hasPriority) {
    // varchar length similar to status
    $sqls[] = "ALTER TABLE letters ADD COLUMN priority VARCHAR(50) DEFAULT 'Normal' AFTER status";
}
if (!$hasPhoto) {
    $sqls[] = "ALTER TABLE letters ADD COLUMN photo_path VARCHAR(255) NULL AFTER priority";
}

foreach ($sqls as $sql) {
    if ($conn->query($sql) === TRUE) {
        echo "Executed: $sql\n";
    } else {
        echo "Error executing: $sql - " . $conn->error . "\n";
    }
}

echo "Done.\n";
?>