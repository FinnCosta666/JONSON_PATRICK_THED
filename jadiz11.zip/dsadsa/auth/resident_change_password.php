<?php
session_start();
include("../includes/db_connect.php");

$error = "";
$success = "";

// Check if resident is logged in
if (!isset($_SESSION['resident_id'])) {
    header("Location: resident_login.php");
    exit;
}

$resident_id = $_SESSION['resident_id'];

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $current_password = trim($_POST['current_password'] ?? '');
    $new_password = trim($_POST['new_password'] ?? '');
    $confirm_password = trim($_POST['confirm_password'] ?? '');

    if (!empty($current_password) && !empty($new_password) && !empty($confirm_password)) {
        // Verify current password
        $stmt = $conn->prepare("SELECT password FROM residents WHERE id = ?");
        $stmt->bind_param("i", $resident_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $resident = $result->fetch_assoc();

        if (password_verify($current_password, $resident['password'])) {
            if ($new_password === $confirm_password) {
                if (strlen($new_password) >= 6) {
                    // Update password
                    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                    $update_stmt = $conn->prepare("UPDATE residents SET password = ? WHERE id = ?");
                    $update_stmt->bind_param("si", $hashed_password, $resident_id);
                    
                    if ($update_stmt->execute()) {
                        $success = "Password changed successfully!";
                    } else {
                        $error = "Error updating password. Please try again.";
                    }
                } else {
                    $error = "New password must be at least 6 characters long.";
                }
            } else {
                $error = "New password and confirm password do not match.";
            }
        } else {
            $error = "Current password is incorrect.";
        }
    } else {
        $error = "Please fill in all fields.";
    }
}

// Get resident info
$stmt = $conn->prepare("SELECT first_name, last_name FROM residents WHERE id = ?");
$stmt->bind_param("i", $resident_id);
$stmt->execute();
$resident = $stmt->get_result()->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password - Villa Castena Waste Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #27ae60;
            --primary-dark: #229954;
            --primary-light: #e8f5e9;
            --villa-gold: #d4af37;
            --villa-brown: #8b6914;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            background: linear-gradient(135deg, rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.2)),
                        url('../assets/images/villa-bg.jpg') no-repeat center center fixed;
            background-size: cover;
            position: relative;
        }

        .navbar-villa {
            background: linear-gradient(135deg, rgba(39, 174, 96, 0.95) 0%, rgba(34, 153, 84, 0.95) 100%);
            backdrop-filter: blur(10px);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.2);
            padding: 15px 0;
            border-bottom: 2px solid var(--villa-gold);
        }

        .navbar-villa .navbar-brand {
            font-weight: 700;
            font-size: 1.3rem;
            color: white !important;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
        }

        .navbar-villa .nav-link {
            color: rgba(255, 255, 255, 0.9) !important;
            font-weight: 500;
            padding: 10px 15px !important;
            border-radius: 8px;
            transition: all 0.3s ease;
            margin: 0 3px;
        }

        .navbar-villa .nav-link:hover {
            background: rgba(255, 255, 255, 0.2);
            color: white !important;
        }

        .villa-container {
            padding: 30px;
        }

        .villa-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.3);
            overflow: hidden;
            margin-bottom: 25px;
        }

        .villa-card-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
            color: white;
            padding: 20px 25px;
            border-bottom: 3px solid var(--villa-gold);
        }

        .villa-card-body {
            padding: 30px;
        }

        .form-label {
            font-weight: 600;
            color: #2c3e50;
        }

        .form-control {
            border: 2px solid #e8f5e9;
            border-radius: 12px;
            padding: 12px 15px;
            font-size: 1rem;
        }

        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(39, 174, 96, 0.25);
        }

        .btn-submit {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
            border: none;
            border-radius: 12px;
            padding: 15px 30px;
            color: white;
            font-weight: 600;
            font-size: 1rem;
            transition: all 0.3s ease;
            width: 100%;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(39, 174, 96, 0.4);
        }

        .btn-back {
            background: #6c757d;
            border: none;
            border-radius: 12px;
            padding: 12px 25px;
            color: white;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
        }

        .btn-back:hover {
            background: #5a6268;
            color: white;
        }

        .password-requirements {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 15px;
            margin-top: 20px;
        }

        .password-requirements ul {
            margin: 0;
            padding-left: 20px;
        }

        .password-requirements li {
            color: #7f8c8d;
            font-size: 0.9rem;
            margin-bottom: 5px;
        }

        .villa-footer {
            background: rgba(44, 62, 80, 0.95);
            color: white;
            padding: 20px;
            text-align: center;
            margin-top: 30px;
            border-top: 2px solid var(--villa-gold);
        }

        .villa-footer small {
            color: rgba(255, 255, 255, 0.7);
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-villa">
        <div class="container-fluid px-4">
            <a class="navbar-brand" href="../resident_dashboard.php">
                <i class="bi bi-house-heart-fill me-2"></i>Villa Castena
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#residentNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="residentNavbar">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../resident_dashboard.php"><i class="bi bi-speedometer2 me-1"></i> Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../resident_schedules.php"><i class="bi bi-calendar-week me-1"></i> Schedules</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../resident_appointments.php"><i class="bi bi-calendar-check me-1"></i> Appointments</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../resident_feedback.php"><i class="bi bi-chat-dots me-1"></i> Feedback</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../resident_messages.php"><i class="bi bi-envelope me-1"></i> Messages</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="resident_change_password.php"><i class="bi bi-key me-1"></i> Change Password</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="resident_logout.php"><i class="bi bi-box-arrow-right me-1"></i> Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="villa-container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="villa-card">
                    <div class="villa-card-header">
                        <h5><i class="bi bi-key me-2"></i>Change Password</h5>
                    </div>
                    <div class="villa-card-body">
                        <?php if ($success): ?>
                            <div class="alert alert-success" role="alert">
                                <i class="bi bi-check-circle me-2"></i><?php echo $success; ?>
                            </div>
                        <?php endif; ?>

                        <?php if ($error): ?>
                            <div class="alert alert-danger" role="alert">
                                <i class="bi bi-exclamation-circle me-2"></i><?php echo $error; ?>
                            </div>
                        <?php endif; ?>

                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="current_password" class="form-label">Current Password *</label>
                                <input type="password" class="form-control" name="current_password" id="current_password" placeholder="Enter your current password" required>
                            </div>

                            <div class="mb-3">
                                <label for="new_password" class="form-label">New Password *</label>
                                <input type="password" class="form-control" name="new_password" id="new_password" placeholder="Enter new password" required>
                            </div>

                            <div class="mb-4">
                                <label for="confirm_password" class="form-label">Confirm New Password *</label>
                                <input type="password" class="form-control" name="confirm_password" id="confirm_password" placeholder="Confirm new password" required>
                            </div>

                            <div class="password-requirements">
                                <strong><i class="bi bi-info-circle me-2"></i>Password Requirements:</strong>
                                <ul class="mt-2">
                                    <li>At least 6 characters long</li>
                                    <li>Should include a mix of letters and numbers</li>
                                    <li>New password must match confirm password</li>
                                </ul>
                            </div>

                            <div class="d-flex gap-3 mt-4">
                                <a href="../resident_dashboard.php" class="btn-back"><i class="bi bi-arrow-left me-2"></i>Back</a>
                                <button type="submit" class="btn-submit">
                                    <i class="bi bi-check-lg me-2"></i>Change Password
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <div class="villa-footer">
        <div class="small">
            &copy; 2025 <strong>Villa Castena Waste Management</strong>
        </div>
        <div class="small">
            Keeping Our Community Clean & Green 🌿
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
