<?php
include("includes/auth_check.php");
include("includes/db_connect.php");
include("header.php");

$error = "";
$success = "";

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'add') {
            $first_name = trim($_POST['first_name'] ?? '');
            $last_name = trim($_POST['last_name'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $contact_number = trim($_POST['contact_number'] ?? '');
            $block_id = intval($_POST['block_id'] ?? 0);
            $house_number = trim($_POST['house_number'] ?? '');
            $password = password_hash('password123', PASSWORD_DEFAULT);

            if (!empty($first_name) && !empty($last_name) && !empty($email) && $block_id > 0 && !empty($house_number)) {
                // Check if email exists
                $check = $conn->prepare("SELECT id FROM residents WHERE email = ?");
                $check->bind_param("s", $email);
                $check->execute();
                if ($check->get_result()->num_rows > 0) {
                    $error = "Email already exists.";
                } else {
                    $stmt = $conn->prepare("INSERT INTO residents (first_name, last_name, email, contact_number, block_id, house_number, password) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $stmt->bind_param("ssssiss", $first_name, $last_name, $email, $contact_number, $block_id, $house_number, $password);
                    
                    if ($stmt->execute()) {
                        $success = "Resident added successfully! Default password: password123";
                    } else {
                        $error = "Error adding resident: " . $stmt->error;
                    }
                }
            } else {
                $error = "Please fill in all required fields.";
            }
        } elseif ($_POST['action'] == 'update_status') {
            $id = intval($_POST['resident_id'] ?? 0);
            $status = trim($_POST['status'] ?? '');

            if ($id > 0) {
                $stmt = $conn->prepare("UPDATE residents SET status = ? WHERE id = ?");
                $stmt->bind_param("si", $status, $id);
                
                if ($stmt->execute()) {
                    $success = "Resident status updated successfully!";
                } else {
                    $error = "Error updating resident: " . $stmt->error;
                }
            }
        }
    }
}

// Get filter parameters
$filter_block = $_GET['block'] ?? 'all';
$filter_status = $_GET['status'] ?? 'all';

// Build query
$query = "SELECT r.*, b.block_name, b.block_range 
    FROM residents r 
    LEFT JOIN blocks b ON r.block_id = b.id 
    WHERE 1=1";

if ($filter_block != 'all') {
    $query .= " AND r.block_id = $filter_block";
}
if ($filter_status != 'all') {
    $query .= " AND r.status = '$filter_status'";
}

$query .= " ORDER BY r.id DESC";

$residents_result = $conn->query($query);

// Get blocks for dropdown
$blocks_result = $conn->query("SELECT * FROM blocks WHERE status = 'active' ORDER BY id");
$blocks_for_form = $conn->query("SELECT * FROM blocks WHERE status = 'active' ORDER BY id");

// Get statistics
$stats_result = $conn->query("SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
    SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END) as inactive
    FROM residents");
$stats = $stats_result->fetch_assoc();
?>

<style>
    .resident-card {
        background: white;
        border-radius: 15px;
        padding: 25px;
        margin-bottom: 20px;
        box-shadow: 0 3px 15px rgba(0, 0, 0, 0.08);
        transition: all 0.3s ease;
    }

    .resident-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);
    }

    .resident-avatar {
        width: 60px;
        height: 60px;
        border-radius: 50%;
        background: linear-gradient(135deg, #27ae60 0%, #229954 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 24px;
        font-weight: 600;
    }

    .resident-info h5 {
        color: #2c3e50;
        font-weight: 600;
        margin: 0;
    }

    .resident-info small {
        color: #7f8c8d;
    }

    .block-badge {
        display: inline-block;
        padding: 5px 15px;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 600;
    }

    .block-1-3 { background: #e3f2fd; color: #1976d2; }
    .block-4-6 { background: #f3e5f5; color: #7b1fa2; }
    .block-7-9 { background: #e8f5e9; color: #388e3c; }
    .block-10-14 { background: #fff3e0; color: #f57c00; }

    .stats-box {
        background: white;
        border-radius: 15px;
        padding: 20px;
        text-align: center;
        box-shadow: 0 3px 15px rgba(0, 0, 0, 0.08);
    }

    .stats-box .number {
        font-size: 2rem;
        font-weight: 700;
    }

    .stats-box .label {
        color: #7f8c8d;
        font-size: 0.9rem;
    }
</style>

<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1><i class="bi bi-people me-2"></i>Residents</h1>
            <p class="text-muted">Manage all residents in Villa Estates</p>
        </div>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addResidentModal">
            <i class="bi bi-plus-lg me-2"></i>Add New Resident
        </button>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo $success; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Statistics -->
    <div class="row g-3 mb-4">
        <div class="col-4">
            <div class="stats-box">
                <div class="number text-primary"><?php echo $stats['total']; ?></div>
                <div class="label">Total Residents</div>
            </div>
        </div>
        <div class="col-4">
            <div class="stats-box">
                <div class="number text-success"><?php echo $stats['active']; ?></div>
                <div class="label">Active</div>
            </div>
        </div>
        <div class="col-4">
            <div class="stats-box">
                <div class="number text-secondary"><?php echo $stats['inactive']; ?></div>
                <div class="label">Inactive</div>
            </div>
        </div>
    </div>

    <!-- Filters -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Block</label>
                    <select name="block" class="form-select" onchange="this.form.submit()">
                        <option value="all" <?php echo ($filter_block == 'all') ? 'selected' : ''; ?>>All Blocks</option>
                        <?php 
                        $blocks_result->data_seek(0);
                        while ($block = $blocks_result->fetch_assoc()): 
                        ?>
                            <option value="<?php echo $block['id']; ?>" <?php echo ($filter_block == $block['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($block['block_name'] . ' - ' . $block['block_range']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select" onchange="this.form.submit()">
                        <option value="all" <?php echo ($filter_status == 'all') ? 'selected' : ''; ?>>All Status</option>
                        <option value="active" <?php echo ($filter_status == 'active') ? 'selected' : ''; ?>>Active</option>
                        <option value="inactive" <?php echo ($filter_status == 'inactive') ? 'selected' : ''; ?>>Inactive</option>
                    </select>
                </div>
            </form>
        </div>
    </div>

    <!-- Residents List -->
    <div class="row">
        <?php if ($residents_result && $residents_result->num_rows > 0): ?>
            <?php while ($resident = $residents_result->fetch_assoc()): ?>
                <div class="col-md-6 col-lg-4">
                    <div class="resident-card">
                        <div class="d-flex align-items-center mb-3">
                            <div class="resident-avatar me-3">
                                <?php echo strtoupper(substr($resident['first_name'], 0, 1) . substr($resident['last_name'], 0, 1)); ?>
                            </div>
                            <div class="resident-info">
                                <h5><?php echo htmlspecialchars($resident['first_name'] . ' ' . $resident['last_name']); ?></h5>
                                <small><i class="bi bi-envelope me-1"></i><?php echo htmlspecialchars($resident['email']); ?></small>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <span class="block-badge block-<?php echo str_replace(' ', '-', strtolower($resident['block_name'] ?? 'none')); ?>">
                                <?php echo htmlspecialchars($resident['block_name'] ?? 'N/A'); ?>
                            </span>
                            <span class="badge bg-<?php echo ($resident['status'] == 'active') ? 'success' : 'secondary'; ?> ms-2">
                                <?php echo ucfirst($resident['status']); ?>
                            </span>
                        </div>

                        <div class="text-muted small mb-3">
                            <div><i class="bi bi-house me-2"></i><?php echo htmlspecialchars($resident['house_number']); ?></div>
                            <div><i class="bi bi-telephone me-2"></i><?php echo htmlspecialchars($resident['contact_number'] ?? 'N/A'); ?></div>
                            <div><i class="bi bi-calendar me-2"></i>Member since <?php echo date('M Y', strtotime($resident['date_added'])); ?></div>
                        </div>

                        <form method="POST" class="d-flex gap-2">
                            <input type="hidden" name="action" value="update_status">
                            <input type="hidden" name="resident_id" value="<?php echo $resident['id']; ?>">
                            <select name="status" class="form-select form-select-sm" onchange="this.form.submit()">
                                <option value="active" <?php echo ($resident['status'] == 'active') ? 'selected' : ''; ?>>Active</option>
                                <option value="inactive" <?php echo ($resident['status'] == 'inactive') ? 'selected' : ''; ?>>Inactive</option>
                            </select>
                        </form>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12 text-center py-5">
                <i class="bi bi-people fs-1 text-muted"></i>
                <p class="mt-3 text-muted">No residents found matching your filters.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Add Resident Modal -->
<div class="modal fade" id="addResidentModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title"><i class="bi bi-plus-lg me-2"></i>Add New Resident</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form method="POST" id="addResidentForm">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="first_name" class="form-label">First Name *</label>
                            <input type="text" class="form-control" name="first_name" id="first_name" required 
                                pattern="[A-Za-z\s]+" title="Letters only"
                                oninput="this.value = this.value.replace(/[^A-Za-z\s]/g, '')">
                        </div>

                        <div class="col-md-6">
                            <label for="last_name" class="form-label">Last Name *</label>
                            <input type="text" class="form-control" name="last_name" id="last_name" required
                                pattern="[A-Za-z\s]+" title="Letters only"
                                oninput="this.value = this.value.replace(/[^A-Za-z\s]/g, '')">
                        </div>

                        <div class="col-md-6">
                            <label for="email" class="form-label">Email Address *</label>
                            <input type="email" class="form-control" name="email" id="email" required>
                        </div>

                        <div class="col-md-6">
                            <label for="contact_number" class="form-label">Contact Number</label>
                            <input type="tel" class="form-control" name="contact_number" id="contact_number" 
                                placeholder="09171234567" maxlength="11" inputmode="numeric"
                                pattern="[0-9]*"
                                oninput="this.value = this.value.replace(/[^0-9]/g, '')">
                        </div>

                        <div class="col-md-6">
                            <label for="block_id" class="form-label">Block *</label>
                            <select class="form-select" name="block_id" id="block_id" required>
                                <option value="">Select Block</option>
                                <?php while ($block = $blocks_for_form->fetch_assoc()): ?>
                                    <option value="<?php echo $block['id']; ?>">
                                        <?php echo htmlspecialchars($block['block_name'] . ' - ' . $block['block_range']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label for="house_number" class="form-label">House Number *</label>
                            <input type="text" class="form-control" name="house_number" id="house_number" 
                                placeholder="e.g., House 1" required>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" form="addResidentForm" class="btn btn-success">Add Resident</button>
            </div>
        </div>
    </div>
</div>

<?php include("footer.php"); ?>
