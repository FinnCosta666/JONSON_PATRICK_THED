<?php
include("includes/auth_check.php");
include("db_connect.php");
include("header.php");
?>

<div class="container-fluid px-4">

    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 mb-1 text-gray-800">Administrators</h1>
            <p class="text-muted mb-0">Manage system administrators and their contact details</p>
        </div>
    </div>

    <!-- Admin Table Card -->
    <div class="card shadow-sm border-0 mb-4">
        <div class="card-header bg-white py-3">
            <h6 class="m-0 fw-bold text-primary">Admin List</h6>
        </div>

        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light text-uppercase small">
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Username</th>
                            <th scope="col">Email Address</th>
                            <th scope="col">Contact Number</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sql = "SELECT Admin_Id, Username, Email, Contact_Number FROM admin";
                        $result = $conn->query($sql);

                        if ($result && $result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                ?>
                                <tr>
                                    <td><?= htmlspecialchars($row['Admin_Id']) ?></td>
                                    <td class="fw-semibold"><?= htmlspecialchars($row['Username']) ?></td>
                                    <td><?= htmlspecialchars($row['Email']) ?></td>
                                    <td><?= htmlspecialchars($row['Contact_Number']) ?></td>
                                </tr>
                                <?php
                            }
                        } else {
                            ?>
                            <tr>
                                <td colspan="4" class="text-center py-5 text-muted">
                                    No administrators found.
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Announcements & Trash Delivery Updates -->
    <div class="card shadow-sm border-0 mt-4">
        <div class="card-header bg-warning text-dark py-3">
            <h6 class="m-0 fw-bold">📢 Trash Delivery Announcements</h6>
        </div>
        <div class="card-body">
            <div class="alert alert-success" role="alert">
                <h6 class="alert-heading">✅ Monday Collection Completed</h6>
                <p class="mb-1">Non-biodegradable waste successfully collected from all zones.</p>
                <small class="text-muted">Last updated: Today at 12:45 PM</small>
            </div>
            <div class="alert alert-info" role="alert">
                <h6 class="alert-heading">🚚 Wednesday Collection In Progress</h6>
                <p class="mb-1">Biodegradable waste collection is ongoing. Zones 1-3 completed, Zones 4-5 in process.</p>
                <small class="text-muted">Status: 60% complete</small>
            </div>
            <div class="alert alert-primary" role="alert">
                <h6 class="alert-heading">📅 Saturday Comprehensive Cleanup Scheduled</h6>
                <p class="mb-1">All zones will be covered for mixed waste collection. Residents are encouraged to prepare for pickup.</p>
                <small class="text-muted">Scheduled: This Saturday, 7:00 AM - 12:00 PM</small>
            </div>
            <div class="alert alert-warning" role="alert">
                <h6 class="alert-heading">⚠️ Reminder: Sort Your Waste</h6>
                <p class="mb-0">Please separate biodegradable and non-biodegradable waste for efficient collection.</p>
            </div>
        </div>
    </div>

</div>

<?php include("footer.php"); ?>