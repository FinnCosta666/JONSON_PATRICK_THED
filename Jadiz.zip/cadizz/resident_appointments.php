<?php
include("includes/resident_auth_check.php");
include("includes/db_connect.php");

// Get resident information
$stmt = $conn->prepare("SELECT r.*, b.block_name, b.block_range 
    FROM residents r 
    LEFT JOIN blocks b ON r.block_id = b.id 
    WHERE r.id = ?");
$stmt->bind_param("i", $_SESSION['resident_id']);
$stmt->execute();
$resident = $stmt->get_result()->fetch_assoc();

$error = "";
$success = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $appointment_date = trim($_POST['appointment_date'] ?? '');
    $appointment_time = trim($_POST['appointment_time'] ?? '');
    $waste_type = trim($_POST['waste_type'] ?? '');
    $special_instructions = trim($_POST['special_instructions'] ?? '');

    if (!empty($appointment_date) && !empty($appointment_time) && !empty($waste_type)) {
        $resident_name = $resident['first_name'] . ' ' . $resident['last_name'];
        $resident_email = $resident['email'];
        $resident_contact = $resident['contact_number'];
        $block_id = $resident['block_id'];

        $stmt = $conn->prepare("INSERT INTO appointments (resident_id, resident_name, resident_email, resident_contact, block_id, appointment_date, appointment_time, waste_type, special_instructions, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
        $stmt->bind_param("isssissss", $_SESSION['resident_id'], $resident_name, $resident_email, $resident_contact, $block_id, $appointment_date, $appointment_time, $waste_type, $special_instructions);
        
        if ($stmt->execute()) {
            $success = "Your appointment request has been submitted successfully!";
        } else {
            $error = "Error submitting appointment: " . $stmt->error;
        }
    } else {
        $error = "Please fill in all required fields.";
    }
}

// Get resident's appointments
$appointments_result = $conn->query("SELECT * FROM appointments WHERE resident_id = {$_SESSION['resident_id']} ORDER BY appointment_date DESC");

// Get unread messages count
$messages_count = $conn->query("SELECT COUNT(*) as count FROM messages WHERE resident_id = {$_SESSION['resident_id']} AND sender_type = 'admin' AND is_read = 0")->fetch_assoc()['count'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointments - Villa Estates Waste Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #27ae60;
            --primary-dark: #229954;
            --primary-light: #e8f5e9;
            --villa-gold: #d4af37;
            --villa-brown: #8b6914;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            background: linear-gradient(135deg, rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.2)),
                        url('assets/images/villa-bg.jpg') no-repeat center center fixed;
            background-size: cover;
            position: relative;
        }

        /* Villa-themed Navbar */
        .navbar-villa {
            background: linear-gradient(135deg, rgba(39, 174, 96, 0.95) 0%, rgba(34, 153, 84, 0.95) 100%);
            backdrop-filter: blur(10px);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.2);
            padding: 15px 0;
            border-bottom: 2px solid var(--villa-gold);
        }

        .navbar-villa .navbar-brand {
            font-weight: 700;
            font-size: 1.3rem;
            color: white !important;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
        }

        .navbar-villa .nav-link {
            color: rgba(255, 255, 255, 0.9) !important;
            font-weight: 500;
            padding: 10px 15px !important;
            border-radius: 8px;
            transition: all 0.3s ease;
            margin: 0 3px;
        }

        .navbar-villa .nav-link:hover {
            background: rgba(255, 255, 255, 0.2);
            color: white !important;
        }

        .navbar-villa .nav-link.active {
            background: rgba(255, 255, 255, 0.25);
            color: white !important;
        }

        /* Main Content Container */
        .villa-container {
            padding: 30px;
        }

        /* Villa Card Style */
        .villa-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.3);
            overflow: hidden;
            margin-bottom: 25px;
        }

        .villa-card-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
            color: white;
            padding: 20px 25px;
            border-bottom: 3px solid var(--villa-gold);
        }

        .villa-card-header h5 {
            margin: 0;
            font-weight: 600;
        }

        .villa-card-body {
            padding: 25px;
        }

        /* Form Styling */
        .form-label {
            font-weight: 600;
            color: #2c3e50;
        }

        .form-control, .form-select {
            border: 2px solid #e8f5e9;
            border-radius: 12px;
            padding: 12px 15px;
            font-size: 1rem;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(39, 174, 96, 0.25);
        }

        textarea.form-control {
            resize: vertical;
            min-height: 120px;
        }

        .btn-submit {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
            border: none;
            border-radius: 12px;
            padding: 15px 30px;
            color: white;
            font-weight: 600;
            font-size: 1rem;
            transition: all 0.3s ease;
            width: 100%;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(39, 174, 96, 0.4);
        }

        /* Appointment Item */
        .appointment-item {
            background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 20px;
            border-left: 5px solid #f39c12;
            transition: all 0.3s ease;
        }

        .appointment-item:hover {
            transform: translateX(5px);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }

        .appointment-item.pending { border-left-color: #f39c12; }
        .appointment-item.approved { border-left-color: #3498db; }
        .appointment-item.completed { border-left-color: #27ae60; }
        .appointment-item.cancelled { border-left-color: #e74c3c; }

        .appointment-item .date {
            font-size: 1.2rem;
            font-weight: 700;
            color: #2c3e50;
        }

        .appointment-item .time {
            color: #7f8c8d;
            margin-bottom: 10px;
        }

        .appointment-item .waste-type {
            display: inline-block;
            background: var(--primary-light);
            color: var(--primary-color);
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 600;
        }

        .appointment-item .status {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }

        .status-pending { background: #fff3e0; color: #ef6c00; }
        .status-approved { background: #e3f2fd; color: #1976d2; }
        .status-completed { background: #e8f5e9; color: #2e7d32; }
        .status-cancelled { background: #ffebee; color: #c62828; }

        .appointment-item .instructions {
            background: #f0f2f5;
            border-radius: 10px;
            padding: 15px;
            margin-top: 15px;
        }

        .appointment-item .admin-notes {
            background: #e8f5e9;
            border-radius: 10px;
            padding: 15px;
            margin-top: 15px;
        }

        /* Footer */
        .villa-footer {
            background: rgba(44, 62, 80, 0.95);
            color: white;
            padding: 20px;
            text-align: center;
            margin-top: 30px;
            border-top: 2px solid var(--villa-gold);
        }

        .villa-footer small {
            color: rgba(255, 255, 255, 0.7);
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-villa">
        <div class="container-fluid px-4">
            <a class="navbar-brand" href="resident_dashboard.php">
                <i class="bi bi-house-heart-fill me-2"></i>Villa Estates
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#residentNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="residentNavbar">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="resident_dashboard.php"><i class="bi bi-speedometer2 me-1"></i> Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="resident_schedules.php"><i class="bi bi-calendar-week me-1"></i> Schedules</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="resident_appointments.php"><i class="bi bi-calendar-check me-1"></i> Appointments</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="resident_feedback.php"><i class="bi bi-chat-dots me-1"></i> Feedback</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="resident_messages.php"><i class="bi bi-envelope me-1"></i> Messages
                            <?php if ($messages_count > 0): ?>
                                <span class="badge bg-danger ms-1"><?php echo $messages_count; ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="auth/resident_logout.php"><i class="bi bi-box-arrow-right me-1"></i> Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="villa-container">
        <div class="row">
            <!-- Request Appointment Form -->
            <div class="col-lg-5">
                <div class="villa-card">
                    <div class="villa-card-header">
                        <h5><i class="bi bi-calendar-plus me-2"></i>Request Appointment</h5>
                    </div>
                    <div class="villa-card-body">
                        <?php if ($success): ?>
                            <div class="alert alert-success" role="alert">
                                <i class="bi bi-check-circle me-2"></i><?php echo $success; ?>
                            </div>
                        <?php endif; ?>

                        <?php if ($error): ?>
                            <div class="alert alert-danger" role="alert">
                                <i class="bi bi-exclamation-circle me-2"></i><?php echo $error; ?>
                            </div>
                        <?php endif; ?>

                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="appointment_date" class="form-label">Preferred Date *</label>
                                <input type="date" class="form-control" name="appointment_date" id="appointment_date" required min="<?php echo date('Y-m-d'); ?>">
                            </div>

                            <div class="mb-3">
                                <label for="appointment_time" class="form-label">Preferred Time *</label>
                                <select class="form-select" name="appointment_time" id="appointment_time" required>
                                    <option value="">Select time...</option>
                                    <option value="08:00 AM - 10:00 AM">08:00 AM - 10:00 AM</option>
                                    <option value="10:00 AM - 12:00 PM">10:00 AM - 12:00 PM</option>
                                    <option value="01:00 PM - 03:00 PM">01:00 PM - 03:00 PM</option>
                                    <option value="03:00 PM - 05:00 PM">03:00 PM - 05:00 PM</option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="waste_type" class="form-label">Waste Type *</label>
                                <select class="form-select" name="waste_type" id="waste_type" required>
                                    <option value="">Select waste type...</option>
                                    <option value="Biodegradable">Biodegradable (Food waste, garden waste)</option>
                                    <option value="Non-Biodegradable">Non-Biodegradable (Plastics, metals, glass)</option>
                                    <option value="Mixed General Waste">Mixed General Waste</option>
                                    <option value="Recyclable">Recyclable Materials</option>
                                    <option value="Hazardous">Hazardous Waste</option>
                                    <option value="Bulky Items">Bulky Items (Furniture, appliances)</option>
                                </select>
                            </div>

                            <div class="mb-4">
                                <label for="special_instructions" class="form-label">Special Instructions</label>
                                <textarea class="form-control" name="special_instructions" id="special_instructions" rows="4" placeholder="Any special instructions or notes..."></textarea>
                            </div>

                            <button type="submit" class="btn-submit">
                                <i class="bi bi-send me-2"></i>Request Appointment
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Appointment History -->
            <div class="col-lg-7">
                <div class="villa-card">
                    <div class="villa-card-header">
                        <h5><i class="bi bi-clock-history me-2"></i>Your Appointment History</h5>
                    </div>
                    <div class="villa-card-body" style="max-height: 700px; overflow-y: auto;">
                        <?php if ($appointments_result && $appointments_result->num_rows > 0): ?>
                            <?php while ($appointment = $appointments_result->fetch_assoc()): ?>
                                <div class="appointment-item <?php echo $appointment['status']; ?>">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <div class="date">
                                                <i class="bi bi-calendar me-2"></i><?php echo date('F d, Y', strtotime($appointment['appointment_date'])); ?>
                                            </div>
                                            <div class="time">
                                                <i class="bi bi-clock me-2"></i><?php echo htmlspecialchars($appointment['appointment_time']); ?>
                                            </div>
                                            <span class="waste-type mt-2">
                                                <i class="bi bi-trash me-1"></i><?php echo htmlspecialchars($appointment['waste_type']); ?>
                                            </span>
                                        </div>
                                        <span class="status status-<?php echo $appointment['status']; ?>">
                                            <?php echo ucfirst($appointment['status']); ?>
                                        </span>
                                    </div>
                                    
                                    <?php if ($appointment['special_instructions']): ?>
                                        <div class="instructions">
                                            <strong><i class="bi bi-info-circle me-2"></i>Your Instructions:</strong>
                                            <p class="mb-0 mt-2"><?php echo nl2br(htmlspecialchars($appointment['special_instructions'])); ?></p>
                                        </div>
                                    <?php endif; ?>

                                    <?php if ($appointment['admin_notes']): ?>
                                        <div class="admin-notes">
                                            <strong><i class="bi bi-reply me-2"></i>Admin Notes:</strong>
                                            <p class="mb-0 mt-2"><?php echo nl2br(htmlspecialchars($appointment['admin_notes'])); ?></p>
                                        </div>
                                    <?php endif; ?>

                                    <div class="text-muted mt-3" style="font-size: 0.85rem;">
                                        <i class="bi bi-calendar-check me-1"></i>Requested on <?php echo date('F d, Y', strtotime($appointment['date_requested'])); ?>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div class="text-center py-5 text-muted">
                                <i class="bi bi-calendar-x fs-1"></i>
                                <p class="mt-3">No appointments requested yet.</p>
                                <p class="small">Use the form to request your first appointment!</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <div class="villa-footer">
        <div class="small">
            &copy; 2025 <strong>Villa Estates Waste Management</strong>
        </div>
        <div class="small">
            Keeping Our Community Clean & Green 🌿
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
