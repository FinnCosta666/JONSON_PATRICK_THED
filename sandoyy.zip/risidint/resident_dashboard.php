<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'resident') {
    header("Location: resident_login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Resident Dashboard</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body>

<nav class="navbar navbar-dark bg-success">
    <div class="container">
        <span class="navbar-brand">
            Welcome, <?= $_SESSION['resident_name']; ?>
        </span>
        <a href="resident_logout.php" class="btn btn-light btn-sm">Logout</a>
    </div>
</nav>

<div class="container mt-4">
    <h3>Resident Dashboard</h3>
    <p>Email: <?= $_SESSION['resident_email']; ?></p>
</div>

</body>
</html>
