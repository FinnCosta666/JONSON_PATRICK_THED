<?php
session_start();
include("../includes/db_connect.php");


$error = "";

// unified login handler supporting both admin and resident modes
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $mode = $_POST['mode'] ?? 'admin';
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($mode === 'resident') {
        // resident login logic (similar to resident_login.php)
        if ($username === '' || $password === '') {
            $error = "Please fill in all fields.";
        } elseif (!filter_var($username, FILTER_VALIDATE_EMAIL)) {
            $error = "Please enter a valid email address.";
        } else {
            $stmt = $conn->prepare("SELECT id, first_name, last_name, email, password FROM residents WHERE email = ?");
            if ($stmt) {
                $stmt->bind_param("s", $username);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result && $result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    if (password_verify($password, $row['password']) || $row['password'] === $password) {
                        $_SESSION['resident_id'] = $row['id'];
                        $_SESSION['resident_name'] = $row['first_name'] . ' ' . $row['last_name'];
                        $_SESSION['resident_email'] = $row['email'];
                        $_SESSION['role'] = 'resident';
                        header("Location: ../resident_dashboard.php");
                        exit;
                    }
                }
                $stmt->close();
            }
            $error = $error ?: "Invalid email or password.";
        }
    } else {
        // admin login
        if (!empty($username) && !empty($password)) {
            $stmt = $conn->prepare("SELECT Admin_Id, Username, Password FROM admin WHERE Username = ?");
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result && $result->num_rows === 1) {
                $row = $result->fetch_assoc();

                if (password_verify($password, $row['Password']) || $row['Password'] === $password) {
                    $_SESSION['admin_id'] = $row['Admin_Id'];
                    $_SESSION['username'] = $row['Username'];
                    $_SESSION['role'] = 'admin';
                    header("Location: ../index.php");
                    exit;
                } else {
                    $error = "Invalid username or password.";
                }
            } else {
                $error = "Invalid username or password.";
            }
            $stmt->close();
        } else {
            $error = "Please fill in all fields.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dalipuga Cleanup - Login</title>

<link href="../assets/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

<style>
body {
    background: linear-gradient(135deg, #27ae60, #229954);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: 'Poppins', sans-serif;
}

/* ADMIN LOGIN BOX */
.login-container {
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 15px 30px rgba(0,0,0,0.2);
    padding: 40px;
    width: 100%;
    max-width: 400px;
}

.login-header {
    text-align: center;
    margin-bottom: 25px;
}

.login-header h2 {
    color: #27ae60;
    font-weight: 600;
}

.login-header p {
    color: #7f8c8d;
    font-size: 14px;
}

.form-control {
    border-radius: 6px;
    padding: 12px;
}

.btn-login {
    background: #27ae60;
    color: #fff;
    padding: 12px;
    width: 100%;
    border-radius: 6px;
    border: none;
}

.btn-login:hover {
    background: #1e8449;
}

/* RESIDENT TAB */
#residentTab {
    position: fixed;
    right: 0;
    top: 50%;
    transform: translateY(-50%);
    background: #fff;
    color: #27ae60;
    padding: 12px 18px;
    border-radius: 10px 0 0 10px;
    cursor: pointer;
    font-weight: 600;
    box-shadow: -2px 2px 10px rgba(0,0,0,0.2);
    z-index: 1000;
}

/* RESIDENT PANEL */
#residentPanel {
    right: -360px;
    top: 0;
    width: 360px;
    height: 100%;
    background: #fff;
    padding: 40px 30px;
    transition: 0.3s ease;
    box-shadow: -3px 0 20px rgba(0,0,0,0.3);
    z-index: 1100;
}

.closeResident {
    text-align: right;
    cursor: pointer;
    color: red;
    font-size: 14px;
    margin-bottom: 10px;
}
</style>
</head>

<body>

<!-- ADMIN LOGIN -->
<div class="login-container">
    <div class="login-header text-center">
        <h2 style="font-weight:700;color:#2f7d3a;">Dalipuga Cleanup</h2>
        <p class="text-muted">Management System Login</p>

        <div class="mt-3 d-flex justify-content-center gap-2">
            <button id="modeAdmin" class="btn btn-sm btn-success active">Admin</button>
            <button id="modeResident" class="btn btn-sm btn-outline-success">Resident</button>
        </div>
    </div>

    <?php if (!empty($error)): ?>
        <div class="alert alert-danger text-center">
            <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <form id="loginForm" method="POST" action="">
        <input type="hidden" name="mode" id="modeInput" value="admin">

        <div class="mb-3">
            <label id="fieldLabel" class="form-label">Email</label>
           <input id="FieldInput" type="text" name="username" class="form-control" placeholder="Enter your username" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Password</label>
            <input id="passwordInput" type="password" name="password" class="form-control" placeholder="Enter your password" required>
        </div>
        <button type="submit" id="submitBtn" class="btn btn-login">Admin Login</button>
    </form>

    <div class="mt-3">
        <div class="d-grid gap-2">
            <a href="resident_register.php" class="btn btn-outline-success">Create Resident Account</a>
        </div>
    </div>
</div>

<script>
    // Toggle between Admin and Resident modes
    const modeAdmin = document.getElementById('modeAdmin');
    const modeResident = document.getElementById('modeResident');
    const fieldLabel = document.getElementById('fieldLabel');
    const fieldInput = document.getElementById('FieldInput');
    const modeInput = document.getElementById('modeInput');
    const loginForm = document.getElementById('loginForm');
    const submitBtn = document.getElementById('submitBtn');

    function setMode(mode) {
        // update button styles
        if (mode === 'resident') {
            modeResident.classList.remove('btn-outline-success');
            modeResident.classList.add('btn-success');
            modeAdmin.classList.remove('active');
            modeAdmin.classList.add('btn-outline-success');

            fieldLabel.textContent = 'Email';
            fieldInput.type = 'email';
            fieldInput.placeholder = 'Enter your email';
            submitBtn.textContent = 'Resident Login';
        } else {
            modeAdmin.classList.remove('btn-outline-success');
            modeAdmin.classList.add('btn-success');
            modeResident.classList.remove('active');
            modeResident.classList.add('btn-outline-success');

            fieldLabel.textContent = 'Username';
            fieldInput.type = 'text';
            fieldInput.placeholder = 'Enter your username';
            submitBtn.textContent = 'Admin Login';
        }
        // always set mode hidden value
        modeInput.value = mode;
    }

    modeAdmin.addEventListener('click', () => setMode('admin'));
    modeResident.addEventListener('click', () => setMode('resident'));

    // Initialize default mode
    setMode('admin');
</script>

</body>
</html>
