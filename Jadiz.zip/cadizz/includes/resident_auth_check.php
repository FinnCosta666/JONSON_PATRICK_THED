<?php
session_start();

// Check if resident is logged in
if (!isset($_SESSION['resident_id'])) {
    header("Location: auth/resident_login.php");
    exit;
}
?>
