<?php
session_start();

// Clear all resident session data
unset($_SESSION['resident_id']);
unset($_SESSION['resident_name']);
unset($_SESSION['resident_email']);
unset($_SESSION['resident_block']);
unset($_SESSION['resident_house']);

// Destroy the session
session_destroy();

// Redirect to login page
header("Location: resident_login.php");
exit;
?>
