<?php
include("includes/auth_check.php");
include("db_connect.php");
include("header.php");
// Leaflet CSS for map
echo '<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" crossorigin=""/>';
?>

<style>
/* ===== BACKGROUND DESIGN ===== */
body {
    background: linear-gradient(135deg, #d4eee5 0%, #e8f8f0 50%, #c8e6c9 100%);
    position: relative;
    overflow-x: hidden;
    min-height: 100vh;
}

/* Decorative shapes */
.bg-shape {
    position: absolute;
    border-radius: 50%;
    filter: blur(80px);
    opacity: 0.6;
    z-index: -1;
}

.bg-shape.green {
    width: 400px;
    height: 400px;
    background: #27ae60;
    top: -150px;
    left: -150px;
}

.bg-shape.light {
    width: 350px;
    height: 350px;
    background: #52b788;
    bottom: -150px;
    right: -150px;
}

/* ===== PAGE TITLE ===== */
.dashboard-title {
    margin-top: 40px;
}

.dashboard-title h1 {
    font-weight: 700;
    color: #27ae60;
}

.dashboard-title p {
    font-size: 1.1rem;
    color: #6c757d;
}

/* ===== DASHBOARD CARDS ===== */
.dashboard-card {
    background: linear-gradient(135deg, #f0f9f7 0%, #ffffff 100%);
    border-radius: 18px;
    padding: 35px 25px;
    text-align: center;
    box-shadow: 0 15px 35px rgba(39, 174, 96, 0.1);
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
    border: 2px solid #e8f5e9;
}

.dashboard-card::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    height: 5px;
    width: 100%;
    background: linear-gradient(90deg, #27ae60, #52b788);
}

.dashboard-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 25px 50px rgba(39, 174, 96, 0.2);
    background: linear-gradient(135deg, #e0f2f1 0%, #f5fdf9 100%);
}

.dashboard-card h5 {
    margin-top: 15px;
    font-weight: 600;
    color: #27ae60;
}

.dashboard-card p {
    font-size: 0.95rem;
    color: #558b7a;
    margin-bottom: 20px;
}

.dashboard-card .btn {
    font-weight: 600;
    padding: 10px 20px;
    border-radius: 30px;
    background-color: #27ae60;
    color: white;
    border: none;
}

.dashboard-card .btn:hover {
    background-color: #229954;
    transform: scale(1.05);
}

/* Card Icon (Letter style) */
.card-icon {
    width: 70px;
    height: 70px;
    margin: 0 auto 10px;
    border-radius: 50%;
    background: linear-gradient(135deg, rgba(39, 174, 96, 0.15) 0%, rgba(82, 183, 136, 0.1) 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 32px;
    font-weight: 700;
    color: #27ae60;
    border: 2px solid #a8d5ba;
}

.container {
    position: relative;
    z-index: 1;
}
</style>

<!-- Background Shapes -->
<div class="bg-shape green"></div>
<div class="bg-shape light"></div>

<div class="container">

    <!-- HEADER -->
    <div class="dashboard-title text-center">
        <h1 class="display-5">Waste Management System</h1>
        <p>Welcome to the Dalipuga Cleanup Tracking Dashboard</p>
    </div>

    <!-- DASHBOARD CARDS -->
    <div class="row mt-5">

        <div class="col-md-4 mb-4">
            <div class="dashboard-card h-100">
                <div class="card-icon">👥</div>
                <h5>Add Resident</h5>
                <p>Register a new household into the system.</p>
                <a href="form.php" class="btn stretched-link">
                    Open Form
                </a>
            </div>
        </div>

        <div class="col-md-4 mb-4">
            <div class="dashboard-card h-100">
                <div class="card-icon">📋</div>
                <h5>View Residents</h5>
                <p>View and manage all registered households.</p>
                <a href="resident.php" class="btn stretched-link">
                    View List
                </a>
            </div>
        </div>
        <div class="col-md-4 mb-4">
            <div class="dashboard-card h-100">
                <div class="card-icon">⚙️</div>
                <h5>Administrators</h5>
                <p>Manage system administrators and access.</p>
                <a href="admins.php" class="btn stretched-link">
                    View Admins
                </a>
            </div>
        </div>

    </div>

    <!-- Bottom spacing -->
    <div style="height: 40px;"></div>

    <!-- ALL WASTE REPORTS SECTION -->
    <div class="card shadow-sm mt-5">
        <div class="card-header bg-success text-white">
            <h5 class="mb-0 fw-bold">📋 Recent Waste Reports</h5>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light text-uppercase small">
                        <tr>
                            <th>ID</th>
                            <th>From (Resident)</th>
                            <th>Subject</th>
                            <th>Status</th>
                            <th>Priority</th>
                            <th>Date Sent</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sql = "SELECT id, resident_name, subject, status, priority, date_sent 
                                FROM letters 
                                ORDER BY date_sent DESC
                                LIMIT 10";
                        $result = $conn->query($sql);
                        if ($result && $result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $status_badge = ($row['status'] == 'unread') ? 
                                    '<span class="badge bg-warning">Unread</span>' : 
                                    '<span class="badge bg-success">Read</span>';
                                $priority_badge = ($row['priority'] == 'Urgent') ?
                                    '<span class="badge bg-danger">Urgent</span>' :
                                    '<span class="badge bg-info">Normal</span>';
                                ?>
                                <tr>
                                    <td><?= htmlspecialchars($row['id']) ?></td>
                                    <td class="fw-semibold"><?= htmlspecialchars($row['resident_name']) ?></td>
                                    <td><?= htmlspecialchars($row['subject']) ?></td>
                                    <td><?= $status_badge ?></td>
                                    <td><?= $priority_badge ?></td>
                                    <td class="text-muted small"><?= htmlspecialchars(date("M d, Y H:i", strtotime($row['date_sent']))) ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#adminLetterModal" onclick="viewAdminLetter(<?= $row['id'] ?>)">👁️ View</button>
                                    </td>
                                </tr>
                                <?php
                            }
                        } else {
                            ?>
                            <tr>
                                <td colspan="7" class="text-center py-5 text-muted">No waste reports submitted yet.</td>
                            </tr>
                            <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            <div class="card-footer bg-light text-center">
                <a href="letters.php" class="btn btn-outline-success btn-sm">View All Reports →</a>
            </div>
        </div>
    </div>
</div>

<!-- Admin Letter Modal -->
<div class="modal fade" id="adminLetterModal" tabindex="-1" aria-labelledby="adminLetterModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title" id="adminLetterModalLabel">📧 Waste Report Details & Location</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" style="min-height: 500px; background-color: #f9f9f9;">
                <div class="row g-3">
                    <div class="col-md-5">
                        <div id="adminLetterContent" style="max-height: 450px; overflow-y: auto;">
                            <div class="text-center text-muted py-5">
                                <div class="spinner-border text-success" role="status" id="loadingSpinner">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-7">
                        <div id="adminLetterMap" style="height: 450px; border-radius: 8px; border: 3px solid #27ae60; background-color: #e8f5e9;"></div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success" data-bs-dismiss="modal">✕ Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"></script>
<script>
    function escapeHtml(text) {
        var map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>\"']/g, function(m) { return map[m]; });
    }

    let adminMap = null;
    let adminMapMarker = null;

    function viewAdminLetter(letterId) {
        document.getElementById('adminLetterContent').innerHTML = `
            <div class="text-center text-muted py-5">
                <div class="spinner-border text-success" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-3">Loading report details...</p>
            </div>
        `;

        fetch('get_letter_details.php?id=' + letterId)
            .then(r => {
                if (!r.ok) throw new Error('Network error ' + r.status);
                return r.json();
            })
            .then(data => {
                var html = `
                    <div style="background: white; padding: 20px; border-radius: 8px; border: 2px solid #e8f5e9;">
                        <div class="mb-3">
                            <label class="fw-semibold text-success">👤 From:</label>
                            <p class="text-dark mb-0">${escapeHtml(data.resident_name)}</p>
                        </div>
                        <div class="mb-3">
                            <label class="fw-semibold text-success">📍 Location:</label>
                            <p class="text-dark mb-0">${escapeHtml(data.resident_location || 'N/A')}</p>
                        </div>
                        <div class="mb-3">
                            <label class="fw-semibold text-success">📞 Contact:</label>
                            <p class="text-dark mb-0">${escapeHtml(data.resident_contact || 'N/A')}</p>
                        </div>
                        <div class="mb-3">
                            <label class="fw-semibold text-success">📧 Email:</label>
                            <p class="text-dark mb-0">${escapeHtml(data.resident_email || 'N/A')}</p>
                        </div>
                        <hr class="my-3" style="border-color: #e8f5e9;">
                        <div class="mb-3">
                            <label class="fw-semibold text-success">📅 Date Sent:</label>
                            <p class="text-dark mb-0">${new Date(data.date_sent).toLocaleString()}</p>
                        </div>
                        <div class="mb-3">
                            <label class="fw-semibold text-success">Subject:</label>
                            <p class="text-dark mb-0"><strong>${escapeHtml(data.subject)}</strong></p>
                        </div>
                        <hr class="my-3" style="border-color: #e8f5e9;">
                        <div class="mb-3">
                            <label class="fw-semibold text-success">💬 Message:</label>
                            <div class="border p-3 bg-light mt-2" style="white-space: pre-wrap; word-wrap: break-word; max-height: 150px; overflow-y: auto; border-color: #a8d5ba !important;">
                                ${escapeHtml(data.message)}
                            </div>
                        </div>
                    </div>
                `;
                document.getElementById('adminLetterContent').innerHTML = html;
                setTimeout(() => {
                    initializeAdminMap(data);
                }, 50);
                
                // Mark as read
                fetch('mark_letter_read.php?id=' + letterId).catch(e => console.error('Error:', e));
            })
            .catch(err => {
                document.getElementById('adminLetterContent').innerHTML = `
                    <div class="alert alert-danger">
                        <strong>Error!</strong> Could not load details. ${escapeHtml(err.message)}
                    </div>
                `;
            });
    }

    function initializeAdminMap(data) {
        if (adminMap !== null) {
            adminMap.remove();
            adminMap = null;
        }
        let lat = 8.31908333, lng = 124.24880555;
        if (data.latitude && data.longitude) {
            lat = parseFloat(data.latitude);
            lng = parseFloat(data.longitude);
        }
        adminMap = L.map('adminLetterMap').setView([lat, lng], 15);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OpenStreetMap contributors', maxZoom: 19 }).addTo(adminMap);
        adminMapMarker = L.marker([lat, lng]).addTo(adminMap);
    }
</script>

<?php include("footer.php"); ?>
