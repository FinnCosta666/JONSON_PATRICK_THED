<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Dalipuga Cleanup - Login</title>

<style>
body {
  margin: 0;
  padding: 0;
  font-family: Arial, sans-serif;
  background: linear-gradient(135deg, #1e9c55, #2ecc71);
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
}

/* MAIN LOGIN BOX */
.login-box {
  background: white;
  width: 350px;
  padding: 30px;
  border-radius: 12px;
  box-shadow: 0 10px 30px rgba(0,0,0,0.2);
  text-align: center;
}

.login-box h2 {
  color: #1e9c55;
  margin-bottom: 5px;
}

.login-box p {
  font-size: 13px;
  color: #777;
  margin-bottom: 20px;
}

.login-box input {
  width: 100%;
  padding: 10px;
  margin-top: 10px;
  border-radius: 6px;
  border: 1px solid #ccc;
}

.login-box button {
  width: 100%;
  background: #1e9c55;
  border: none;
  padding: 10px;
  margin-top: 15px;
  color: white;
  font-size: 15px;
  border-radius: 6px;
  cursor: pointer;
}

.login-box button:hover {
  background: #158344;
}

/* RESIDENTS TAB BUTTON */
#residentTab {
  position: fixed;
  right: 0;
  top: 50%;
  transform: translateY(-50%);
  background: white;
  color: #1e9c55;
  padding: 12px 18px;
  border-radius: 10px 0 0 10px;
  cursor: pointer;
  font-weight: bold;
  box-shadow: -2px 2px 10px rgba(0,0,0,0.2);
}

/* RESIDENT PANEL */
#residentPanel {
  position: fixed;
  right: -320px;
  top: 0;
  width: 320px;
  height: 100%;
  background: white;
  padding: 30px;
  transition: 0.3s ease;
  box-shadow: -3px 0 20px rgba(0,0,0,0.3);
}

#residentPanel h3 {
  color: #1e9c55;
  margin-bottom: 20px;
}

#residentPanel input {
  width: 100%;
  padding: 10px;
  margin-bottom: 12px;
  border-radius: 6px;
  border: 1px solid #ccc;
}

#residentPanel button {
  width: 100%;
  background: #1e9c55;
  border: none;
  padding: 10px;
  color: white;
  font-size: 15px;
  border-radius: 6px;
  cursor: pointer;
}

/* CLOSE BTN */
.closeBtn {
  text-align: right;
  font-size: 14px;
  cursor: pointer;
  color: red;
  margin-bottom: 10px;
}
</style>
</head>
<body>

<!-- ADMIN LOGIN -->
<div class="login-box">
  <h2>Dalipuga Cleanup</h2>
  <p>Management System Login</p>

  <form action="admin_login.php" method="POST">
    <input type="text" name="username" placeholder="Enter username" required>
    <input type="password" name="password" placeholder="Enter password" required>
    <button type="submit">Login</button>
  </form>
</div>

<!-- RESIDENT TAB -->
<div id="residentTab" onclick="toggleResident()">
  Residents
</div>

<!-- RESIDENT LOGIN PANEL -->
<div id="residentPanel">
  <div class="closeBtn" onclick="toggleResident()">✖ Close</div>

  <h3>Resident Login</h3>

  <form action="resident_login.php" method="POST">
    <input type="text" name="username" placeholder="Resident username" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit">Login</button>
  </form>
</div>

<script>
function toggleResident() {
  let panel = document.getElementById("residentPanel");
  panel.style.right = (panel.style.right === "0px") ? "-320px" : "0px";
}
</script>

</body>
</html>
