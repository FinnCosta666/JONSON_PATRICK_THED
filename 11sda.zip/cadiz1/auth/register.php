<?php
session_start();
include("../includes/db_connect.php");

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    $contact_number = trim($_POST['contact_number']);

    if (!$username || !$email || !$password || !$confirm_password) {
        $error = "Please fill in all required fields.";
    } elseif (strlen($username) < 3) {
        $error = "Username must be at least 3 characters long.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters long.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare(
            "INSERT INTO admin (Username, Email, Contact_Number, Password)
             VALUES (?, ?, ?, ?)"
        );
        $stmt->bind_param("ssss", $username, $email, $contact_number, $hashed_password);

        if ($stmt->execute()) {
            $success = "Account created successfully! Redirecting to login...";
            header("refresh:2;url=login.php");
        } else {
            $error = "Error creating account.";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Register - Dalipuga Cleanup</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
<style>
body {
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    font-family: 'Poppins', sans-serif;
    position: relative;
    overflow: hidden;
    background-color: #27ae60;
}

body::before {
    content: "";
    position: fixed;
    inset: 0;
    background-image: url('https://www.reliableskip.com/wp-content/uploads/2022/10/eco-friendly-1.jpeg');
    background-position: center;
    background-size: cover;
    background-repeat: no-repeat;
    filter: blur(6px) brightness(0.75);
    transform: scale(1.03);
    z-index: -1;
}

.register-container {
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 25px 50px rgba(0,0,0,.25);
    padding: 40px;
    width: 100%;
    max-width: 480px;
    position: relative;
    z-index: 1;
}

.register-header {
    text-align: center;
    margin-bottom: 25px;
}

.register-header h2 {
    color: #27ae60;
    font-weight: 600;
}

.register-header p {
    color: #7f8c8d;
    font-size: 14px;
}

.form-label {
    font-weight: 500;
}

/* INPUT SHADOW */
.form-control {
    padding: 12px 14px;
    border-radius: 10px;
    border: 1px solid #ddd;
    box-shadow: 0 6px 14px rgba(0,0,0,0.08);
    transition: all 0.2s ease;
}

.form-control:focus {
    border-color: #27ae60;
    box-shadow: 0 8px 18px rgba(39,174,96,.3);
}

/* PASSWORD FIELD */
.password-wrapper {
    position: relative;
}

.password-wrapper i {
    position: absolute;
    top: 50%;
    right: 15px;
    transform: translateY(-50%);
    cursor: pointer;
    color: #7f8c8d;
}

.password-wrapper i:hover {
    color: #27ae60;
}

.btn-register {
    background: #27ae60;
    color: #fff;
    border: none;
    padding: 14px;
    border-radius: 10px;
    font-weight: 500;
    width: 100%;
}

.btn-register:hover {
    background: #1e8449;
}

.hint {
    font-size: 12px;
    color: #7f8c8d;
}

.login-link {
    margin-top: 20px;
    text-align: center;
}

.login-link a {
    color: #27ae60;
    font-weight: 500;
    text-decoration: none;
}

.login-link a:hover {
    text-decoration: underline;
}
</style>
</head>

<body>

<div class="register-container">
    <div class="register-header">
        <h2>♻️ Dalipuga Cleanup</h2>
        <p>Create New Account</p>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <label class="form-label">Username</label>
            <input type="text" name="username" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Email Address</label>
            <input type="email" name="email" class="form-control" required>
        </div>

        <!-- CONTACT NUMBER (NUMBERS ONLY) -->
        <div class="mb-3">
            <label class="form-label">Contact Number</label>
            <input type="text"
                   name="contact_number"
                   class="form-control"
                   maxlength="11"
                   oninput="this.value=this.value.replace(/[^0-9]/g,'');">
            <div class="hint">Numbers only</div>
        </div>

        <!-- PASSWORD -->
        <div class="mb-3 password-wrapper">
            <label class="form-label">Password</label>
            <input type="password" name="password" id="password" class="form-control" required>
            <i class="bi bi-eye-slash" onclick="togglePassword('password', this)"></i>
            <div class="hint">Minimum 6 characters</div>
        </div>

        <!-- CONFIRM PASSWORD -->
        <div class="mb-3 password-wrapper">
            <label class="form-label">Confirm Password</label>
            <input type="password" name="confirm_password" id="confirm_password" class="form-control" required>
            <i class="bi bi-eye-slash" onclick="togglePassword('confirm_password', this)"></i>
        </div>

        <button type="submit" class="btn btn-register">Create Account</button>
    </form>

    <div class="login-link">
        <small class="text-muted">
            Already have an account?
            <a href="login.php">Login here</a>
        </small>
    </div>
</div>

<script>
function togglePassword(id, icon) {
    const input = document.getElementById(id);
    if (input.type === "password") {
        input.type = "text";
        icon.classList.remove("bi-eye-slash");
        icon.classList.add("bi-eye");
    } else {
        input.type = "password";
        icon.classList.remove("bi-eye");
        icon.classList.add("bi-eye-slash");
    }
}
</script>

</body>
</html>
