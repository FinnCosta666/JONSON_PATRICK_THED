<?php
session_start();
include("../includes/db_connect.php");


$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = trim($_POST['first_name']);
        $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    $contact_number = trim($_POST['contact_number']);
    $location = trim($_POST['location']);

    // Validation
    if (!$first_name || !$last_name || !$email || !$password || !$confirm_password || !$location) {
        $error = "Please fill in all required fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters long.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        // Check if email already exists
        $email_stmt = $conn->prepare("SELECT id FROM residents WHERE email = ?");
        $email_stmt->bind_param("s", $email);
        $email_stmt->execute();
        $email_result = $email_stmt->get_result();

        if ($email_result->num_rows > 0) {
            $error = "Email already registered. Please use another.";
        } else {
            // Hash the password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Insert new resident
            $insert_stmt = $conn->prepare("INSERT INTO residents (first_name, last_name, email, contact_number, location, password) VALUES (?, ?, ?, ?, ?, ?)");
            $insert_stmt->bind_param("ssssss", $first_name, $last_name, $email, $contact_number, $location, $hashed_password);

            if ($insert_stmt->execute()) {
                $success = "Account created successfully! Redirecting to login...";
                // Redirect to login after 2 seconds
                header("refresh:2;url=login.php");
            } else {
                $error = "Error creating account. Please try again.";
            }
            $insert_stmt->close();
        }
        $email_stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Register - Dalipuga Cleanup</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

<style>
body {
    background: linear-gradient(135deg, #27ae60, #229954);
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    font-family: 'Poppins', sans-serif;
}

.register-container {
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 25px 50px rgba(0,0,0,.25);
    padding: 40px;
    width: 100%;
    max-width: 580px;
}

.register-header {
    text-align: center;
    margin-bottom: 25px;
}

.register-header h2 {
    color: #27ae60;
    font-weight: 600;
}

.register-header p {
    color: #7f8c8d;
    font-size: 14px;
}

.form-label {
    font-weight: 500;
}

/* INPUT SHADOW */
.form-control {
    padding: 12px 14px;
    border-radius: 10px;
    border: 1px solid #ddd;
    box-shadow: 0 6px 14px rgba(0,0,0,0.08);
    transition: all 0.2s ease;
}

.form-control:focus {
    border-color: #27ae60;
    box-shadow: 0 8px 18px rgba(39,174,96,.3);
}

/* PASSWORD FIELD */
.password-wrapper {
    position: relative;
}

.password-wrapper i {
    position: absolute;
    top: 50%;
    right: 15px;
    transform: translateY(-50%);
    cursor: pointer;
    color: #7f8c8d;
}

.password-wrapper i:hover {
    color: #27ae60;
}

.btn-register {
    background: #27ae60;
    color: #fff;
    border: none;
    padding: 14px;
    border-radius: 10px;
    font-weight: 500;
    width: 100%;
}

.btn-register:hover {
    background: #1e8449;
}

.hint {
    font-size: 12px;
    color: #7f8c8d;
}

.login-link {
    margin-top: 20px;
    text-align: center;
}

.login-link a {
    color: #27ae60;
    font-weight: 500;
    text-decoration: none;
}

.login-link a:hover {
    text-decoration: underline;
}
</style>
</head>

<body>

<div class="register-container">
    <div class="register-header">
        <h2>♻️ Dalipuga Cleanup</h2>
        <p>Create Resident Account</p>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="row mb-3">
            <div class="col-md-6">
                <label class="form-label">First Name</label>
                <input type="text" name="first_name" class="form-control" placeholder="First name" value="<?= isset($_POST['first_name']) ? htmlspecialchars($_POST['first_name']) : '' ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Last Name</label>
                <input type="text" name="last_name" class="form-control" placeholder="Last name" value="<?= isset($_POST['last_name']) ? htmlspecialchars($_POST['last_name']) : '' ?>" required>
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label">Email Address</label>
            <input type="email" name="email" class="form-control" placeholder="Enter your email" value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Address/Location</label>
            <input type="text" name="location" class="form-control" placeholder="e.g. Purok 5, Dalipuga" value="<?= isset($_POST['location']) ? htmlspecialchars($_POST['location']) : '' ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Contact Number</label>
            <input type="text" name="contact_number" class="form-control" placeholder="09XX XXXX XXX" maxlength="11" oninput="this.value=this.value.replace(/[^0-9]/g,'');" value="<?= isset($_POST['contact_number']) ? htmlspecialchars($_POST['contact_number']) : '' ?>">
            <div class="hint">Numbers only</div>
        </div>

        <!-- PASSWORD -->
        <div class="mb-3 password-wrapper">
            <label class="form-label">Password</label>
            <input type="password" name="password" id="password" class="form-control" placeholder="Enter a strong password" required>
            <i class="bi bi-eye-slash" onclick="togglePassword('password', this)"></i>
            <div class="hint">Minimum 6 characters</div>
        </div>

        <!-- CONFIRM PASSWORD -->
        <div class="mb-3 password-wrapper">
            <label class="form-label">Confirm Password</label>
            <input type="password" name="confirm_password" id="confirm_password" class="form-control" placeholder="Re-enter your password" required>
            <i class="bi bi-eye-slash" onclick="togglePassword('confirm_password', this)"></i>
        </div>

        <button type="submit" class="btn btn-register">Create Account</button>
    </form>
</div>

<script>
function togglePassword(id, icon) {
    const input = document.getElementById(id);
    if (input.type === "password") {
        input.type = "text";
        icon.classList.remove("bi-eye-slash");
        icon.classList.add("bi-eye");
    } else {
        input.type = "password";
        icon.classList.remove("bi-eye");
        icon.classList.add("bi-eye-slash");
    }
}
</script>

</body>
</html>
