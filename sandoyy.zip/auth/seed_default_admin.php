<?php
// Creates a default admin if no admin exists. Run once during setup.
session_start();
include("../includes/db_connect.php");

// Check if admins exist
$res = $conn->query("SELECT COUNT(*) AS c FROM admin");
$row = $res->fetch_assoc();
if ($row && intval($row['c']) > 0) {
    echo "Admin user already exists. No action taken.";
    exit;
}

// Default credentials (change after first login)
$default_username = 'admin';
$default_email = 'admin@example.com';
$default_password = 'admin123';
$contact = '';

$hashed = password_hash($default_password, PASSWORD_DEFAULT);
$stmt = $conn->prepare("INSERT INTO admin (Username, Email, Contact_Number, Password) VALUES (?, ?, ?, ?)");
$stmt->bind_param('ssss', $default_username, $default_email, $contact, $hashed);
if ($stmt->execute()) {
    echo "Default admin created. Username: {$default_username} Password: {$default_password}. Please change immediately.";
} else {
    echo "Failed to create default admin.";
}
$stmt->close();
exit;
?>