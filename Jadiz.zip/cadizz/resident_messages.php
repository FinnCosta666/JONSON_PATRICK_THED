<?php
include("includes/resident_auth_check.php");
include("includes/db_connect.php");

// Get resident information
$stmt = $conn->prepare("SELECT r.*, b.block_name, b.block_range 
    FROM residents r 
    LEFT JOIN blocks b ON r.block_id = b.id 
    WHERE r.id = ?");
$stmt->bind_param("i", $_SESSION['resident_id']);
$stmt->execute();
$resident = $stmt->get_result()->fetch_assoc();

$error = "";
$success = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $message = trim($_POST['message'] ?? '');

    if (!empty($message)) {
        $sender_name = $resident['first_name'] . ' ' . $resident['last_name'];
        $stmt = $conn->prepare("INSERT INTO messages (resident_id, sender_type, sender_name, message) VALUES (?, 'resident', ?, ?)");
        $stmt->bind_param("iss", $_SESSION['resident_id'], $sender_name, $message);
        
        if ($stmt->execute()) {
            $success = "Message sent successfully!";
        } else {
            $error = "Error sending message: " . $stmt->error;
        }
    } else {
        $error = "Please enter a message.";
    }
}

// Mark messages as read
$conn->query("UPDATE messages SET is_read = 1 WHERE resident_id = {$_SESSION['resident_id']} AND sender_type = 'admin' AND is_read = 0");

// Get messages
$messages_result = $conn->query("SELECT * FROM messages WHERE resident_id = {$_SESSION['resident_id']} ORDER BY date_sent ASC");

// Get unread messages count (will be 0 after marking as read)
$messages_count = 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messages - Villa Estates Waste Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #27ae60;
            --primary-dark: #229954;
            --primary-light: #e8f5e9;
            --villa-gold: #d4af37;
            --villa-brown: #8b6914;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            background: linear-gradient(135deg, rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.2)),
                        url('assets/images/villa-bg.jpg') no-repeat center center fixed;
            background-size: cover;
            position: relative;
        }

        /* Villa-themed Navbar */
        .navbar-villa {
            background: linear-gradient(135deg, rgba(39, 174, 96, 0.95) 0%, rgba(34, 153, 84, 0.95) 100%);
            backdrop-filter: blur(10px);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.2);
            padding: 15px 0;
            border-bottom: 2px solid var(--villa-gold);
        }

        .navbar-villa .navbar-brand {
            font-weight: 700;
            font-size: 1.3rem;
            color: white !important;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
        }

        .navbar-villa .nav-link {
            color: rgba(255, 255, 255, 0.9) !important;
            font-weight: 500;
            padding: 10px 15px !important;
            border-radius: 8px;
            transition: all 0.3s ease;
            margin: 0 3px;
        }

        .navbar-villa .nav-link:hover {
            background: rgba(255, 255, 255, 0.2);
            color: white !important;
        }

        .navbar-villa .nav-link.active {
            background: rgba(255, 255, 255, 0.25);
            color: white !important;
        }

        /* Main Content Container */
        .villa-container {
            padding: 30px;
        }

        /* Villa Card Style */
        .villa-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.3);
            overflow: hidden;
            margin-bottom: 25px;
        }

        .villa-card-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
            color: white;
            padding: 20px 25px;
            border-bottom: 3px solid var(--villa-gold);
        }

        .villa-card-header h5 {
            margin: 0;
            font-weight: 600;
        }

        .villa-card-body {
            padding: 25px;
        }

        /* Chat Container */
        .chat-container {
            max-height: 500px;
            overflow-y: auto;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 15px;
        }

        .chat-message {
            margin-bottom: 20px;
            display: flex;
            flex-direction: column;
        }

        .chat-message.sent {
            align-items: flex-end;
        }

        .chat-message.received {
            align-items: flex-start;
        }

        .message-bubble {
            max-width: 70%;
            padding: 15px 20px;
            border-radius: 20px;
            position: relative;
        }

        .chat-message.sent .message-bubble {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
            color: white;
            border-bottom-right-radius: 5px;
        }

        .chat-message.received .message-bubble {
            background: white;
            color: #2c3e50;
            border-bottom-left-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .message-sender {
            font-size: 0.85rem;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .chat-message.sent .message-sender {
            color: var(--primary-color);
            text-align: right;
        }

        .chat-message.received .message-sender {
            color: var(--villa-brown);
        }

        .message-time {
            font-size: 0.75rem;
            margin-top: 8px;
            opacity: 0.7;
        }

        /* Form Styling */
        .message-form {
            display: flex;
            gap: 15px;
            margin-top: 20px;
        }

        .message-input {
            flex: 1;
            border: 2px solid #e8f5e9;
            border-radius: 25px;
            padding: 15px 25px;
            font-size: 1rem;
            outline: none;
        }

        .message-input:focus {
            border-color: var(--primary-color);
        }

        .btn-send {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
            border: none;
            border-radius: 50%;
            width: 60px;
            height: 60px;
            color: white;
            font-size: 24px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .btn-send:hover {
            transform: scale(1.1);
            box-shadow: 0 5px 20px rgba(39, 174, 96, 0.4);
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 50px 20px;
            color: #7f8c8d;
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 20px;
            color: #bdc3c7;
        }

        /* Footer */
        .villa-footer {
            background: rgba(44, 62, 80, 0.95);
            color: white;
            padding: 20px;
            text-align: center;
            margin-top: 30px;
            border-top: 2px solid var(--villa-gold);
        }

        .villa-footer small {
            color: rgba(255, 255, 255, 0.7);
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-villa">
        <div class="container-fluid px-4">
            <a class="navbar-brand" href="resident_dashboard.php">
                <i class="bi bi-house-heart-fill me-2"></i>Villa Estates
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#residentNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="residentNavbar">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="resident_dashboard.php"><i class="bi bi-speedometer2 me-1"></i> Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="resident_schedules.php"><i class="bi bi-calendar-week me-1"></i> Schedules</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="resident_appointments.php"><i class="bi bi-calendar-check me-1"></i> Appointments</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="resident_feedback.php"><i class="bi bi-chat-dots me-1"></i> Feedback</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="resident_messages.php"><i class="bi bi-envelope me-1"></i> Messages</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="auth/resident_logout.php"><i class="bi bi-box-arrow-right me-1"></i> Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="villa-container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="villa-card">
                    <div class="villa-card-header">
                        <h5><i class="bi bi-chat-dots me-2"></i>Messages with Admin</h5>
                    </div>
                    <div class="villa-card-body">
                        <?php if ($success): ?>
                            <div class="alert alert-success" role="alert">
                                <i class="bi bi-check-circle me-2"></i><?php echo $success; ?>
                            </div>
                        <?php endif; ?>

                        <?php if ($error): ?>
                            <div class="alert alert-danger" role="alert">
                                <i class="bi bi-exclamation-circle me-2"></i><?php echo $error; ?>
                            </div>
                        <?php endif; ?>

                        <!-- Chat Messages -->
                        <div class="chat-container" id="chatContainer">
                            <?php if ($messages_result && $messages_result->num_rows > 0): ?>
                                <?php while ($message = $messages_result->fetch_assoc()): ?>
                                    <div class="chat-message <?php echo ($message['sender_type'] == 'resident') ? 'sent' : 'received'; ?>">
                                        <?php if ($message['sender_type'] == 'admin'): ?>
                                            <div class="message-sender">
                                                <i class="bi bi-shield-check me-1"></i>Admin
                                            </div>
                                        <?php else: ?>
                                            <div class="message-sender">You</div>
                                        <?php endif; ?>
                                        <div class="message-bubble">
                                            <?php echo nl2br(htmlspecialchars($message['message'])); ?>
                                            <div class="message-time">
                                                <?php echo date('M d, Y h:i A', strtotime($message['date_sent'])); ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <div class="empty-state">
                                    <i class="bi bi-chat-square-text"></i>
                                    <h5>No messages yet</h5>
                                    <p>Start a conversation with the admin by sending a message below.</p>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Message Form -->
                        <form method="POST" action="" class="message-form">
                            <input type="text" name="message" class="message-input" placeholder="Type your message..." required autocomplete="off">
                            <button type="submit" class="btn-send">
                                <i class="bi bi-send-fill"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <div class="villa-footer">
        <div class="small">
            &copy; 2025 <strong>Villa Estates Waste Management</strong>
        </div>
        <div class="small">
            Keeping Our Community Clean & Green 🌿
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Scroll to bottom of chat
        document.addEventListener('DOMContentLoaded', function() {
            const chatContainer = document.getElementById('chatContainer');
            chatContainer.scrollTop = chatContainer.scrollHeight;
        });
    </script>
</body>
</html>
