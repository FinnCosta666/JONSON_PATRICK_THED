<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Villa Castena Waste Management System</title>
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">

    <!-- Custom Styles -->
    <style>
        :root {
            --primary-color: #27ae60;
            --primary-dark: #229954;
            --primary-light: #e8f5e9;
            --accent-color: #f39c12;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #e8f5e9 100%);
            min-height: 100vh;
        }

        /* Navbar Styling */
        .navbar-custom {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
            box-shadow: 0 4px 20px rgba(39, 174, 96, 0.3);
            padding: 15px 0;
        }

        .navbar-custom .navbar-brand {
            font-weight: 700;
            font-size: 1.3rem;
            color: white !important;
        }

        .navbar-custom .nav-link {
            color: rgba(255, 255, 255, 0.9) !important;
            font-weight: 500;
            padding: 10px 15px !important;
            border-radius: 8px;
            transition: all 0.3s ease;
            margin: 0 3px;
        }

        .navbar-custom .nav-link:hover {
            background: rgba(255, 255, 255, 0.15);
            color: white !important;
        }

        .navbar-custom .nav-link.active {
            background: rgba(255, 255, 255, 0.2);
            color: white !important;
        }

        /* Card Styling */
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
        }

        .card:hover {
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.12);
        }

        .card-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
            color: white;
            border-radius: 15px 15px 0 0 !important;
            padding: 20px;
            font-weight: 600;
        }

        /* Button Styling */
        .btn-success {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
            border: none;
            border-radius: 10px;
            padding: 10px 25px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-success:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(39, 174, 96, 0.4);
        }

        /* Table Styling */
        .table {
            border-radius: 10px;
            overflow: hidden;
        }

        .table thead th {
            background: var(--primary-light);
            color: var(--primary-dark);
            font-weight: 600;
            border: none;
            padding: 15px;
        }

        .table tbody td {
            padding: 15px;
            vertical-align: middle;
        }

        .table tbody tr:hover {
            background: rgba(39, 174, 96, 0.05);
        }

        /* Badge Styling */
        .badge {
            padding: 8px 15px;
            border-radius: 20px;
            font-weight: 500;
        }

        /* Form Styling */
        .form-control, .form-select {
            border: 2px solid #e8f5e9;
            border-radius: 10px;
            padding: 12px 15px;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(39, 174, 96, 0.25);
        }

        /* Alert Styling */
        .alert {
            border-radius: 12px;
            border: none;
        }

        /* Footer Styling */
        .footer {
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            color: white;
            margin-top: 50px;
        }

        /* Stats Card */
        .stats-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            text-align: center;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
        }

        .stats-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
        }

        .stats-card .icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            font-size: 24px;
        }

        .stats-card .number {
            font-size: 2rem;
            font-weight: 700;
            color: #2c3e50;
        }

        .stats-card .label {
            color: #7f8c8d;
            font-size: 0.9rem;
        }

        /* Block Badge */
        .block-badge {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }

        .block-1-3 { background: #e3f2fd; color: #1976d2; }
        .block-4-6 { background: #f3e5f5; color: #7b1fa2; }
        .block-7-9 { background: #e8f5e9; color: #388e3c; }
        .block-10-14 { background: #fff3e0; color: #f57c00; }
    </style>
</head>
<body>

<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-dark navbar-custom">
    <div class="container-fluid px-4">
        <a class="navbar-brand" href="index.php">
            <i class="bi bi-house-heart-fill me-2"></i>Villa Castena Waste Management
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="mainNavbar">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php"><i class="bi bi-speedometer2 me-1"></i> Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="residents.php"><i class="bi bi-people me-1"></i> Residents</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="schedules.php"><i class="bi bi-calendar-week me-1"></i> Schedules</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="appointments.php"><i class="bi bi-calendar-check me-1"></i> Appointments</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="feedback.php"><i class="bi bi-chat-dots me-1"></i> Feedback</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="messages.php"><i class="bi bi-envelope me-1"></i> Messages</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="auth/logout.php"><i class="bi bi-box-arrow-right me-1"></i> Logout</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Page Content Start -->
<div class="container-fluid px-4 mt-4">
