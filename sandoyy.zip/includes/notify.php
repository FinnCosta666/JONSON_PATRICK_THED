<?php
function notify($conn, $msg){
    $stmt=$conn->prepare("INSERT INTO notifications(message) VALUES(?)");
    $stmt->bind_param("s",$msg);
    $stmt->execute();
}
?>