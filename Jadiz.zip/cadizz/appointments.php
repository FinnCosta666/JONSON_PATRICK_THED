<?php
include("includes/auth_check.php");
include("includes/db_connect.php");
include("header.php");

$error = "";
$success = "";

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'update_status') {
            $id = intval($_POST['appointment_id'] ?? 0);
            $status = trim($_POST['status'] ?? '');
            $admin_notes = trim($_POST['admin_notes'] ?? '');

            if ($id > 0) {
                $stmt = $conn->prepare("UPDATE appointments SET status = ?, admin_notes = ? WHERE id = ?");
                $stmt->bind_param("ssi", $status, $admin_notes, $id);
                
                if ($stmt->execute()) {
                    $success = "Appointment updated successfully!";
                } else {
                    $error = "Error updating appointment: " . $stmt->error;
                }
            }
        }
    }
}

// Get filter parameters
$filter_status = $_GET['status'] ?? 'all';
$filter_block = $_GET['block'] ?? 'all';

// Build query
$query = "SELECT a.*, b.block_name, b.block_range 
    FROM appointments a 
    LEFT JOIN blocks b ON a.block_id = b.id 
    WHERE 1=1";

if ($filter_status != 'all') {
    $query .= " AND a.status = '$filter_status'";
}
if ($filter_block != 'all') {
    $query .= " AND a.block_id = $filter_block";
}

$query .= " ORDER BY a.appointment_date DESC, a.appointment_time ASC";

$appointments_result = $conn->query($query);

// Get blocks for filter
$blocks_result = $conn->query("SELECT * FROM blocks WHERE status = 'active' ORDER BY id");

// Get statistics
$stats_result = $conn->query("SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
    SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
    SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
    SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled
    FROM appointments");
$stats = $stats_result->fetch_assoc();
?>

<style>
    .appointment-card {
        background: white;
        border-radius: 15px;
        padding: 25px;
        margin-bottom: 20px;
        box-shadow: 0 3px 15px rgba(0, 0, 0, 0.08);
        border-left: 5px solid #f39c12;
        transition: all 0.3s ease;
    }

    .appointment-card.pending { border-left-color: #f39c12; }
    .appointment-card.approved { border-left-color: #3498db; }
    .appointment-card.completed { border-left-color: #27ae60; }
    .appointment-card.cancelled { border-left-color: #e74c3c; }

    .appointment-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);
    }

    .appointment-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 15px;
    }

    .appointment-author {
        display: flex;
        align-items: center;
        gap: 15px;
    }

    .author-avatar {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        background: linear-gradient(135deg, #27ae60 0%, #229954 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 20px;
        font-weight: 600;
    }

    .author-info h5 {
        margin: 0;
        color: #2c3e50;
        font-weight: 600;
    }

    .author-info small {
        color: #7f8c8d;
    }

    .appointment-details {
        background: #f8f9fa;
        border-radius: 10px;
        padding: 20px;
        margin: 15px 0;
    }

    .appointment-details .detail-row {
        display: flex;
        margin-bottom: 10px;
    }

    .appointment-details .detail-row:last-child {
        margin-bottom: 0;
    }

    .appointment-details .detail-label {
        width: 150px;
        color: #27ae60;
        font-weight: 600;
    }

    .appointment-details .detail-value {
        flex: 1;
        color: #2c3e50;
    }

    .admin-notes {
        background: #e8f5e9;
        border-radius: 10px;
        padding: 15px;
        margin-top: 15px;
    }

    .stats-box {
        background: white;
        border-radius: 15px;
        padding: 20px;
        text-align: center;
        box-shadow: 0 3px 15px rgba(0, 0, 0, 0.08);
    }

    .stats-box .number {
        font-size: 2rem;
        font-weight: 700;
    }

    .stats-box .label {
        color: #7f8c8d;
        font-size: 0.9rem;
    }
</style>

<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1><i class="bi bi-calendar-check me-2"></i>Appointments</h1>
            <p class="text-muted">Manage special collection appointments from residents</p>
        </div>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo $success; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Statistics -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3 col-lg">
            <div class="stats-box">
                <div class="number text-primary"><?php echo $stats['total']; ?></div>
                <div class="label">Total</div>
            </div>
        </div>
        <div class="col-6 col-md-3 col-lg">
            <div class="stats-box">
                <div class="number text-warning"><?php echo $stats['pending']; ?></div>
                <div class="label">Pending</div>
            </div>
        </div>
        <div class="col-6 col-md-3 col-lg">
            <div class="stats-box">
                <div class="number text-info"><?php echo $stats['approved']; ?></div>
                <div class="label">Approved</div>
            </div>
        </div>
        <div class="col-6 col-md-3 col-lg">
            <div class="stats-box">
                <div class="number text-success"><?php echo $stats['completed']; ?></div>
                <div class="label">Completed</div>
            </div>
        </div>
        <div class="col-6 col-md-3 col-lg">
            <div class="stats-box">
                <div class="number text-danger"><?php echo $stats['cancelled']; ?></div>
                <div class="label">Cancelled</div>
            </div>
        </div>
    </div>

    <!-- Filters -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select" onchange="this.form.submit()">
                        <option value="all" <?php echo ($filter_status == 'all') ? 'selected' : ''; ?>>All Status</option>
                        <option value="pending" <?php echo ($filter_status == 'pending') ? 'selected' : ''; ?>>Pending</option>
                        <option value="approved" <?php echo ($filter_status == 'approved') ? 'selected' : ''; ?>>Approved</option>
                        <option value="completed" <?php echo ($filter_status == 'completed') ? 'selected' : ''; ?>>Completed</option>
                        <option value="cancelled" <?php echo ($filter_status == 'cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Block</label>
                    <select name="block" class="form-select" onchange="this.form.submit()">
                        <option value="all" <?php echo ($filter_block == 'all') ? 'selected' : ''; ?>>All Blocks</option>
                        <?php while ($block = $blocks_result->fetch_assoc()): ?>
                            <option value="<?php echo $block['id']; ?>" <?php echo ($filter_block == $block['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($block['block_name']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
            </form>
        </div>
    </div>

    <!-- Appointments List -->
    <?php if ($appointments_result && $appointments_result->num_rows > 0): ?>
        <?php while ($appointment = $appointments_result->fetch_assoc()): ?>
            <div class="appointment-card <?php echo $appointment['status']; ?>">
                <div class="appointment-header">
                    <div class="appointment-author">
                        <div class="author-avatar">
                            <?php echo strtoupper(substr($appointment['resident_name'], 0, 1)); ?>
                        </div>
                        <div class="author-info">
                            <h5><?php echo htmlspecialchars($appointment['resident_name']); ?></h5>
                            <small>
                                <i class="bi bi-envelope me-1"></i><?php echo htmlspecialchars($appointment['resident_email'] ?? 'N/A'); ?> | 
                                <i class="bi bi-telephone me-1"></i><?php echo htmlspecialchars($appointment['resident_contact'] ?? 'N/A'); ?>
                            </small>
                        </div>
                    </div>
                    <div class="text-end">
                        <span class="badge bg-<?php echo ($appointment['status'] == 'pending') ? 'warning' : (($appointment['status'] == 'approved') ? 'info' : (($appointment['status'] == 'completed') ? 'success' : 'danger')); ?>">
                            <?php echo ucfirst($appointment['status']); ?>
                        </span>
                        <small class="text-muted d-block mt-1">
                            Requested <?php echo date('M d, Y', strtotime($appointment['date_requested'])); ?>
                        </small>
                    </div>
                </div>

                <div class="appointment-details">
                    <div class="detail-row">
                        <span class="detail-label"><i class="bi bi-calendar me-2"></i>Date:</span>
                        <span class="detail-value"><?php echo date('F d, Y', strtotime($appointment['appointment_date'])); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label"><i class="bi bi-clock me-2"></i>Time:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($appointment['appointment_time']); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label"><i class="bi bi-trash me-2"></i>Waste Type:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($appointment['waste_type']); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label"><i class="bi bi-building me-2"></i>Block:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($appointment['block_name'] ?? 'N/A'); ?></span>
                    </div>
                    <?php if ($appointment['special_instructions']): ?>
                        <div class="detail-row">
                            <span class="detail-label"><i class="bi bi-info-circle me-2"></i>Instructions:</span>
                            <span class="detail-value"><?php echo nl2br(htmlspecialchars($appointment['special_instructions'])); ?></span>
                        </div>
                    <?php endif; ?>
                </div>

                <?php if ($appointment['admin_notes']): ?>
                    <div class="admin-notes">
                        <strong><i class="bi bi-reply me-2"></i>Admin Notes:</strong>
                        <p class="mb-0"><?php echo nl2br(htmlspecialchars($appointment['admin_notes'])); ?></p>
                    </div>
                <?php endif; ?>

                <div class="mt-3">
                    <button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#updateModal<?php echo $appointment['id']; ?>">
                        <i class="bi bi-pencil me-1"></i>Update Status
                    </button>
                </div>
            </div>

            <!-- Update Modal -->
            <div class="modal fade" id="updateModal<?php echo $appointment['id']; ?>" tabindex="-1">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header bg-success text-white">
                            <h5 class="modal-title"><i class="bi bi-pencil me-2"></i>Update Appointment</h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <form method="POST" id="updateForm<?php echo $appointment['id']; ?>">
                                <input type="hidden" name="action" value="update_status">
                                <input type="hidden" name="appointment_id" value="<?php echo $appointment['id']; ?>">
                                
                                <div class="mb-3">
                                    <label for="status" class="form-label">Status *</label>
                                    <select class="form-select" name="status" id="status" required>
                                        <option value="pending" <?php echo ($appointment['status'] == 'pending') ? 'selected' : ''; ?>>Pending</option>
                                        <option value="approved" <?php echo ($appointment['status'] == 'approved') ? 'selected' : ''; ?>>Approved</option>
                                        <option value="completed" <?php echo ($appointment['status'] == 'completed') ? 'selected' : ''; ?>>Completed</option>
                                        <option value="cancelled" <?php echo ($appointment['status'] == 'cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label for="admin_notes" class="form-label">Admin Notes</label>
                                    <textarea class="form-control" name="admin_notes" rows="4" placeholder="Add notes about this appointment..."><?php echo htmlspecialchars($appointment['admin_notes'] ?? ''); ?></textarea>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" form="updateForm<?php echo $appointment['id']; ?>" class="btn btn-success">Update Appointment</button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <div class="text-center py-5">
            <i class="bi bi-calendar-x fs-1 text-muted"></i>
            <p class="mt-3 text-muted">No appointments found matching your filters.</p>
        </div>
    <?php endif; ?>
</div>

<?php include("footer.php"); ?>
