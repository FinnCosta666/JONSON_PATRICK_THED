-- HOME OWNERS WASTE MANAGEMENT SYSTEM - COMPLETE DATABASE
-- ============================================================
-- Villa Community Waste Management System
-- Blocks: 1-3, 4-6, 7-9, 10-14
-- ============================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

-- ============================================================
-- 1. ADMIN TABLE (for Login, Register, Change Password)
-- ============================================================

CREATE TABLE IF NOT EXISTS admin (
  Admin_Id int(11) NOT NULL AUTO_INCREMENT,
  Username varchar(50) NOT NULL UNIQUE,
  Email varchar(100) NOT NULL UNIQUE,
  Contact_Number varchar(20) DEFAULT NULL,
  Password varchar(255) NOT NULL DEFAULT 'password',
  date_created timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (Admin_Id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Sample Admin Data
-- Username: admin, Password: admin123 (hashed)
INSERT INTO admin (Admin_Id, Username, Email, Contact_Number, Password) VALUES
(1, 'admin', 'admin@villa-castena.com', '09170001111', '$2y$10$SCrJYzovZjxUpE9D0s2X7e58YwmgyAX9RmfiHeo4JT83YpKVlLzqi');

-- ============================================================
-- 2. BLOCKS TABLE (Villa Community Blocks)
-- ============================================================

CREATE TABLE IF NOT EXISTS blocks (
  id int(11) NOT NULL AUTO_INCREMENT,
  block_name varchar(50) NOT NULL UNIQUE,
  block_range varchar(50) NOT NULL,
  description text DEFAULT NULL,
  total_houses int(11) DEFAULT 0,
  status varchar(20) DEFAULT 'active',
  date_created timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insert Villa Community Blocks
INSERT INTO blocks (id, block_name, block_range, description, total_houses, status) VALUES
(1, 'Block 1-3', 'Houses 1-3', 'Premium villa units with garden view', 3, 'active'),
(2, 'Block 4-6', 'Houses 4-6', 'Standard villa units near clubhouse', 3, 'active'),
(3, 'Block 7-9', 'Houses 7-9', 'Luxury villa units with pool access', 3, 'active'),
(4, 'Block 10-14', 'Houses 10-14', 'Executive villa units with panoramic view', 5, 'active');

-- ============================================================
-- 3. RESIDENTS TABLE (for Resident Login, Register, Change Password)
-- ============================================================

CREATE TABLE IF NOT EXISTS residents (
  id int(11) NOT NULL AUTO_INCREMENT,
  first_name varchar(100) NOT NULL,
  last_name varchar(100) NOT NULL,
  email varchar(100) UNIQUE,
  contact_number varchar(20) DEFAULT NULL,
  block_id int(11) DEFAULT NULL,
  house_number varchar(20) NOT NULL,
  password varchar(255) NOT NULL,
  status varchar(20) DEFAULT 'active',
  date_added timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  FOREIGN KEY (block_id) REFERENCES blocks(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Sample Residents Data
-- Password for all residents: password123 (hashed)
INSERT INTO residents (first_name, last_name, email, contact_number, block_id, house_number, password) VALUES
('Juan', 'Dela Cruz', 'juan@villa-estates.com', '09171234567', 1, 'House 1', '$2y$10$S7W.G9VXsLyfMEEw7sn9yuWb3yEcfl6ZbUz4zchUtEZIlufiL6V1m'),
('Maria', 'Santos', 'maria@villa-estates.com', '09987654321', 1, 'House 2', '$2y$10$5eEywOtKqLuTDwdRDmlvYeduCtdn9DyZyREdiUY/F8wB73gOjb2Yu'),
('Pedro', 'Bautista', 'pedro@villa-estates.com', '09221234567', 2, 'House 4', '$2y$10$5eEywOtKqLuTDwdRDmlvYeduCtdn9DyZyREdiUY/F8wB73gOjb2Yu'),
('Ana', 'Garcia', 'ana@villa-estates.com', '09335678901', 3, 'House 7', '$2y$10$5eEywOtKqLuTDwdRDmlvYeduCtdn9DyZyREdiUY/F8wB73gOjb2Yu'),
('Luis', 'Rodriguez', 'luis@villa-estates.com', '09445678912', 4, 'House 10', '$2y$10$5eEywOtKqLuTDwdRDmlvYeduCtdn9DyZyREdiUY/F8wB73gOjb2Yu');

-- ============================================================
-- 4. SCHEDULES TABLE (for Collection Scheduling by Block)
-- ============================================================

CREATE TABLE IF NOT EXISTS schedules (
  id int(11) NOT NULL AUTO_INCREMENT,
  block_id int(11) NOT NULL,
  collection_day varchar(20) NOT NULL,
  collection_time_start time NOT NULL,
  collection_time_end time NOT NULL,
  waste_type varchar(100) NOT NULL,
  notes text DEFAULT NULL,
  status varchar(50) DEFAULT 'active',
  created_by int(11) DEFAULT NULL,
  date_created timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  FOREIGN KEY (block_id) REFERENCES blocks(id) ON DELETE CASCADE,
  FOREIGN KEY (created_by) REFERENCES admin(Admin_Id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Sample Schedule Data
INSERT INTO schedules (block_id, collection_day, collection_time_start, collection_time_end, waste_type, notes, status) VALUES
(1, 'Monday', '08:00:00', '10:00:00', 'Non-Biodegradable', 'Plastics, metals, glass', 'active'),
(1, 'Wednesday', '08:00:00', '10:00:00', 'Biodegradable', 'Food waste, garden waste', 'active'),
(2, 'Monday', '10:00:00', '12:00:00', 'Non-Biodegradable', 'Plastics, metals, glass', 'active'),
(2, 'Wednesday', '10:00:00', '12:00:00', 'Biodegradable', 'Food waste, garden waste', 'active'),
(3, 'Tuesday', '08:00:00', '10:00:00', 'Non-Biodegradable', 'Plastics, metals, glass', 'active'),
(3, 'Thursday', '08:00:00', '10:00:00', 'Biodegradable', 'Food waste, garden waste', 'active'),
(4, 'Tuesday', '10:00:00', '12:00:00', 'Non-Biodegradable', 'Plastics, metals, glass', 'active'),
(4, 'Thursday', '10:00:00', '12:00:00', 'Biodegradable', 'Food waste, garden waste', 'active'),
(1, 'Saturday', '07:00:00', '12:00:00', 'Mixed General Waste', 'All types of waste - comprehensive cleanup', 'active'),
(2, 'Saturday', '07:00:00', '12:00:00', 'Mixed General Waste', 'All types of waste - comprehensive cleanup', 'active'),
(3, 'Saturday', '07:00:00', '12:00:00', 'Mixed General Waste', 'All types of waste - comprehensive cleanup', 'active'),
(4, 'Saturday', '07:00:00', '12:00:00', 'Mixed General Waste', 'All types of waste - comprehensive cleanup', 'active');

-- ============================================================
-- 5. COLLECTION_LOGS TABLE (Track actual collections)
-- ============================================================

CREATE TABLE IF NOT EXISTS collection_logs (
  id int(11) NOT NULL AUTO_INCREMENT,
  schedule_id int(11) NOT NULL,
  block_id int(11) NOT NULL,
  collection_date date NOT NULL,
  status varchar(50) DEFAULT 'completed',
  notes text DEFAULT NULL,
  collected_by varchar(100) DEFAULT NULL,
  date_logged timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  FOREIGN KEY (schedule_id) REFERENCES schedules(id) ON DELETE CASCADE,
  FOREIGN KEY (block_id) REFERENCES blocks(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================
-- 6. APPOINTMENTS TABLE (for Special Collection Appointments)
-- ============================================================

CREATE TABLE IF NOT EXISTS appointments (
  id int(11) NOT NULL AUTO_INCREMENT,
  resident_id int(11) NOT NULL,
  resident_name varchar(200) NOT NULL,
  resident_email varchar(100) DEFAULT NULL,
  resident_contact varchar(20) DEFAULT NULL,
  block_id int(11) DEFAULT NULL,
  appointment_date date NOT NULL,
  appointment_time varchar(50) NOT NULL,
  waste_type varchar(100) NOT NULL,
  special_instructions text DEFAULT NULL,
  status varchar(50) DEFAULT 'pending',
  admin_notes text DEFAULT NULL,
  date_requested timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  FOREIGN KEY (resident_id) REFERENCES residents(id) ON DELETE CASCADE,
  FOREIGN KEY (block_id) REFERENCES blocks(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================
-- 7. FEEDBACK TABLE (for Resident Feedback and Complaints)
-- ============================================================

CREATE TABLE IF NOT EXISTS feedback (
  id int(11) NOT NULL AUTO_INCREMENT,
  resident_id int(11) NOT NULL,
  resident_name varchar(200) NOT NULL,
  resident_email varchar(100) DEFAULT NULL,
  resident_contact varchar(20) DEFAULT NULL,
  block_id int(11) DEFAULT NULL,
  subject varchar(200) NOT NULL,
  message longtext NOT NULL,
  feedback_type varchar(50) NOT NULL,
  rating int(1) DEFAULT NULL,
  status varchar(50) DEFAULT 'unread',
  admin_response longtext DEFAULT NULL,
  response_date timestamp NULL DEFAULT NULL,
  date_submitted timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  FOREIGN KEY (resident_id) REFERENCES residents(id) ON DELETE CASCADE,
  FOREIGN KEY (block_id) REFERENCES blocks(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================
-- 8. MESSAGES TABLE (for Admin and Resident Communication)
-- ============================================================

CREATE TABLE IF NOT EXISTS messages (
  id int(11) NOT NULL AUTO_INCREMENT,
  resident_id int(11) DEFAULT NULL,
  admin_id int(11) DEFAULT NULL,
  sender_type varchar(20) NOT NULL,
  sender_name varchar(200) NOT NULL,
  message longtext NOT NULL,
  is_read tinyint(1) DEFAULT 0,
  date_sent timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  FOREIGN KEY (resident_id) REFERENCES residents(id) ON DELETE CASCADE,
  FOREIGN KEY (admin_id) REFERENCES admin(Admin_Id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================
-- 9. ANNOUNCEMENTS TABLE (for Admin Announcements)
-- ============================================================

CREATE TABLE IF NOT EXISTS announcements (
  id int(11) NOT NULL AUTO_INCREMENT,
  title varchar(200) NOT NULL,
  content longtext NOT NULL,
  priority varchar(20) DEFAULT 'normal',
  status varchar(20) DEFAULT 'active',
  created_by int(11) DEFAULT NULL,
  date_created timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  FOREIGN KEY (created_by) REFERENCES admin(Admin_Id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Sample Announcements
INSERT INTO announcements (title, content, priority, status) VALUES
('Welcome to Villa Estates Waste Management', 'We are pleased to introduce our new waste management system. Please follow the collection schedules for your respective blocks.', 'normal', 'active'),
('Saturday Collection Schedule', 'All blocks will have comprehensive waste collection every Saturday from 7:00 AM to 12:00 PM.', 'high', 'active'),
('Proper Waste Segregation Reminder', 'Please ensure to segregate your waste properly. Biodegradable waste includes food scraps and garden waste. Non-biodegradable includes plastics, metals, and glass.', 'normal', 'active');

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

-- ============================================================
-- DATABASE SETUP COMPLETE
-- ============================================================
-- VILLA ESTATES WASTE MANAGEMENT SYSTEM
--
-- ADMIN LOGIN CREDENTIALS:
-- Username: admin        | Password: admin123
-- Email: admin@villa-estates.com
--
-- RESIDENT LOGIN CREDENTIALS (all use password: password123):
-- Email: juan@villa-estates.com  | Block: 1-3 | House: 1
-- Email: maria@villa-estates.com | Block: 1-3 | House: 2
-- Email: pedro@villa-estates.com | Block: 4-6 | House: 4
-- Email: ana@villa-estates.com   | Block: 7-9 | House: 7
-- Email: luis@villa-estates.com  | Block: 10-14 | House: 10
--
-- BLOCKS:
-- - Block 1-3: Houses 1-3 (Premium villa units)
-- - Block 4-6: Houses 4-6 (Standard villa units)
-- - Block 7-9: Houses 7-9 (Luxury villa units)
-- - Block 10-14: Houses 10-14 (Executive villa units)
--
-- ADMIN FEATURES:
-- - Dashboard with statistics
-- - Collection Scheduling by Block
-- - Manage Appointments
-- - View and Respond to Resident Feedback
-- - Manage Messages
-- - Create Announcements
--
-- RESIDENT FEATURES:
-- - Dashboard with villa theme
-- - View Collection Schedules for their Block
-- - Request Appointments
-- - Send Feedback & Complaints
-- - View and Manage Messages
-- - Read Announcements
-- ============================================================
