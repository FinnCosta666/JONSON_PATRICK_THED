<?php
include("includes/auth_check.php");
include("db_connect.php");
include("header.php");
?>

<div class="container-fluid px-4">

    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 mb-1 text-gray-800">Administrators</h1>
            <p class="text-muted mb-0">Manage system administrators and their contact details</p>
                        <a href="auth/register.php" class="btn btn-outline-secondary">Create Admin Account</a>

            

        </div>
    </div>

    <!-- Admin Table Card -->
    <div class="card shadow-sm border-0 mb-4">
        <div class="card-header bg-white py-3">
            <h6 class="m-0 fw-bold text-primary">Admin List</h6>
        </div>

        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light text-uppercase small">
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Username</th>
                            <th scope="col">Email Address</th>
                            <th scope="col">Contact Number</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sql = "SELECT Admin_Id, Username, Email, Contact_Number FROM admin";
                        $result = $conn->query($sql);

                        if ($result && $result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                ?>
                                <tr>
                                    <td><?= htmlspecialchars($row['Admin_Id']) ?></td>
                                    <td class="fw-semibold"><?= htmlspecialchars($row['Username']) ?></td>
                                    <td><?= htmlspecialchars($row['Email']) ?></td>
                                    <td><?= htmlspecialchars($row['Contact_Number']) ?></td>
                                </tr>
                                <?php
                            }
                        } else {
                            ?>
                            <tr>
                                <td colspan="4" class="text-center py-5 text-muted">
                                    No administrators found.
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Letters Map Card (shows locations of residents who sent letters) -->
    <div class="card shadow-sm border-0">
        <div class="card-header bg-white py-3">
            <h6 class="m-0 fw-bold text-primary">Residents Who Sent Letters — Map</h6>
            <small class="text-muted">Markers show location for each submitted letter</small>
        </div>
        <div class="card-body">
            <div id="lettersMap" style="height: 500px; border-radius: 8px;"></div>
            <p class="small text-muted mt-2">Note: locations are approximated from the address text.</p>
        </div>
    </div>

</div>

<?php include("footer.php"); ?>

<!-- Leaflet CSS/JS for the admin map -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"></script>

<script>
/**
 * Deterministic pseudo-random offset from a string.
 * Converts a string to a small offset so markers are reproducible per location text.
 */
function stringToOffset(s) {
    let hash = 0;
    for (let i = 0; i < s.length; i++) {
        hash = ((hash << 5) - hash) + s.charCodeAt(i);
        hash |= 0; // Convert to 32bit integer
    }
    // Map hash to offsets between -0.01 and +0.01 degrees (~1.1km at equator)
    const maxOffset = 0.01;
    const latOffset = ((hash & 0xffff) / 0xffff) * (2 * maxOffset) - maxOffset;
    const lngOffset = (((hash >>> 16) & 0xffff) / 0xffff) * (2 * maxOffset) - maxOffset;
    return [latOffset, lngOffset];
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

document.addEventListener('DOMContentLoaded', function () {
    // Center of Dalipuga (approximate)
    const centerLat = 8.9;
    const centerLng = 124.3;

    const map = L.map('lettersMap').setView([centerLat, centerLng], 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 19
    }).addTo(map);

    fetch('get_letters_locations.php')
        .then(response => response.json())
        .then(data => {
            if (!Array.isArray(data) || data.length === 0) {
                // no letters yet
                return;
            }

            data.forEach(letter => {
                const locationText = letter.resident_location || '';
                // If location is empty, still place near center with slight random offset
                const base = (locationText && locationText.trim() !== '') ? stringToOffset(locationText) : [Math.random()*0.02-0.01, Math.random()*0.02-0.01];
                const lat = centerLat + base[0];
                const lng = centerLng + base[1];

                const popupHtml = `
                    <div style="min-width:200px">
                        <strong style="color:#0d6efd">${escapeHtml(letter.resident_name || 'Unnamed')}</strong><br>
                        <small style="color:#333">${escapeHtml(letter.subject || 'Report')}</small><br>
                        <small>📍 ${escapeHtml(letter.resident_location || 'N/A')}</small><br>
                        <small>📞 ${escapeHtml(letter.resident_contact || 'N/A')}</small><br>
                        <small class="text-muted">${new Date(letter.date_sent).toLocaleString()}</small>
                    </div>
                `;

                const marker = L.marker([lat, lng]).addTo(map);
                marker.bindPopup(popupHtml);
            });
        })
        .catch(err => {
            console.error('Error loading letters for map:', err);
        });
});
</script>