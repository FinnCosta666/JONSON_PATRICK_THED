<?php
include("db_connect.php");

// Return letters with location info for mapping
$sql = "SELECT id, resident_name, resident_location, resident_contact, subject, date_sent, status, latitude, longitude
    FROM letters
    WHERE resident_location IS NOT NULL AND resident_location <> ''
    ORDER BY date_sent DESC";

$result = $conn->query($sql);

$letters = [];

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $letters[] = $row;
    }
}

header('Content-Type: application/json');
echo json_encode($letters, JSON_UNESCAPED_UNICODE);
$conn->close();
?>