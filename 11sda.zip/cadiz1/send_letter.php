<?php
include("includes/resident_auth_check.php");
include("includes/db_connect.php");

$success = "";
$error = "";
$open_maps_js = "";
$submitted_subject = "";
$submitted_trash_type = "";
$submitted_priority = "Normal";
$submitted_location = "";
$submitted_contact = "";
$submitted_weight = 0;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');
    $trash_type = trim($_POST['trash_type'] ?? '');
    $trash_weight = floatval($_POST['trash_weight'] ?? 0);
    $priority = trim($_POST['priority'] ?? 'Normal');
    $contact_number = trim($_POST['contact_number'] ?? '');
    $custom_location = trim($_POST['custom_location'] ?? '');
    $latitude = floatval($_POST['latitude'] ?? 0);
    $longitude = floatval($_POST['longitude'] ?? 0);
    $resident_id = $_SESSION['resident_id'];
    $resident_name = $_SESSION['resident_name'] ?? '';
    $resident_email = $_SESSION['resident_email'] ?? '';

    // Get resident location and contact from database
    $stmt = $conn->prepare("SELECT id, location, contact_number FROM residents WHERE id = ?");
    $stmt->bind_param("i", $resident_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $resident_data = $result->fetch_assoc();
    $stmt->close();

    // ensure the session id points to an existing resident
    if (!$resident_data) {
        $error = "Resident account not found. Please log in again.";
    }

    $resident_location = !empty($custom_location) ? $custom_location : ($resident_data['location'] ?? '');
    $resident_contact = !empty($contact_number) ? $contact_number : ($resident_data['contact_number'] ?? '');

    // Handle photo upload
    $photo_path = '';
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] == 0) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        if (in_array($_FILES['photo']['type'], $allowed_types) && $_FILES['photo']['size'] <= 5 * 1024 * 1024) { // 5MB limit
            $upload_dir = 'uploads/photos/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            $photo_name = time() . '_' . uniqid() . '_' . basename($_FILES['photo']['name']);
            $photo_path = $upload_dir . $photo_name;
            move_uploaded_file($_FILES['photo']['tmp_name'], $photo_path);
        }
    }

    // Validation
    if (empty($subject) || empty($trash_type)) {
        $error = "Please fill in all required fields.";
    } elseif (strlen($subject) < 5) {
        $error = "Subject must be at least 5 characters long.";
    } elseif (empty($resident_location)) {
        $error = "Please provide a location.";
    } elseif (empty($resident_contact)) {
        $error = "Please provide a contact number.";
    } elseif (empty($resident_data)) {
        // previous lookup failed
        // $error already set above
    } elseif (!is_numeric($resident_id) || intval($resident_id) <= 0) {
        $error = "Invalid resident identifier. Please log in again.";
    } else {
        try {
            // Insert letter into database WITH latitude and longitude from map selection
            $insert_stmt = $conn->prepare("INSERT INTO letters (resident_id, subject, message, resident_location, resident_name, resident_email, resident_contact, status, priority, photo_path, latitude, longitude, date_sent) VALUES (?, ?, ?, ?, ?, ?, ?, 'unread', ?, ?, ?, ?, NOW())");
            if (!$insert_stmt) {
                // if prepare fails because the table structure is outdated, provide details
                throw new Exception("Database error during prepare: " . $conn->error);
            }

            // Combine trash info into message
            $full_message = "Waste Type: " . htmlspecialchars($trash_type) . " | Weight: " . $trash_weight . " kg | Priority: " . htmlspecialchars($priority);
            if (!empty($message)) {
                $full_message .= "\n\nAdditional Details:\n" . $message;
            }

            // Use the coordinates selected on the map
            $insert_stmt->bind_param("issssssssdd", $resident_id, $subject, $full_message, $resident_location, $resident_name, $resident_email, $resident_contact, $priority, $photo_path, $latitude, $longitude);

            if ($insert_stmt->execute()) {
                $letter_id = $conn->insert_id;
                $success = "Letter sent successfully! Reference ID: #" . $letter_id;

                // Store submitted data for modal display (before clearing form)
                $submitted_subject = $subject;
                $submitted_trash_type = $trash_type;
                $submitted_priority = $priority;
                $submitted_location = $resident_location;
                $submitted_contact = $resident_contact;
                $submitted_weight = $trash_weight;

                // Clear form
                $_POST['subject'] = '';
                $_POST['message'] = '';
                $_POST['trash_type'] = '';
                $_POST['trash_weight'] = '';
                $_POST['priority'] = 'Normal';
                $_POST['contact_number'] = '';
                $_POST['custom_location'] = '';
                $_POST['latitude'] = '';
                $_POST['longitude'] = '';
            } else {
                // include DB error and ID for diagnostics
                $error = "Error sending letter. " . htmlspecialchars($insert_stmt->error) . " (resident_id=" . intval($resident_id) . ")";
            }
            $insert_stmt->close();
        } catch (Exception $e) {
            // expose the exception message in development mode to help debugging
            $error = "An error occurred. " . htmlspecialchars($e->getMessage());
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Letter to Admin - Dalipuga Cleanup System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        /* ===== ECO-FRIENDLY BACKGROUND ===== */
        body {
            background: linear-gradient(135deg, #d4eee5 0%, #e8f8f0 50%, #c8e6c9 100%);
            position: relative;
            overflow-x: hidden;
            min-height: 100vh;
            font-family: 'Poppins', sans-serif;
        }

        /* Decorative background shapes */
        .bg-shape {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.6;
            z-index: -1;
        }

        .bg-shape.green {
            width: 400px;
            height: 400px;
            background: #27ae60;
            top: -150px;
            left: -150px;
        }

        .bg-shape.light {
            width: 350px;
            height: 350px;
            background: #52b788;
            bottom: -150px;
            right: -150px;
        }

        .navbar-custom {
            background: linear-gradient(135deg, #27ae60 0%, #229954 100%);
        }

        /* ===== CARDS STYLING ===== */
        .letter-container {
            max-width: 800px;
            margin: 30px auto;
            background: linear-gradient(135deg, #f0f9f7 0%, #ffffff 100%);
            border: 2px solid #e8f5e9 !important;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(39, 174, 96, 0.1);
            padding: 30px;
        }

        .letter-header {
            margin-bottom: 30px;
            border-bottom: 2px solid #27ae60;
            padding-bottom: 15px;
        }

        .letter-header h2 {
            color: #27ae60;
            font-weight: 600;
        }

        /* ===== LABELS AND TEXT ===== */
        .form-label {
            font-weight: 500;
            color: #27ae60 !important;
            margin-bottom: 8px;
        }

        .form-control {
            border: 1px solid #c8e6c9;
            border-radius: 8px;
            padding: 10px 15px;
            margin-bottom: 20px;
            background: #ffffff;
        }

        .form-control:focus {
            border-color: #27ae60;
            box-shadow: 0 0 0 0.2rem rgba(39, 174, 96, 0.25);
        }

        .btn-send {
            background: linear-gradient(135deg, #27ae60 0%, #229954 100%);
            border: none;
            color: white;
            padding: 12px 30px;
            border-radius: 8px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            min-height: 48px;
            font-size: 16px;
        }

        .btn-send:hover {
            background: linear-gradient(135deg, #229954 0%, #1e7e34 100%);
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(39, 174, 96, 0.3);
        }

        .btn-back {
            background: #95a5a6;
            border: none;
            color: white;
            padding: 12px 30px;
            border-radius: 8px;
            font-weight: 500;
            cursor: pointer;
            margin-left: 10px;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s;
        }

        .btn-back:hover {
            background: #7f8c8d;
            color: white;
            text-decoration: none;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .alert {
            border-radius: 8px;
            padding: 12px 16px;
            margin-bottom: 20px;
            border: 1px solid #c8e6c9;
        }

        .alert-info {
            background: linear-gradient(135deg, #e8f5e9 0%, #f0f9f7 100%) !important;
            border-color: #81c784 !important;
            color: #1b5e20 !important;
        }

        .alert-success {
            background: linear-gradient(135deg, #c8e6c9 0%, #e8f5e9 100%) !important;
            border-color: #81c784 !important;
            color: #1b5e20 !important;
        }

        .alert-danger {
            background: linear-gradient(135deg, #ffebee 0%, #ffcdd2 100%) !important;
            border-color: #ef5350 !important;
            color: #c62828 !important;
        }

        .form-buttons {
            display: flex;
            gap: 10px;
            margin-top: 30px;
        }

        @media (max-width: 768px) {
            .letter-container {
                margin: 20px 10px;
                padding: 20px;
            }
            .form-buttons {
                flex-direction: column !important;
            }
            .form-buttons .btn {
                width: 100%;
                margin-bottom: 10px !important;
                margin-left: 0 !important;
            }
            .form-control, input, textarea, select {
                font-size: 16px !important;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom">
        <div class="container-fluid px-4">
            <a class="navbar-brand" href="resident_dashboard.php">
                ♻️ Dalipuga Cleanup Management System
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#residentNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="residentNavbar">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="resident_dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="send_letter.php">Send Letter</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="auth/resident_change_password.php">Change Password</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="auth/resident_logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="letter-container">
        <div class="letter-header">
            <h2>Send Letter to Admin</h2>
            <p class="text-muted mb-0">Communicate with the administrator</p>
        </div>

        <!-- Copy Link Section -->
        <div class="alert alert-info mb-4" role="alert">
            <strong>📋 Share this link:</strong>
            <div class="input-group mt-2">
                <input type="text" class="form-control" id="copyLink" value="<?= htmlspecialchars($_SERVER['HTTP_HOST']) ?>/cadiz/send_letter.php" readonly style="font-size: 14px;">
                <button class="btn btn-outline-info" type="button" onclick="copyToClipboard()" style="min-height: 48px; font-size: 14px;">
                    📋 Copy
                </button>
            </div>
            <small class="d-block mt-2 text-muted">Share this link with others to report trash easily</small>
        </div>

        <?php if (!empty($error)): ?>
            <div class="alert alert-danger" role="alert">
                <strong>Error:</strong> <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($success)): ?>
            <div class="alert alert-success" role="alert">
                <strong>Success!</strong> <?= htmlspecialchars($success) ?>
            </div>
        <?php endif; ?>

        <!-- Success Modal -->
        <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-success text-white">
                        <h5 class="modal-title" id="successModalLabel">✅ Letter Sent Successfully!</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p class="mb-2"><strong>Reference ID:</strong> <span id="referenceId" class="badge bg-primary">#12345</span></p>
                        <p class="mb-2"><strong>Subject:</strong> <span id="modalSubject"></span></p>
                        <p class="mb-2"><strong>Waste Type:</strong> <span id="modalWasteType"></span></p>
                        <p class="mb-2"><strong>Priority:</strong> <span id="modalPriority" class="badge bg-secondary">Normal</span></p>
                        <p class="mb-0"><strong>Location:</strong> <span id="modalLocation"></span></p>
                        <hr>
                        <p class="text-muted mb-0">Your letter has been sent to the admin. You will receive updates on your dashboard.</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <a href="resident_dashboard.php" class="btn btn-success">Go to Dashboard</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Map Modal -->
        <div class="modal fade" id="mapModal" tabindex="-1" aria-labelledby="mapModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="mapModalLabel">🗺️ Select Location</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div style="position: relative;">
                            <div id="locationMap" style="height: 400px; width: 100%;"></div>
                            <!-- Your Location Button -->
                            <button type="button" class="btn btn-light" id="yourLocationBtn" style="position: absolute; top: 10px; right: 10px; z-index: 1000; background-color: #e8f4f8; border: 2px solid #52b788; padding: 8px 12px; border-radius: 8px; display: flex; align-items: center; gap: 8px; font-weight: 500; color: #27ae60;">
                                <span style="font-size: 18px;">📍</span>
                                Your location
                            </button>
                        </div>
                        <p class="mt-2 text-muted">Click on the map to select your exact location, or use the "Your location" button to use your current position</p>
                        <div class="input-group mt-2">
                            <input type="text" class="form-control" id="searchLocation" placeholder="Search for a location...">
                            <button class="btn btn-outline-primary" type="button" id="searchBtn">🔍 Search</button>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-success" id="confirmLocation">✅ Confirm Location</button>
                    </div>
                </div>
            </div>
        </div>

        <form method="POST" action="" novalidate>
            <!-- Hidden fields for coordinates -->
            <input type="hidden" id="latitude" name="latitude" value="">
            <input type="hidden" id="longitude" name="longitude" value="">

            <div class="mb-3">
                <label class="form-label" for="subject">Subject <span class="text-danger">*</span></label>
                <input
                    type="text"
                    class="form-control"
                    id="subject"
                    name="subject"
                    placeholder="Enter letter subject"
                    value="<?= isset($_POST['subject']) ? htmlspecialchars($_POST['subject']) : '' ?>"
                    minlength="5"
                    maxlength="100"
                    required>
                <small class="form-text text-muted">
                    <span id="subject-counter">0</span>/100 characters (minimum 5)
                </small>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label" for="trash_type">Waste Type <span class="text-danger">*</span></label>
                    <select
                        class="form-control"
                        id="trash_type"
                        name="trash_type"
                        required>
                        <option value="">-- Select Waste Type --</option>
                        <option value="Recyclable - Plastic" <?= (isset($_POST['trash_type']) && $_POST['trash_type'] === 'Recyclable - Plastic') ? 'selected' : '' ?>>🗑️ Recyclable - Plastic</option>
                        <option value="Recyclable - Paper" <?= (isset($_POST['trash_type']) && $_POST['trash_type'] === 'Recyclable - Paper') ? 'selected' : '' ?>>📄 Recyclable - Paper</option>
                        <option value="Recyclable - Metal" <?= (isset($_POST['trash_type']) && $_POST['trash_type'] === 'Recyclable - Metal') ? 'selected' : '' ?>>🔧 Recyclable - Metal</option>
                        <option value="Recyclable - Glass" <?= (isset($_POST['trash_type']) && $_POST['trash_type'] === 'Recyclable - Glass') ? 'selected' : '' ?>>🥤 Recyclable - Glass</option>
                        <option value="Non-biodegradable" <?= (isset($_POST['trash_type']) && $_POST['trash_type'] === 'Non-biodegradable') ? 'selected' : '' ?>>🚫 Non-biodegradable</option>
                        <option value="Biodegradable" <?= (isset($_POST['trash_type']) && $_POST['trash_type'] === 'Biodegradable') ? 'selected' : '' ?>>🌱 Biodegradable</option>
                        <option value="Hazardous - Electronics" <?= (isset($_POST['trash_type']) && $_POST['trash_type'] === 'Hazardous - Electronics') ? 'selected' : '' ?>>⚡ Hazardous - Electronics</option>
                        <option value="Hazardous - Chemicals" <?= (isset($_POST['trash_type']) && $_POST['trash_type'] === 'Hazardous - Chemicals') ? 'selected' : '' ?>>☠️ Hazardous - Chemicals</option>
                        <option value="Mixed Waste" <?= (isset($_POST['trash_type']) && $_POST['trash_type'] === 'Mixed Waste') ? 'selected' : '' ?>>🔄 Mixed Waste</option>
                        <option value="Construction Debris" <?= (isset($_POST['trash_type']) && $_POST['trash_type'] === 'Construction Debris') ? 'selected' : '' ?>>🏗️ Construction Debris</option>
                    </select>
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label" for="trash_weight">Estimated Weight (kg)</label>
                    <input
                        type="number"
                        class="form-control"
                        id="trash_weight"
                        name="trash_weight"
                        placeholder="0.0"
                        value="<?= isset($_POST['trash_weight']) ? htmlspecialchars($_POST['trash_weight']) : '' ?>"
                        step="0.1"
                        min="0">
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label" for="priority">Priority Level</label>
                    <select class="form-control" id="priority" name="priority">
                        <option value="Normal" <?= (isset($_POST['priority']) && $_POST['priority'] === 'Normal') ? 'selected' : '' ?>>📊 Normal</option>
                        <option value="Urgent" <?= (isset($_POST['priority']) && $_POST['priority'] === 'Urgent') ? 'selected' : '' ?>>🚨 Urgent</option>
                    </select>
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label" for="contact_number">Contact Number <span class="text-danger">*</span></label>
                    <input
                        type="tel"
                        class="form-control"
                        id="contact_number"
                        name="contact_number"
                        placeholder="09123456789"
                        value="<?= isset($_POST['contact_number']) ? htmlspecialchars($_POST['contact_number']) : htmlspecialchars($resident_data['contact_number'] ?? '') ?>"
                        pattern="[0-9]{11}"
                        required>
                    <small class="form-text text-muted">Your registered contact: <?= htmlspecialchars($resident_data['contact_number'] ?? 'Not set') ?></small>
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label" for="custom_location">Location <span class="text-danger">*</span></label>
                <div class="input-group">
                    <input
                        type="text"
                        class="form-control"
                        id="custom_location"
                        name="custom_location"
                        placeholder="Enter specific location or address"
                        value="<?= isset($_POST['custom_location']) ? htmlspecialchars($_POST['custom_location']) : htmlspecialchars($resident_data['location'] ?? '') ?>"
                        required>
                    <button class="btn btn-outline-success" type="button" id="mapBtn" title="Select location on map">
                        🗺️ Map
                    </button>
                </div>
                <small class="form-text text-muted">Your registered location: <?= htmlspecialchars($resident_data['location'] ?? 'Not set') ?> | Click map button to select exact location</small>
            </div>

            <div class="mb-3">
                <label class="form-label" for="photo">Photo Attachment (Optional)</label>
                <input
                    type="file"
                    class="form-control"
                    id="photo"
                    name="photo"
                    accept="image/*">
                <small class="form-text text-muted">Upload a photo of the waste location (max 5MB, JPG/PNG/GIF only)</small>
                <div id="photo-preview" class="mt-2" style="display: none;">
                    <img id="preview-img" src="" alt="Preview" class="img-thumbnail" style="max-width: 200px; max-height: 200px;">
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label" for="message">Message</label>
                <textarea 
                    class="form-control" 
                    id="message"
                    name="message" 
                    placeholder="Write your message here (optional)..."
                    rows="8"><?= isset($_POST['message']) ? htmlspecialchars($_POST['message']) : '' ?></textarea>
            </div>

            <div class="form-buttons">
                <button type="submit" class="btn btn-send">Send Letter</button>
                <a href="resident_dashboard.php" class="btn btn-back">Back to Dashboard</a>
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

    <script>
        // Character counter for subject
        document.getElementById('subject').addEventListener('input', function() {
            const counter = document.getElementById('subject-counter');
            const length = this.value.length;
            counter.textContent = length;
            counter.className = length < 5 ? 'text-danger' : 'text-success';
        });

        // Photo preview
        document.getElementById('photo').addEventListener('change', function(e) {
            const file = e.target.files[0];
            const preview = document.getElementById('photo-preview');
            const previewImg = document.getElementById('preview-img');

            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    previewImg.src = e.target.result;
                    preview.style.display = 'block';
                };
                reader.readAsDataURL(file);
            } else {
                preview.style.display = 'none';
            }
        });

        // Copy link function
        function copyToClipboard() {
            const copyLink = document.getElementById('copyLink');
            copyLink.select();
            document.execCommand('copy');

            const button = event.target;
            const originalText = button.innerHTML;
            button.innerHTML = '✅ Copied!';
            setTimeout(() => {
                button.innerHTML = originalText;
            }, 2000);
        }

        // Map functionality
        let map, marker;
        let selectedLatLng = null;

        document.getElementById('mapBtn').addEventListener('click', function() {
            const modal = new bootstrap.Modal(document.getElementById('mapModal'));
            modal.show();

            // Initialize map after modal is shown
            setTimeout(() => {
                if (!map) {
                    map = L.map('locationMap').setView([8.31908333, 124.24880555], 13); // Dalipuga coordinates: 8°19'08.7"N 124°14'55.7"E

                    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                        attribution: '© OpenStreetMap contributors'
                    }).addTo(map);

                    map.on('click', function(e) {
                        if (marker) {
                            map.removeLayer(marker);
                        }
                        marker = L.marker(e.latlng).addTo(map);
                        selectedLatLng = e.latlng;
                    });

                    // Your Location button functionality
                    document.getElementById('yourLocationBtn').addEventListener('click', function() {
                        const btn = this;
                        const originalHTML = btn.innerHTML;
                        btn.innerHTML = '<span style="font-size: 18px;">⏳</span> Getting location...';
                        btn.disabled = true;

                        if (navigator.geolocation) {
                            navigator.geolocation.getCurrentPosition(
                                function(position) {
                                    const lat = position.coords.latitude;
                                    const lng = position.coords.longitude;

                                    // Center map on user location
                                    map.setView([lat, lng], 16);

                                    // Remove old marker and add new one
                                    if (marker) {
                                        map.removeLayer(marker);
                                    }
                                    marker = L.marker([lat, lng]).addTo(map);
                                    selectedLatLng = { lat: lat, lng: lng };

                                    // Update button
                                    btn.innerHTML = '<span style="font-size: 18px;">✅</span> Location found!';
                                    setTimeout(() => {
                                        btn.innerHTML = originalHTML;
                                        btn.disabled = false;
                                    }, 2000);
                                },
                                function(error) {
                                    let errorMsg = 'Unable to get location';
                                    if (error.code === error.PERMISSION_DENIED) {
                                        errorMsg = 'Location permission denied. Please enable location in browser settings.';
                                    } else if (error.code === error.POSITION_UNAVAILABLE) {
                                        errorMsg = 'Location service unavailable';
                                    }
                                    alert(errorMsg);
                                    btn.innerHTML = originalHTML;
                                    btn.disabled = false;
                                }
                            );
                        } else {
                            alert('Geolocation is not supported by your browser. Please update your browser or manually select location on the map.');
                            btn.innerHTML = originalHTML;
                            btn.disabled = false;
                        }
                    });
                }
            }, 500);
        });

        // Search location
        document.getElementById('searchBtn').addEventListener('click', function() {
            const query = document.getElementById('searchLocation').value;
            if (query) {
                fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=1`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.length > 0) {
                            const lat = parseFloat(data[0].lat);
                            const lng = parseFloat(data[0].lon);
                            map.setView([lat, lng], 16);

                            if (marker) {
                                map.removeLayer(marker);
                            }
                            marker = L.marker([lat, lng]).addTo(map);
                            selectedLatLng = { lat, lng };
                        } else {
                            alert('Location not found. Please try a different search term.');
                        }
                    })
                    .catch(error => {
                        console.error('Search error:', error);
                        alert('Error searching for location. Please try again.');
                    });
            }
        });

        // Confirm location
        document.getElementById('confirmLocation').addEventListener('click', function() {
            if (selectedLatLng) {
                // Store the exact coordinates selected on the map
                document.getElementById('latitude').value = selectedLatLng.lat;
                document.getElementById('longitude').value = selectedLatLng.lng;

                // Reverse geocode to get address
                fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${selectedLatLng.lat}&lon=${selectedLatLng.lng}`)
                    .then(response => response.json())
                    .then(data => {
                        const address = data.display_name || `${selectedLatLng.lat}, ${selectedLatLng.lng}`;
                        document.getElementById('custom_location').value = address;
                        bootstrap.Modal.getInstance(document.getElementById('mapModal')).hide();
                    })
                    .catch(error => {
                        console.error('Reverse geocoding error:', error);
                        document.getElementById('custom_location').value = `${selectedLatLng.lat}, ${selectedLatLng.lng}`;
                        bootstrap.Modal.getInstance(document.getElementById('mapModal')).hide();
                    });
            } else {
                alert('Please select a location on the map first.');
            }
        });

        // Show success modal on successful submission
        <?php if (!empty($success) && strpos($success, 'Reference ID:') !== false): ?>
            document.addEventListener('DOMContentLoaded', function() {
                const successModal = new bootstrap.Modal(document.getElementById('successModal'));

                // Extract data from the success message
                const referenceMatch = '<?= $success ?>'.match(/Reference ID: #(\d+)/);
                if (referenceMatch) {
                    document.getElementById('referenceId').textContent = '#' + referenceMatch[1];
                }

                // Fill modal with submitted data from PHP (not form values)
                document.getElementById('modalSubject').textContent = '<?= htmlspecialchars($submitted_subject ?? '') ?>';
                
                // Get waste type with emoji
                const wasteTypeMap = {
                    'Recyclable - Plastic': '🗑️ Recyclable - Plastic',
                    'Recyclable - Paper': '📄 Recyclable - Paper',
                    'Recyclable - Metal': '🔧 Recyclable - Metal',
                    'Recyclable - Glass': '🥤 Recyclable - Glass',
                    'Non-biodegradable': '🚫 Non-biodegradable',
                    'Biodegradable': '🌱 Biodegradable',
                    'Hazardous - Electronics': '⚡ Hazardous - Electronics',
                    'Hazardous - Chemicals': '☠️ Hazardous - Chemicals',
                    'Mixed Waste': '🔄 Mixed Waste',
                    'Construction Debris': '🏗️ Construction Debris'
                };
                const wasteType = '<?= htmlspecialchars($submitted_trash_type ?? '') ?>';
                document.getElementById('modalWasteType').textContent = wasteTypeMap[wasteType] || wasteType;
                
                const priority = '<?= htmlspecialchars($submitted_priority ?? 'Normal') ?>';
                document.getElementById('modalPriority').textContent = priority;
                document.getElementById('modalPriority').className = priority === 'Urgent' ? 'badge bg-danger' : 'badge bg-secondary';
                
                document.getElementById('modalLocation').textContent = '<?= htmlspecialchars($submitted_location ?? '') ?>';

                successModal.show();
            });
        <?php endif; ?>

        // Form validation
        document.querySelector('form').addEventListener('submit', function(e) {
            const subject = document.getElementById('subject').value.trim();
            const trashType = document.getElementById('trash_type').value;
            const location = document.getElementById('custom_location').value.trim();
            const contact = document.getElementById('contact_number').value.trim();
            const latitude = document.getElementById('latitude').value;
            const longitude = document.getElementById('longitude').value;

            if (subject.length < 5) {
                alert('Subject must be at least 5 characters long.');
                e.preventDefault();
                return false;
            }

            if (!trashType) {
                alert('Please select a waste type.');
                e.preventDefault();
                return false;
            }

            if (!location) {
                alert('Please provide a location.');
                e.preventDefault();
                return false;
            }

            if (!latitude || !longitude) {
                alert('Please select a location on the map to get exact coordinates.');
                e.preventDefault();
                return false;
            }

            if (!contact) {
                alert('Please provide a contact number.');
                e.preventDefault();
                return false;
            }

            // Show loading state
            const submitBtn = document.querySelector('.btn-send');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = '📤 Sending...';
            submitBtn.disabled = true;

            // Re-enable after 10 seconds (in case of error)
            setTimeout(() => {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            }, 10000);
        });
    </script>
</body>
</html>