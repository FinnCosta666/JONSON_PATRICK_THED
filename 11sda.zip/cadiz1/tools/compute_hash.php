<?php
// helper script to compute password hash
echo password_hash('password123', PASSWORD_DEFAULT) . "\n";
