<?php
$servername = "localhost";
$username   = "root";
$password   = "";
$database   = "barangay_system";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("<div class='alert alert-danger'>❌ Connection failed: " . $conn->connect_error . "</div>");
}

// Auto-create staff table if it doesn't exist
$table_check = $conn->query("SHOW TABLES LIKE 'staff'");
if (!$table_check || $table_check->num_rows === 0) {
    $create_staff_table = "CREATE TABLE IF NOT EXISTS staff (
      staff_id int(11) NOT NULL AUTO_INCREMENT,
      first_name varchar(100) NOT NULL,
      last_name varchar(100) NOT NULL,
      email varchar(100) NOT NULL UNIQUE,
      contact_number varchar(20) DEFAULT NULL,
      role varchar(50) NOT NULL DEFAULT 'staff',
      password varchar(255) NOT NULL,
      status varchar(20) DEFAULT 'active',
      date_created timestamp DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (staff_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
    
    $conn->query($create_staff_table);
}

// Auto-add latitude and longitude columns to letters table if missing
$lat_check = $conn->query("SHOW COLUMNS FROM letters LIKE 'latitude'");
$lon_check = $conn->query("SHOW COLUMNS FROM letters LIKE 'longitude'");

if (!$lat_check || $lat_check->num_rows === 0) {
    $conn->query("ALTER TABLE letters ADD COLUMN latitude DECIMAL(10,8) NULL DEFAULT NULL");
}

if (!$lon_check || $lon_check->num_rows === 0) {
    $conn->query("ALTER TABLE letters ADD COLUMN longitude DECIMAL(11,8) NULL DEFAULT NULL");
}
?>