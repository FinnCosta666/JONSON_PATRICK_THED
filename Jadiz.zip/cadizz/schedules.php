<?php
include("includes/auth_check.php");
include("includes/db_connect.php");
include("header.php");

$error = "";
$success = "";

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'add') {
            $block_id = intval($_POST['block_id'] ?? 0);
            $collection_day = trim($_POST['collection_day'] ?? '');
            $collection_time_start = trim($_POST['collection_time_start'] ?? '');
            $collection_time_end = trim($_POST['collection_time_end'] ?? '');
            $waste_type = trim($_POST['waste_type'] ?? '');
            $notes = trim($_POST['notes'] ?? '');

            if ($block_id > 0 && !empty($collection_day) && !empty($collection_time_start) && !empty($collection_time_end) && !empty($waste_type)) {
                $stmt = $conn->prepare("INSERT INTO schedules (block_id, collection_day, collection_time_start, collection_time_end, waste_type, notes, status, created_by) VALUES (?, ?, ?, ?, ?, ?, 'active', ?)");
                $stmt->bind_param("isssssi", $block_id, $collection_day, $collection_time_start, $collection_time_end, $waste_type, $notes, $_SESSION['admin_id']);
                
                if ($stmt->execute()) {
                    $success = "Schedule added successfully!";
                } else {
                    $error = "Error adding schedule: " . $stmt->error;
                }
            } else {
                $error = "Please fill in all required fields.";
            }
        } elseif ($_POST['action'] == 'update') {
            $id = intval($_POST['schedule_id'] ?? 0);
            $status = trim($_POST['status'] ?? '');

            if ($id > 0) {
                $stmt = $conn->prepare("UPDATE schedules SET status = ? WHERE id = ?");
                $stmt->bind_param("si", $status, $id);
                
                if ($stmt->execute()) {
                    $success = "Schedule updated successfully!";
                } else {
                    $error = "Error updating schedule: " . $stmt->error;
                }
            }
        } elseif ($_POST['action'] == 'delete') {
            $id = intval($_POST['schedule_id'] ?? 0);

            if ($id > 0) {
                $stmt = $conn->prepare("DELETE FROM schedules WHERE id = ?");
                $stmt->bind_param("i", $id);
                
                if ($stmt->execute()) {
                    $success = "Schedule deleted successfully!";
                } else {
                    $error = "Error deleting schedule: " . $stmt->error;
                }
            }
        }
    }
}

// Fetch all blocks for dropdown
$blocks_result = $conn->query("SELECT * FROM blocks WHERE status = 'active' ORDER BY id");

// Fetch all schedules with block info
$schedules_result = $conn->query("SELECT s.*, b.block_name, b.block_range 
    FROM schedules s 
    JOIN blocks b ON s.block_id = b.id 
    ORDER BY FIELD(s.collection_day, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'), 
    s.collection_time_start ASC");

// Days of week for dropdown
$days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
?>

<style>
    .schedule-card {
        background: white;
        border-radius: 15px;
        padding: 20px;
        margin-bottom: 15px;
        box-shadow: 0 3px 15px rgba(0, 0, 0, 0.08);
        border-left: 5px solid #27ae60;
        transition: all 0.3s ease;
    }

    .schedule-card:hover {
        transform: translateX(5px);
        box-shadow: 0 5px 20px rgba(0, 0, 0, 0.12);
    }

    .schedule-card .block-name {
        font-size: 1.1rem;
        font-weight: 700;
        color: #2c3e50;
    }

    .schedule-card .waste-type {
        color: #27ae60;
        font-weight: 600;
    }

    .schedule-card .time {
        color: #7f8c8d;
        font-size: 0.9rem;
    }

    .schedule-card .day-badge {
        display: inline-block;
        background: #e8f5e9;
        color: #27ae60;
        padding: 5px 15px;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 600;
    }

    .block-1-3 { border-left-color: #1976d2; }
    .block-4-6 { border-left-color: #7b1fa2; }
    .block-7-9 { border-left-color: #388e3c; }
    .block-10-14 { border-left-color: #f57c00; }
</style>

<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1><i class="bi bi-calendar-week me-2"></i>Collection Schedules</h1>
            <p class="text-muted">Manage waste collection schedules for all blocks</p>
        </div>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addScheduleModal">
            <i class="bi bi-plus-lg me-2"></i>Add New Schedule
        </button>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo $success; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Schedules List -->
    <div class="row">
        <?php 
        $current_day = '';
        if ($schedules_result && $schedules_result->num_rows > 0):
            while ($schedule = $schedules_result->fetch_assoc()):
                if ($current_day != $schedule['collection_day']):
                    $current_day = $schedule['collection_day'];
        ?>
                    <div class="col-12 mt-4">
                        <h4 class="text-success"><i class="bi bi-calendar-event me-2"></i><?php echo $current_day; ?></h4>
                        <hr>
                    </div>
        <?php endif; ?>
                <div class="col-md-6 col-lg-4">
                    <div class="schedule-card block-<?php echo str_replace(' ', '-', strtolower($schedule['block_name'])); ?>">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <span class="day-badge"><?php echo $schedule['collection_day']; ?></span>
                            <span class="badge bg-<?php echo ($schedule['status'] == 'active') ? 'success' : 'secondary'; ?>">
                                <?php echo ucfirst($schedule['status']); ?>
                            </span>
                        </div>
                        <div class="block-name mb-1"><?php echo htmlspecialchars($schedule['block_name']); ?></div>
                        <small class="text-muted"><?php echo htmlspecialchars($schedule['block_range']); ?></small>
                        <div class="waste-type mt-2">
                            <i class="bi bi-trash me-1"></i><?php echo htmlspecialchars($schedule['waste_type']); ?>
                        </div>
                        <div class="time mt-2">
                            <i class="bi bi-clock me-1"></i>
                            <?php echo date('h:i A', strtotime($schedule['collection_time_start'])) . ' - ' . date('h:i A', strtotime($schedule['collection_time_end'])); ?>
                        </div>
                        <?php if ($schedule['notes']): ?>
                            <small class="text-muted d-block mt-2">
                                <i class="bi bi-info-circle me-1"></i><?php echo htmlspecialchars($schedule['notes']); ?>
                            </small>
                        <?php endif; ?>
                        <div class="mt-3 d-flex gap-2">
                            <form method="POST" class="d-inline">
                                <input type="hidden" name="action" value="update">
                                <input type="hidden" name="schedule_id" value="<?php echo $schedule['id']; ?>">
                                <select name="status" class="form-select form-select-sm" onchange="this.form.submit()">
                                    <option value="active" <?php echo ($schedule['status'] == 'active') ? 'selected' : ''; ?>>Active</option>
                                    <option value="inactive" <?php echo ($schedule['status'] == 'inactive') ? 'selected' : ''; ?>>Inactive</option>
                                </select>
                            </form>
                            <form method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this schedule?');">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="schedule_id" value="<?php echo $schedule['id']; ?>">
                                <button type="submit" class="btn btn-danger btn-sm">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12 text-center py-5">
                <i class="bi bi-calendar-x fs-1 text-muted"></i>
                <p class="mt-3 text-muted">No schedules found. Add your first schedule!</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Add Schedule Modal -->
<div class="modal fade" id="addScheduleModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title"><i class="bi bi-plus-lg me-2"></i>Add New Schedule</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form method="POST" id="addScheduleForm">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="block_id" class="form-label">Block *</label>
                            <select class="form-select" name="block_id" id="block_id" required>
                                <option value="">Select Block</option>
                                <?php while ($block = $blocks_result->fetch_assoc()): ?>
                                    <option value="<?php echo $block['id']; ?>">
                                        <?php echo htmlspecialchars($block['block_name'] . ' - ' . $block['block_range']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label for="collection_day" class="form-label">Collection Day *</label>
                            <select class="form-select" name="collection_day" id="collection_day" required>
                                <option value="">Select Day</option>
                                <?php foreach ($days as $day): ?>
                                    <option value="<?php echo $day; ?>"><?php echo $day; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label for="collection_time_start" class="form-label">Start Time *</label>
                            <input type="time" class="form-control" name="collection_time_start" id="collection_time_start" required>
                        </div>

                        <div class="col-md-6">
                            <label for="collection_time_end" class="form-label">End Time *</label>
                            <input type="time" class="form-control" name="collection_time_end" id="collection_time_end" required>
                        </div>

                        <div class="col-md-6">
                            <label for="waste_type" class="form-label">Waste Type *</label>
                            <select class="form-select" name="waste_type" id="waste_type" required>
                                <option value="">Select Waste Type</option>
                                <option value="Biodegradable">Biodegradable (Food waste, garden waste)</option>
                                <option value="Non-Biodegradable">Non-Biodegradable (Plastics, metals, glass)</option>
                                <option value="Mixed General Waste">Mixed General Waste</option>
                                <option value="Recyclable">Recyclable Materials</option>
                                <option value="Hazardous">Hazardous Waste</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label for="notes" class="form-label">Notes (Optional)</label>
                            <input type="text" class="form-control" name="notes" id="notes" placeholder="Additional notes...">
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" form="addScheduleForm" class="btn btn-success">Add Schedule</button>
            </div>
        </div>
    </div>
</div>

<?php include("footer.php"); ?>
