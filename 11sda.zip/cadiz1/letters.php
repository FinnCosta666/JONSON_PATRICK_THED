<?php
include("includes/auth_check.php");
include("db_connect.php");
include("header.php");
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css" />

<style>
    body {
        background: linear-gradient(135deg, #d4eee5 0%, #e8f8f0 50%, #c8e6c9 100%);
    }
    
    .card {
        background: linear-gradient(135deg, #f0f9f7 0%, #ffffff 100%);
        border: 2px solid #e8f5e9 !important;
        box-shadow: 0 8px 25px rgba(39, 174, 96, 0.1);
    }
    
    .card-header {
        background: linear-gradient(135deg, #27ae60 0%, #52b788 100%) !important;
        color: white !important;
        border-bottom: none;
    }
    
    .modal-content {
        background: linear-gradient(135deg, #f0f9f7 0%, #ffffff 100%);
        border: 3px solid #27ae60;
        box-shadow: 0 10px 40px rgba(39, 174, 96, 0.2);
    }
    
    .modal-header {
        background: linear-gradient(135deg, #27ae60 0%, #52b788 100%) !important;
        border-bottom: 2px solid #e8f5e9;
    }
    
    .modal-body {
        background-color: #f8fdfb !important;
    }
    
    .btn-success {
        background-color: #27ae60;
        border-color: #27ae60;
    }
    
    .btn-success:hover {
        background-color: #229954;
        border-color: #229954;
    }
</style>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-1 text-success fw-bold">📬 Resident Letters</h1>
        <p class="text-muted mb-0">Letters from residents with their locations</p>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-header bg-success text-white">
        <h6 class="mb-0 fw-bold">✉️ All Letters</h6>
    </div>

    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light text-uppercase small">
                    <tr>
                        <th>ID</th>
                        <th>From (Name)</th>
                        <th>Subject</th>
                        <th>Location</th>
                        <th>Contact</th>
                        <th>Status</th>
                        <th>Date Sent</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT id, resident_name, subject, resident_location, resident_contact, status, date_sent 
                            FROM letters 
                            ORDER BY date_sent DESC";
                    $result = $conn->query($sql);

                    if ($result && $result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $status_badge = $row['status'] == 'unread' ? 
                                '<span class="badge bg-warning">Unread</span>' : 
                                '<span class="badge bg-success">Read</span>';
                            ?>
                            <tr>
                                <td><?= htmlspecialchars($row['id']) ?></td>
                                <td class="fw-semibold"><?= htmlspecialchars($row['resident_name']) ?></td>
                                <td><?= htmlspecialchars($row['subject']) ?></td>
                                <td>
                                     <?= htmlspecialchars($row['resident_location']) ?>
                                </td>
                                <td><?= htmlspecialchars($row['resident_contact'] ?? 'N/A') ?></td>
                                <td><?= $status_badge ?></td>
                                <td class="text-muted small">
                                    <?= htmlspecialchars(date("M d, Y H:i", strtotime($row['date_sent']))) ?>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#letterModal" 
                                            onclick="viewLetter(<?= $row['id'] ?>)">👁️ View</button>
                                </td>
                            </tr>
                            <?php
                        }
                    } else {
                        ?>
                        <tr>
                            <td colspan="8" class="text-center py-5 text-muted">
                                No letters received yet.
                            </td>
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Letter Modal with Map -->
<div class="modal fade" id="letterModal" tabindex="-1" aria-labelledby="letterModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title" id="letterModalLabel">📧 Letter Details & Resident Location</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" style="min-height: 500px; background-color: #f9f9f9;">
                <div class="row g-3">
                    <!-- Letter Details -->
                    <div class="col-md-5">
                        <div id="letterContent" style="max-height: 450px; overflow-y: auto;">
                            <div class="text-center text-muted py-5">
                                <div class="spinner-border text-success" role="status" id="loadingSpinner">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Map -->
                    <div class="col-md-7">
                        <div id="letterMap" style="height: 450px; border-radius: 8px; border: 3px solid #27ae60; background-color: #e8f5e9;"></div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success" data-bs-dismiss="modal">✕ Close</button>
            </div>
        </div>
    </div>
</div>

<?php include("footer.php"); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"></script>
<script>
    let letterMap = null;
    let letterMapMarker = null;

    function viewLetter(letterId) {
        console.log('Viewing letter ID:', letterId);
        
        // Show loading spinner
        document.getElementById('letterContent').innerHTML = `
            <div class="text-center text-muted py-5">
                <div class="spinner-border text-success" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-3">Loading letter details...</p>
            </div>
        `;

        // Fetch letter details via AJAX
        fetch('get_letter_details.php?id=' + letterId)
            .then(response => {
                console.log('Response status:', response.status);
                if (!response.ok) {
                    throw new Error('Network response was not ok: ' + response.status);
                }
                return response.json();
            })
            .then(data => {
                console.log('Letter data received:', data);
                
                if (!data || !data.resident_name) {
                    throw new Error('Invalid letter data received');
                }

                let html = `
                    <div style="background: white; padding: 20px; border-radius: 8px; border: 2px solid #e8f5e9;">
                        <div class="mb-3">
                            <label class="fw-semibold text-success">👤 From:</label>
                            <p class="text-dark mb-0">${escapeHtml(data.resident_name)}</p>
                        </div>

                        <div class="mb-3">
                            <label class="fw-semibold text-success">📧 Email:</label>
                            <p class="text-dark mb-0">${escapeHtml(data.resident_email || 'N/A')}</p>
                        </div>

                        <div class="mb-3">
                            <label class="fw-semibold text-success">📍 Location:</label>
                            <p class="text-dark mb-0">${escapeHtml(data.resident_location || 'N/A')}</p>
                        </div>

                        <div class="mb-3">
                            <label class="fw-semibold text-success">📞 Contact:</label>
                            <p class="text-dark mb-0">${escapeHtml(data.resident_contact || 'N/A')}</p>
                        </div>

                        <hr class="my-3" style="border-color: #e8f5e9;">

                        <div class="mb-3">
                            <label class="fw-semibold text-success">📅 Date Sent:</label>
                            <p class="text-dark mb-0">${new Date(data.date_sent).toLocaleString()}</p>
                        </div>

                        <div class="mb-3">
                            <label class="fw-semibold text-success">Subject:</label>
                            <p class="text-dark mb-0"><strong>${escapeHtml(data.subject)}</strong></p>
                        </div>

                        <hr class="my-3" style="border-color: #e8f5e9;">

                        <div class="mb-3">
                            <label class="fw-semibold text-success">💬 Message:</label>
                            <div class="border p-3 bg-light mt-2" style="white-space: pre-wrap; word-wrap: break-word; max-height: 200px; overflow-y: auto; border-color: #a8d5ba !important;">
                                ${escapeHtml(data.message)}
                            </div>
                        </div>
                    </div>
                `;

                document.getElementById('letterContent').innerHTML = html;

                // Initialize or update map with resident location
                setTimeout(() => {
                    initializeLetterMap(data);
                }, 100);

                // Mark as read
                fetch('mark_letter_read.php?id=' + letterId)
                    .then(r => console.log('Letter marked as read'))
                    .catch(e => console.error('Error marking as read:', e));
            })
            .catch(error => {
                console.error('Error fetching letter:', error);
                document.getElementById('letterContent').innerHTML = `
                    <div class="alert alert-danger">
                        <strong>Error!</strong> Could not load letter details. Please try again.
                        <br><small class="text-muted">${escapeHtml(error.message)}</small>
                    </div>
                `;
            });
    }

    function initializeLetterMap(data) {
        console.log('Initializing map with data:', data);
        
        // Destroy existing map if it exists
        if (letterMap !== null) {
            letterMap.remove();
            letterMap = null;
        }

        // Default coordinates (Dalipuga center)
        let lat = 8.31908333;
        let lng = 124.24880555;
        let markerTitle = data.resident_name + ' - ' + data.resident_location;

        // Use provided coordinates if available
        if (data.latitude && data.longitude) {
            lat = parseFloat(data.latitude);
            lng = parseFloat(data.longitude);
            console.log('Using coordinates from DB:', lat, lng);
        } else {
            console.log('Using default coordinates');
        }

        // Create new map
        letterMap = L.map('letterMap').setView([lat, lng], 15);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors',
            maxZoom: 19
        }).addTo(letterMap);

        // Add marker for resident location
        letterMapMarker = L.marker([lat, lng], {
            title: markerTitle
        }).addTo(letterMap);

        // Create popup with resident info
        let popupContent = `
            <div>
                <strong style="color: #27ae60;">${escapeHtml(data.resident_name)}</strong><br>
                <small>📍 ${escapeHtml(data.resident_location)}</small><br>
                <small>📞 ${escapeHtml(data.resident_contact || 'N/A')}</small><br>
                <small style="color: #27ae60;"><strong>${escapeHtml(data.subject)}</strong></small>
            </div>
        `;

        letterMapMarker.bindPopup(popupContent).openPopup();

        // Adjust map view and invalidate size
        setTimeout(() => {
            letterMap.invalidateSize();
        }, 150);
    }

    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Clean up map when modal is closed
    document.getElementById('letterModal').addEventListener('hide.bs.modal', function() {
        console.log('Modal hidden, cleaning up map');
        if (letterMap !== null) {
            letterMap.remove();
            letterMap = null;
        }
    });
</script>
