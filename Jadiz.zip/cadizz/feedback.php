<?php
include("includes/auth_check.php");
include("includes/db_connect.php");
include("header.php");

$error = "";
$success = "";

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'respond') {
            $feedback_id = intval($_POST['feedback_id'] ?? 0);
            $admin_response = trim($_POST['admin_response'] ?? '');

            if ($feedback_id > 0 && !empty($admin_response)) {
                $stmt = $conn->prepare("UPDATE feedback SET admin_response = ?, response_date = NOW(), status = 'responded' WHERE id = ?");
                $stmt->bind_param("si", $admin_response, $feedback_id);
                
                if ($stmt->execute()) {
                    $success = "Response sent successfully!";
                } else {
                    $error = "Error sending response: " . $stmt->error;
                }
            } else {
                $error = "Please provide a response.";
            }
        } elseif ($_POST['action'] == 'mark_read') {
            $feedback_id = intval($_POST['feedback_id'] ?? 0);

            if ($feedback_id > 0) {
                $stmt = $conn->prepare("UPDATE feedback SET status = 'read' WHERE id = ?");
                $stmt->bind_param("i", $feedback_id);
                
                if ($stmt->execute()) {
                    $success = "Marked as read!";
                } else {
                    $error = "Error updating status: " . $stmt->error;
                }
            }
        }
    }
}

// Get filter parameters
$filter_status = $_GET['status'] ?? 'all';
$filter_type = $_GET['type'] ?? 'all';
$filter_block = $_GET['block'] ?? 'all';

// Build query
$query = "SELECT f.*, r.house_number, b.block_name, b.block_range 
    FROM feedback f 
    LEFT JOIN residents r ON f.resident_id = r.id 
    LEFT JOIN blocks b ON f.block_id = b.id 
    WHERE 1=1";

if ($filter_status != 'all') {
    $query .= " AND f.status = '$filter_status'";
}
if ($filter_type != 'all') {
    $query .= " AND f.feedback_type = '$filter_type'";
}
if ($filter_block != 'all') {
    $query .= " AND f.block_id = $filter_block";
}

$query .= " ORDER BY f.date_submitted DESC";

$feedback_result = $conn->query($query);

// Get blocks for filter
$blocks_result = $conn->query("SELECT * FROM blocks WHERE status = 'active' ORDER BY id");

// Get statistics
$stats_result = $conn->query("SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN status = 'unread' THEN 1 ELSE 0 END) as unread,
    SUM(CASE WHEN status = 'read' THEN 1 ELSE 0 END) as read_count,
    SUM(CASE WHEN status = 'responded' THEN 1 ELSE 0 END) as responded
    FROM feedback");
$stats = $stats_result->fetch_assoc();
?>

<style>
    .feedback-card {
        background: white;
        border-radius: 15px;
        padding: 25px;
        margin-bottom: 20px;
        box-shadow: 0 3px 15px rgba(0, 0, 0, 0.08);
        border-left: 5px solid #f39c12;
        transition: all 0.3s ease;
    }

    .feedback-card.unread {
        border-left-color: #e74c3c;
        background: linear-gradient(135deg, #fff5f5 0%, #ffffff 100%);
    }

    .feedback-card.read {
        border-left-color: #3498db;
    }

    .feedback-card.responded {
        border-left-color: #27ae60;
    }

    .feedback-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);
    }

    .feedback-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 15px;
    }

    .feedback-author {
        display: flex;
        align-items: center;
        gap: 15px;
    }

    .author-avatar {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        background: linear-gradient(135deg, #27ae60 0%, #229954 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 20px;
        font-weight: 600;
    }

    .author-info h5 {
        margin: 0;
        color: #2c3e50;
        font-weight: 600;
    }

    .author-info small {
        color: #7f8c8d;
    }

    .feedback-type {
        display: inline-block;
        padding: 5px 15px;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 600;
    }

    .type-feedback { background: #e3f2fd; color: #1976d2; }
    .type-complaint { background: #ffebee; color: #c62828; }
    .type-suggestion { background: #e8f5e9; color: #2e7d32; }
    .type-issue { background: #fff3e0; color: #ef6c00; }

    .feedback-content {
        background: #f8f9fa;
        border-radius: 10px;
        padding: 20px;
        margin: 15px 0;
    }

    .feedback-content h6 {
        color: #27ae60;
        margin-bottom: 10px;
    }

    .admin-response {
        background: #e8f5e9;
        border-radius: 10px;
        padding: 20px;
        margin-top: 15px;
    }

    .admin-response h6 {
        color: #27ae60;
        margin-bottom: 10px;
    }

    .rating-stars {
        color: #f39c12;
    }

    .stats-box {
        background: white;
        border-radius: 15px;
        padding: 20px;
        text-align: center;
        box-shadow: 0 3px 15px rgba(0, 0, 0, 0.08);
    }

    .stats-box .number {
        font-size: 2rem;
        font-weight: 700;
    }

    .stats-box .label {
        color: #7f8c8d;
        font-size: 0.9rem;
    }
</style>

<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1><i class="bi bi-chat-dots me-2"></i>Resident Feedback</h1>
            <p class="text-muted">View and respond to feedback from residents</p>
        </div>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo $success; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Statistics -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3">
            <div class="stats-box">
                <div class="number text-primary"><?php echo $stats['total']; ?></div>
                <div class="label">Total Feedback</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="stats-box">
                <div class="number text-danger"><?php echo $stats['unread']; ?></div>
                <div class="label">Unread</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="stats-box">
                <div class="number text-info"><?php echo $stats['read_count']; ?></div>
                <div class="label">Read</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="stats-box">
                <div class="number text-success"><?php echo $stats['responded']; ?></div>
                <div class="label">Responded</div>
            </div>
        </div>
    </div>

    <!-- Filters -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select" onchange="this.form.submit()">
                        <option value="all" <?php echo ($filter_status == 'all') ? 'selected' : ''; ?>>All Status</option>
                        <option value="unread" <?php echo ($filter_status == 'unread') ? 'selected' : ''; ?>>Unread</option>
                        <option value="read" <?php echo ($filter_status == 'read') ? 'selected' : ''; ?>>Read</option>
                        <option value="responded" <?php echo ($filter_status == 'responded') ? 'selected' : ''; ?>>Responded</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Type</label>
                    <select name="type" class="form-select" onchange="this.form.submit()">
                        <option value="all" <?php echo ($filter_type == 'all') ? 'selected' : ''; ?>>All Types</option>
                        <option value="Feedback" <?php echo ($filter_type == 'Feedback') ? 'selected' : ''; ?>>Feedback</option>
                        <option value="Complaint" <?php echo ($filter_type == 'Complaint') ? 'selected' : ''; ?>>Complaint</option>
                        <option value="Suggestion" <?php echo ($filter_type == 'Suggestion') ? 'selected' : ''; ?>>Suggestion</option>
                        <option value="Issue" <?php echo ($filter_type == 'Issue') ? 'selected' : ''; ?>>Issue</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Block</label>
                    <select name="block" class="form-select" onchange="this.form.submit()">
                        <option value="all" <?php echo ($filter_block == 'all') ? 'selected' : ''; ?>>All Blocks</option>
                        <?php while ($block = $blocks_result->fetch_assoc()): ?>
                            <option value="<?php echo $block['id']; ?>" <?php echo ($filter_block == $block['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($block['block_name']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
            </form>
        </div>
    </div>

    <!-- Feedback List -->
    <?php if ($feedback_result && $feedback_result->num_rows > 0): ?>
        <?php while ($feedback = $feedback_result->fetch_assoc()): ?>
            <div class="feedback-card <?php echo $feedback['status']; ?>">
                <div class="feedback-header">
                    <div class="feedback-author">
                        <div class="author-avatar">
                            <?php echo strtoupper(substr($feedback['resident_name'], 0, 1)); ?>
                        </div>
                        <div class="author-info">
                            <h5><?php echo htmlspecialchars($feedback['resident_name']); ?></h5>
                            <small>
                                <i class="bi bi-house me-1"></i><?php echo htmlspecialchars($feedback['house_number'] ?? 'N/A'); ?> | 
                                <i class="bi bi-building me-1"></i><?php echo htmlspecialchars($feedback['block_name'] ?? 'N/A'); ?> | 
                                <i class="bi bi-calendar me-1"></i><?php echo date('M d, Y', strtotime($feedback['date_submitted'])); ?>
                            </small>
                        </div>
                    </div>
                    <div class="text-end">
                        <span class="feedback-type type-<?php echo strtolower($feedback['feedback_type']); ?>">
                            <?php echo htmlspecialchars($feedback['feedback_type']); ?>
                        </span>
                        <span class="badge bg-<?php echo ($feedback['status'] == 'unread') ? 'danger' : (($feedback['status'] == 'read') ? 'info' : 'success'); ?> d-block mt-2">
                            <?php echo ucfirst($feedback['status']); ?>
                        </span>
                        <?php if ($feedback['rating'] > 0): ?>
                            <div class="rating-stars mt-2">
                                <?php for ($i = 0; $i < $feedback['rating']; $i++): ?>⭐<?php endfor; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="feedback-content">
                    <h6><i class="bi bi-chat-left-text me-2"></i><?php echo htmlspecialchars($feedback['subject']); ?></h6>
                    <p class="mb-0"><?php echo nl2br(htmlspecialchars($feedback['message'])); ?></p>
                </div>

                <?php if ($feedback['admin_response']): ?>
                    <div class="admin-response">
                        <h6><i class="bi bi-reply me-2"></i>Admin Response</h6>
                        <p class="mb-0"><?php echo nl2br(htmlspecialchars($feedback['admin_response'])); ?></p>
                        <small class="text-muted">
                            Responded on <?php echo date('M d, Y', strtotime($feedback['response_date'])); ?>
                        </small>
                    </div>
                <?php endif; ?>

                <div class="mt-3 d-flex gap-2">
                    <?php if ($feedback['status'] == 'unread'): ?>
                        <form method="POST" class="d-inline">
                            <input type="hidden" name="action" value="mark_read">
                            <input type="hidden" name="feedback_id" value="<?php echo $feedback['id']; ?>">
                            <button type="submit" class="btn btn-info btn-sm">
                                <i class="bi bi-check me-1"></i>Mark as Read
                            </button>
                        </form>
                    <?php endif; ?>
                    
                    <?php if (empty($feedback['admin_response'])): ?>
                        <button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#replyModal<?php echo $feedback['id']; ?>">
                            <i class="bi bi-reply me-1"></i>Reply
                        </button>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Reply Modal -->
            <div class="modal fade" id="replyModal<?php echo $feedback['id']; ?>" tabindex="-1">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header bg-success text-white">
                            <h5 class="modal-title"><i class="bi bi-reply me-2"></i>Reply to Feedback</h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label class="form-label"><strong>Original Message:</strong></label>
                                <div class="p-3 bg-light rounded">
                                    <strong><?php echo htmlspecialchars($feedback['subject']); ?></strong>
                                    <p class="mb-0 mt-2"><?php echo nl2br(htmlspecialchars($feedback['message'])); ?></p>
                                </div>
                            </div>

                            <form method="POST" id="replyForm<?php echo $feedback['id']; ?>">
                                <input type="hidden" name="action" value="respond">
                                <input type="hidden" name="feedback_id" value="<?php echo $feedback['id']; ?>">
                                
                                <div class="mb-3">
                                    <label for="admin_response" class="form-label">Your Response *</label>
                                    <textarea class="form-control" name="admin_response" rows="5" required placeholder="Type your response here..."></textarea>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" form="replyForm<?php echo $feedback['id']; ?>" class="btn btn-success">Send Response</button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <div class="text-center py-5">
            <i class="bi bi-inbox fs-1 text-muted"></i>
            <p class="mt-3 text-muted">No feedback found matching your filters.</p>
        </div>
    <?php endif; ?>
</div>

<?php include("footer.php"); ?>
