<?php
session_start();
// clear session data and destroy session
$_SESSION = [];
if (ini_get("session.use_cookies")) {
	$params = session_get_cookie_params();
	setcookie(session_name(), '', time() - 42000,
		$params["path"], $params["domain"],
		$params["secure"], $params["httponly"]
	);
}
session_unset();
session_destroy();

// Redirect to the unified login page (admin + resident)
header("Location: login.php");
exit;
?>
