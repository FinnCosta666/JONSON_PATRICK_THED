<?php
session_start();
include("../includes/db_connect.php");

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($email === '' || $password === '') {
        $error = "Please fill in all fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } else {
        $stmt = $conn->prepare("SELECT id, first_name, last_name, email, password FROM residents WHERE email = ?");
        if ($stmt) {
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result && $result->num_rows > 0) {
                $row = $result->fetch_assoc();
                if (password_verify($password, $row['password']) || $row['password'] === $password) {
                    $_SESSION['resident_id'] = $row['id'];
                    $_SESSION['resident_name'] = $row['first_name'] . ' ' . $row['last_name'];
                    $_SESSION['resident_email'] = $row['email'];
                    $_SESSION['role'] = 'resident';
                    header("Location: ../resident_dashboard.php");
                    exit;
                }
            }
            $stmt->close();
        }
        $error = $error ?: "Invalid email or password.";
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Resident Login • Dalipuga Cleanup</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">


</head>
<body class="auth-wrapper">

<div class="dashboard-card auth-card">
    <div class="">
        <div class="text-center mb-3">
            <h3 class="mb-0 brand">♻️ Dalipuga Cleanup</h3>
            <div class="small-link">Resident Login Portal</div>
        </div>

        <?php if (!empty($error)): ?>
            <div class="alert alert-danger" role="alert"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST" novalidate>
            <div class="mb-3">
                <label for="email" class="form-label">Username</label>
                <input id="email" name="email" type="email" class="form-control" placeholder="Enter your username" required
                       value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>" autocomplete="email">
            </div>

            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input id="password" name="password" type="password" class="form-control" placeholder="Enter password" required autocomplete="current-password">
            </div>

            <div class="d-grid">
                <button class="btn btn-primary btn-lg" type="submit">Login</button>
            </div>
        </form>

        <div class="divider"></div>

        <div class="text-center">
            <div class="mb-2">Don't have an account? <a href="resident_register.php">Register here</a></div>
            <div class="mb-2"><a href="#" data-bs-toggle="modal" data-bs-target="#forgotPasswordModal">Forgot Password?</a></div>
            <div class="mb-0 small-link">Admin? <a href="login.php">Login as Administrator</a></div>
        </div>
    </div>
</div>

<!-- Forgot Password Modal (simple, simulated) -->
<div class="modal fade" id="forgotPasswordModal" tabindex="-1" aria-labelledby="forgotPasswordLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="forgotPasswordLabel">Reset Your Password</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p class="mb-3">Enter your email address and we'll send instructions to reset your password.</p>
                <form id="forgotPasswordForm">
                    <div class="mb-3">
                        <label for="forgotEmail" class="form-label">Email Address</label>
                        <input id="forgotEmail" name="forgotEmail" type="email" class="form-control" placeholder="Enter your registered email" required>
                    </div>
                    <div id="forgotPasswordMessage"></div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="sendResetBtn">Send Reset Link</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Safe helpers
    const el = (sel) => document.querySelector(sel);
    const esc = (s) => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));

    // Forgot password flow (simulated)
    document.getElementById('sendResetBtn')?.addEventListener('click', () => {
        const email = el('#forgotEmail')?.value?.trim() || '';
        const msg = el('#forgotPasswordMessage');
        if (!email) { msg.innerHTML = '<div class="alert alert-danger">Please enter your email address.</div>'; return; }
        if (!email.includes('@')) { msg.innerHTML = '<div class="alert alert-danger">Please enter a valid email address.</div>'; return; }
        msg.innerHTML = '<div class="alert alert-success"><strong>Success!</strong> A password reset link has been sent to ' + esc(email) + '.</div>';
        setTimeout(() => { el('#forgotPasswordForm')?.reset(); msg.innerHTML = ''; const modal = bootstrap.Modal.getInstance(el('#forgotPasswordModal')); modal?.hide(); }, 2000);
    });

    // Enhance UX: submit on Enter in modal
    el('#forgotEmail')?.addEventListener('keypress', (e) => { if (e.key === 'Enter') { e.preventDefault(); document.getElementById('sendResetBtn').click(); } });
</script>

</body>
</html>